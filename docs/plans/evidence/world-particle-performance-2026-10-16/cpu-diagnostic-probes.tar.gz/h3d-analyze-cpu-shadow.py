from pathlib import Path
import collections,hashlib,json,statistics
root=Path('/home/me/code/holtburger');trials=json.loads(Path('/tmp/h3d-cpu-shadow-trials.json').read_text())['trials']
# Locations are zero-based CDP call-frame coordinates in the exact production bundle.
chunk='portal-transition-controller-DUBKhiRh.js';tuning='client-tuning-D2xRF4P9.js'
symbols={
 'sceneAssembly':(chunk,2495,38218,'WebGL2Renderer.#resolveSceneContributions','renderer/webgl2-renderer.ts'),
 'shadowPreparation':(chunk,2495,35607,'WebGL2Renderer.#prepareOutdoorShadows','renderer/webgl2-renderer.ts'),
 'shadowPassPrepare':(chunk,1316,4284,'WebGL2OutdoorPssmPass.prepare','renderer/webgl2-outdoor-pssm-pass.ts'),
 'shadowCasterSelection':(chunk,1297,9128,'planOutdoorShadowCastersForView','renderer/outdoor-pssm-casters.ts'),
 'sceneQuerySelection':(chunk,120,20943,'SceneGraph.#selectEntries','scene/scene-graph.ts'),
 'entryFrustumTest':(chunk,120,25438,'SceneGraph.#frustumIntersectsEntry','scene/scene-graph.ts'),
 'contributionDescriptor':(chunk,120,29815,'RenderWorld.getRenderContributionDescriptor','renderer/render-world.ts'),
 'footprintProjection':(chunk,120,33466,'classifyObjectFootprint','renderer/object-footprint.ts'),
 'retailVisibility':(chunk,120,27736,'retainsRetailGeometry','renderer/retail-geometry-visibility.ts'),
 'dynamicOpaqueRangePreparation':(chunk,1738,33533,'DynamicBatchedRanges.prepare','renderer/dynamic-opaque-range-preparation.ts'),
 'matrixMultiply':(tuning,0,9559,'multiplyMat4','math/matrices.ts'),
 'dynamicPresentationPublication':(chunk,2538,68309,'DynamicEntitySystem.publishPresentation','systems/dynamic-entity-system.ts'),
 'dynamicSampleApplication':(chunk,2538,73604,'DynamicEntitySystem.#applySample','systems/dynamic-entity-system.ts')}
# Verify source mapping paths, correcting the actual range-preparer filename from its declaration.
for key,row in list(symbols.items()):
 file=root/'apps/holtburger-3d/src/lib/game'/row[4]
 if not file.exists() and key=='dynamicOpaqueRangePreparation':
  matches=[p for p in (root/'apps/holtburger-3d/src/lib/game/renderer').glob('*.ts') if 'Dynamic color range references missing part' in p.read_text()]
  assert len(matches)==1;symbols[key]=(*row[:4],str(matches[0].relative_to(root/'apps/holtburger-3d/src/lib/game')))
 else:assert file.exists(),file
lookup={tuple(v[:3]):k for k,v in symbols.items()}
profiles=[]
for t in trials:
 if not t['sampling']:continue
 p=json.loads(Path(t['profilePath']).read_text());nodes={n['id']:n for n in p['nodes']};parents={c:n['id'] for n in p['nodes'] for c in n.get('children',[])}
 def key(id):
  c=nodes[id]['callFrame'];return (c['url'].split('/')[-1].split('?')[0],c['lineNumber'],c['columnNumber'])
 def name(id):
  c=nodes[id]['callFrame'];return (c['functionName'],*key(id))
 leaf=collections.Counter();inclusive=collections.Counter();contexts=collections.Counter();allself=collections.Counter();allinclusive=collections.Counter()
 for id,dt in list(zip(p['samples'],p['timeDeltas']))[1:]:
  allself[name(id)]+=dt
  if key(id) in lookup:leaf[lookup[key(id)]]+=dt
  ancestors=[];seen=set();allseen=set();cur=id
  while cur is not None:
   k=key(cur);n=name(cur)
   if n not in allseen:allinclusive[n]+=dt;allseen.add(n)
   if k in lookup and lookup[k] not in seen:ancestors.append(lookup[k]);seen.add(lookup[k]);inclusive[lookup[k]]+=dt
   cur=parents.get(cur)
  phase='shadow' if 'shadowPreparation' in seen else 'scene' if 'sceneAssembly' in seen else 'elsewhere'
  for k in seen:contexts[(phase,k)]+=dt
 f=t['snapshot']['sampledFrameCount']
 profiles.append({'round':t['round'],'shadowMode':t['shadowMode'],'frames':f,'profileFile':Path(t['profilePath']).name,'durationMs':(p['endTime']-p['startTime'])/1000,'leadingGapMs':p['timeDeltas'][0]/1000,'sampledDurationAfterLeadingGapMs':sum(p['timeDeltas'][1:])/1000,'sampleCount':len(p['samples']),
 'functions':{k:{'selfMsPerFrame':leaf[k]/1000/f,'inclusiveMsPerFrame':inclusive[k]/1000/f,'contextInclusiveMsPerFrame':{phase:contexts[(phase,k)]/1000/f for phase in ['shadow','scene','elsewhere']}} for k in symbols},
 'topSelf':[{'symbol':list(k),'msPerFrame':v/1000/f} for k,v in allself.most_common(30)],'topInclusive':[{'symbol':list(k),'msPerFrame':v/1000/f} for k,v in allinclusive.most_common(35)]})
def stats(values):return {'median':statistics.median(values),'min':min(values),'max':max(values)}
aggregates={}
for mode in ['shadow-maps','none']:
 rows=[p for p in profiles if p['shadowMode']==mode];assert len(rows)==5
 aggregates[mode]={k:{metric:stats([r['functions'][k][metric] for r in rows]) for metric in ['selfMsPerFrame','inclusiveMsPerFrame']}|{'contextInclusiveMsPerFrame':{phase:stats([r['functions'][k]['contextInclusiveMsPerFrame'][phase] for r in rows]) for phase in ['shadow','scene','elsewhere']}} for k in symbols}
metrics={}
getters={
 'frameWorkMs':lambda t:t['snapshot']['meanFrameWorkMs'],
 'observedFps':lambda t:t['snapshot']['sampledFrameCount']*1000/t['windowMs'],
 'rendererCpuMs':lambda t:t['snapshot']['diagnostics']['renderer']['profile']['cpu']['mean']['totalMs'],
 'sceneAssemblyCpuMs':lambda t:t['snapshot']['diagnostics']['renderer']['profile']['cpu']['mean']['sceneContributionResolutionMs'],
 'shadowCpuMs':lambda t:t['snapshot']['diagnostics']['renderer']['profile']['cpu']['mean']['outdoorShadowMapMs'],
 'totalGpuMs':lambda t:t['snapshot']['diagnostics']['renderer']['profile']['gpu']['mean']['totalMs'],
 'shadowGpuMs':lambda t:t['snapshot']['diagnostics']['renderer']['profile']['gpu']['mean']['outdoorShadowMapMs'],
 'particleGpuMs':lambda t:t['snapshot']['diagnostics']['renderer']['profile']['gpu']['mean']['particleMs'],
 'visibleDynamicCount':lambda t:t['snapshot']['diagnostics']['renderer']['selectionMetrics']['visibleDynamicEntityCount'],
 'visibleSceneEntries':lambda t:t['snapshot']['diagnostics']['renderer']['selectionMetrics']['visibleSceneEntries']}
for sampling in [True,False]:
 key='withV8' if sampling else 'withoutV8';metrics[key]={}
 for mode in ['shadow-maps','none']:
  rows=[t for t in trials if t['sampling']==sampling and t['shadowMode']==mode];assert len(rows)==5
  metrics[key][mode]={name:stats([fn(t) for t in rows]) for name,fn in getters.items()}
 metrics[key]['pairedMappedMinusNone']={name:stats([fn(next(t for t in trials if t['sampling']==sampling and t['round']==round and t['shadowMode']=='shadow-maps'))-fn(next(t for t in trials if t['sampling']==sampling and t['round']==round and t['shadowMode']=='none')) for round in range(5)]) for name,fn in getters.items()}
symbolRows={k:{'bundle':v[0],'lineNumber':v[1],'columnNumber':v[2],'sourceSymbol':v[3],'sourcePath':'apps/holtburger-3d/src/lib/game/'+v[4]} for k,v in symbols.items()}
sourceHashes={v['sourcePath']:hashlib.sha256((root/v['sourcePath']).read_bytes()).hexdigest() for v in symbolRows.values()}
bundleHashes={name:hashlib.sha256((root/'apps/holtburger-3d/dist/assets'/name).read_bytes()).hexdigest() for name in {v[0] for v in symbols.values()}}
result={'date':'2026-10-16','productionSourceChanges':False,'method':{'productionFrontend':True,'releaseHost':True,'samplingIntervalUs':100,'windowMs':5000,'settleMs':1500,'roundsPerSamplingMode':5,'samplingModesSequential':True,'symbolCoordinates':'zero based CDP call frames; matched to source bodies in hashed production assets','leadingDeltaTreatment':'Exclude first sample/delta: it includes Profiler.start initialization before measurement. Raw profiles retain it. Function timing is sampled attribution normalized by the bridge measured frame count; profile start/stop and bridge boundaries are not exactly coincident.','hostAndMainThreadOnly':'V8 samples cover the renderer main thread, not Rust, GPU process, compositor, or workers.','qualityAblation':'none disables mapped and analytic shadows and changes receivers too; total savings cannot be assigned solely to caster selection.','coLoad':'During the V8 block, diagnostic Python profile aggregation ran between observations and may overlap windows. The separate without-V8 block ran after it, without heavy aggregation. V8 results support attribution; without-V8 results carry the performance comparison.','liveDrift':'Compare pairs in one session. Counts are snapshot workloads, not frozen inputs; sun, animation, mobs, and particle populations can vary.'},'timing':metrics,'sampledFunctions':aggregates,'profiles':profiles,'compilerSymbols':symbolRows,'sourceHashes':sourceHashes,'bundleHashes':bundleHashes,'viewportValues':[list(v) for v in sorted({tuple(t['snapshot']['diagnostics']['viewport'].values()) for t in trials})]}
Path('/tmp/h3d-cpu-shadow-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'timing':metrics,'attribution':{mode:{k:aggregates[mode][k]['inclusiveMsPerFrame'] for k in ['sceneAssembly','shadowPreparation','shadowCasterSelection','sceneQuerySelection','contributionDescriptor','matrixMultiply']} for mode in aggregates}},indent=2))
