async () => {
 const [{RenderWorld},{SceneGraph},{WebGL2Renderer},{WebGL2OutdoorPssmPass},{ParticleSystem},{Mat4}]=await Promise.all([
  import('/src/lib/game/renderer/render-world.ts'),import('/src/lib/game/scene/scene-graph.ts'),import('/src/lib/game/renderer/webgl2-renderer.ts'),import('/src/lib/game/renderer/webgl2-outdoor-pssm-pass.ts'),import('/src/lib/game/systems/particle-system.ts'),import('/src/lib/game/math/types.ts')]);
 const state=window.__cpuWorkAudit={collecting:false,frames:[],current:null,shadow:false,descriptor:false,dominantOwners:new Set()};
 const collect=ParticleSystem.prototype.collectDrawRanges;
 ParticleSystem.prototype.collectDrawRanges=function(){const result=collect.apply(this,arguments);state.dominantOwners.clear();for(const r of result)if(r.hwGfxObjId==='0x01003fa7')state.dominantOwners.add(r.renderOwner);return result;};
 const draw=WebGL2Renderer.prototype.drawFrame;
 WebGL2Renderer.prototype.drawFrame=function(){
  if(!state.collecting)return draw.apply(this,arguments);
  if(state.current)throw new Error('Unexpected nested renderer frame');
  const frame=state.current={descriptorCalls:{shadow:{},color:{}},uniqueDescriptors:new Set(),repeatedDescriptors:0,shadowQueries:[],colorQueries:[],shadowQueriedOwners:new Set(),clones:{shadowDescriptor:0,colorDescriptor:0,otherRenderer:0},copiedPlacementCalls:{shadowDescriptor:0,colorDescriptor:0,otherRenderer:0},copiedBoundsCalls:{shadowDescriptor:0,colorDescriptor:0,otherRenderer:0},dominantOwnerCount:state.dominantOwners.size,dominantDescriptorCalls:{shadow:0,color:0}};
  try{return draw.apply(this,arguments);}finally{
   frame.uniqueDescriptorCount=frame.uniqueDescriptors.size;delete frame.uniqueDescriptors;
   frame.shadowUniqueQueriedOwnerCount=frame.shadowQueriedOwners.size;
   frame.shadowDominantUniqueQueriedOwners=[...frame.shadowQueriedOwners].filter(id=>state.dominantOwners.has(id)).length;delete frame.shadowQueriedOwners;
   state.current=null;state.frames.push(frame);if(state.frames.length>=300)state.collecting=false;
  }
 };
 const prepare=WebGL2OutdoorPssmPass.prototype.prepare;
 WebGL2OutdoorPssmPass.prototype.prepare=function(){const previous=state.shadow;state.shadow=true;try{return prepare.apply(this,arguments);}finally{state.shadow=previous;}};
 const descriptor=RenderWorld.prototype.getRenderContributionDescriptor;
 RenderWorld.prototype.getRenderContributionDescriptor=function(nodeId){
  const previous=state.descriptor;state.descriptor=true;
  try{const result=descriptor.apply(this,arguments);const f=state.current;if(f){const phase=state.shadow?'shadow':'color';const label=result===null?'none':result.kind==='dynamic'?'dynamic:'+result.entityClass:result.kind;const counts=f.descriptorCalls[phase];counts[label]=(counts[label]||0)+1;if(f.uniqueDescriptors.has(nodeId))f.repeatedDescriptors++;else f.uniqueDescriptors.add(nodeId);if(state.dominantOwners.has(nodeId))f.dominantDescriptorCalls[phase]++;}return result;}finally{state.descriptor=previous;}
 };
 for(const method of ['queryScopesScene','queryScopeSelectionScene','queryFlatScene']){
  const original=RenderWorld.prototype[method];if(typeof original!=='function')throw new Error('Missing world query '+method);
  RenderWorld.prototype[method]=function(){const result=original.apply(this,arguments);const f=state.current;if(f){const record={method,entries:result.entries.length,dominantOwners:0};for(const id of result.entries){if(state.dominantOwners.has(id))record.dominantOwners++;if(state.shadow)f.shadowQueriedOwners.add(id);}f[state.shadow?'shadowQueries':'colorQueries'].push(record);}return result;};
 }
 function category(){return state.descriptor?(state.shadow?'shadowDescriptor':'colorDescriptor'):'otherRenderer';}
 for(const [method,metric] of [['getResolvedPlacement','copiedPlacementCalls'],['getResolvedBounds','copiedBoundsCalls']]){
  const original=SceneGraph.prototype[method];SceneGraph.prototype[method]=function(){if(state.current)state.current[metric][category()]++;return original.apply(this,arguments);};
 }
 const clone=Mat4.prototype.clone;Mat4.prototype.clone=function(){if(state.current)state.current.clones[category()]++;return clone.apply(this,arguments);};
}
