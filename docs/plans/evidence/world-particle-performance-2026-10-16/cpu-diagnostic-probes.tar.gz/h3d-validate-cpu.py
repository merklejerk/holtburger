from pathlib import Path
import ast,collections,gzip,hashlib,json,re,statistics,subprocess,tarfile
root=Path.cwd();base=root/'docs/plans/evidence/world-particle-performance-2026-10-16';summary=json.loads((base/'cpu-shadow-summary.json').read_text());trials=json.loads(gzip.decompress((base/'cpu-shadow-trials.json.gz').read_bytes()))['trials']
def stats(xs):return {'median':statistics.median(xs),'min':min(xs),'max':max(xs)}
assert len(trials)==20
for sampling in [True,False]:
 for mode in ['shadow-maps','none']:
  rows=[t for t in trials if t['sampling']==sampling and t['shadowMode']==mode];assert len(rows)==5
  for t in rows:
   snap=t['snapshot'];renderer=snap['diagnostics']['renderer'];assert snap['sampledFrameCount']>0
   assert snap['diagnostics']['cameraResidency']=={'landblockId':'0x482dffff','envCellId':None}
   expected=0 if mode=='none' else 8388608;assert renderer['entityShadows']['outdoorTargets']['activeBytes']==expected
   if mode=='none':assert renderer['profile']['cpu']['mean']['outdoorShadowMapMs']==renderer['profile']['gpu']['mean']['outdoorShadowMapMs']==0
  key='withV8' if sampling else 'withoutV8';assert summary['timing'][key][mode]['frameWorkMs']==stats([t['snapshot']['meanFrameWorkMs'] for t in rows])
  assert summary['timing'][key][mode]['observedFps']==stats([t['snapshot']['sampledFrameCount']*1000/t['windowMs'] for t in rows])
 for metric,getter in [('frameWorkMs',lambda t:t['snapshot']['meanFrameWorkMs']),('rendererCpuMs',lambda t:t['snapshot']['diagnostics']['renderer']['profile']['cpu']['mean']['totalMs']),('shadowCpuMs',lambda t:t['snapshot']['diagnostics']['renderer']['profile']['cpu']['mean']['outdoorShadowMapMs'])]:
  differences=[getter(next(t for t in trials if t['sampling']==sampling and t['round']==i and t['shadowMode']=='shadow-maps'))-getter(next(t for t in trials if t['sampling']==sampling and t['round']==i and t['shadowMode']=='none')) for i in range(5)]
  assert stats(differences)==summary['timing'][key]['pairedMappedMinusNone'][metric]
lookup={(v['bundle'],v['lineNumber'],v['columnNumber']):k for k,v in summary['compilerSymbols'].items()}
for row in summary['profiles']:
 profile=json.loads(gzip.decompress((base/row['evidenceFile']).read_bytes()));nodes={n['id']:n for n in profile['nodes']};parents={c:n['id'] for n in profile['nodes'] for c in n.get('children',[])}
 assert nodes[profile['samples'][0]]['callFrame']['functionName']=='(program)'
 assert len(profile['samples'])==len(profile['timeDeltas'])==row['sampleCount']
 assert profile['timeDeltas'][0]/1000==row['leadingGapMs']
 assert all('?' not in n['callFrame']['url'] and '#' not in n['callFrame']['url'] for n in profile['nodes'])
 self_ms=collections.Counter();inclusive_ms=collections.Counter();context_ms=collections.Counter()
 for node_id,delta in list(zip(profile['samples'],profile['timeDeltas']))[1:]:
  keys=[];current=node_id
  while current is not None:
   c=nodes[current]['callFrame'];key=(c['url'].split('/')[-1],c['lineNumber'],c['columnNumber']);keys.append(lookup.get(key));current=parents.get(current)
  if keys[0]:self_ms[keys[0]]+=delta
  phase='shadow' if 'shadowPreparation' in keys else 'scene' if 'sceneAssembly' in keys else 'elsewhere'
  for key in set(keys)-{None}:inclusive_ms[key]+=delta;context_ms[(phase,key)]+=delta
 for key in summary['compilerSymbols']:
  actual=row['functions'][key];assert actual['selfMsPerFrame']==self_ms[key]/1000/row['frames'];assert actual['inclusiveMsPerFrame']==inclusive_ms[key]/1000/row['frames']
  for phase in ['shadow','scene','elsewhere']:assert actual['contextInclusiveMsPerFrame'][phase]==context_ms[(phase,key)]/1000/row['frames']
for mode in ['shadow-maps','none']:
 rows=[p for p in summary['profiles'] if p['shadowMode']==mode]
 for symbol in summary['compilerSymbols']:
  for metric in ['selfMsPerFrame','inclusiveMsPerFrame']:assert summary['sampledFunctions'][mode][symbol][metric]==stats([r['functions'][symbol][metric] for r in rows])
for name,digest in summary['sourceHashes'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
for name,digest in summary['bundleHashes'].items():assert hashlib.sha256((root/'apps/holtburger-3d/dist/assets'/name).read_bytes()).hexdigest()==digest
for mode in ['none','mapped']:
 capture=json.loads(gzip.decompress((base/f'cpu-work-audit-{mode}.json.gz').read_bytes()));frames=capture['frames'];assert len(frames)==300
 for frame in frames:
  assert frame['dominantOwnerCount']==206
  assert frame['dominantDescriptorCalls']['color']==206
  assert frame['clones']['colorDescriptor']==frame['copiedPlacementCalls']['colorDescriptor']+frame['copiedBoundsCalls']['colorDescriptor']
  total=sum(sum(counts.values()) for counts in frame['descriptorCalls'].values());assert total==frame['uniqueDescriptorCount']+frame['repeatedDescriptors']
  if mode=='mapped':
   assert len(frame['shadowQueries'])==2 and all(q['dominantOwners']==206 for q in frame['shadowQueries'])
   assert frame['shadowDominantUniqueQueriedOwners']==frame['dominantDescriptorCalls']['shadow']==206
   counts=frame['descriptorCalls']['shadow'];assert set(counts)=={'dynamic:other','dynamic:mob','dynamic:npc','dynamic:player'}
   assert counts['dynamic:mob']+counts['dynamic:npc']+counts['dynamic:player']==64
   assert sum(counts.values())==frame['shadowUniqueQueriedOwnerCount']==frame['clones']['shadowDescriptor']==frame['copiedPlacementCalls']['shadowDescriptor']
  else:assert frame['shadowQueries']==[] and frame['descriptorCalls']['shadow']=={} and frame['clones']['shadowDescriptor']==0
 if mode=='mapped':assert capture['restored']=={'savedMode':'shadow-maps','activeBytes':8388608}
 for metric in ['uniqueDescriptorCount','repeatedDescriptors','dominantOwnerCount','shadowUniqueQueriedOwnerCount','shadowDominantUniqueQueriedOwners']:assert summary['countAudits'][mode]['counts'][metric]==stats([f[metric] for f in frames])
with tarfile.open(base/'cpu-diagnostic-probes.tar.gz') as archive:
 members=archive.getmembers();assert len(members)==6
 for member in members:
  assert member.name==Path(member.name).name;path=Path('/tmp')/member.name;assert archive.extractfile(member).read()==path.read_bytes()
  if path.suffix in ['.js','.mjs','.cjs']:subprocess.run(['node','--check',str(path)],capture_output=True,check=True)
  else:ast.parse(path.read_text())
manifest=json.loads((base/'manifest.json').read_text())
for item in manifest['files']:
 data=(base/item['path']).read_bytes();assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'],item['path']
doc=root/'docs/plans/holtburger-3d-world-particle-performance-investigation.md'
for target in re.findall(r'\]\(([^)]+)\)',doc.read_text()):
 if not target.startswith(('http:','https:','#')):assert (doc.parent/target.split('#')[0]).exists(),target
assert all(line==line.rstrip() for line in doc.read_text().splitlines())
print(json.dumps({'productionWindows':len(trials),'sampledProfilesRecomputed':len(summary['profiles']),'auditFrames':600,'dominantOwnersInBothShadowCascadesEveryAuditedFrame':206,'savedAndActiveOriginalShadowSetting':'verified','artifactHashes':len(manifest['files']),'sourceSyntaxAndHashes':'pass','docLinksAndWhitespace':'pass'}))
