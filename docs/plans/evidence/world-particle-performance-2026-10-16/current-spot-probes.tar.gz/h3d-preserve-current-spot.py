from pathlib import Path
import gzip,hashlib,io,json,statistics,tarfile
root=Path('/home/me/code/holtburger');base=root/'docs/plans/evidence/world-particle-performance-2026-10-16';m=json.loads((base/'manifest.json').read_text());removed=set(m['sanitization']['removedKeys'])
def clean(v):
 if isinstance(v,list):return [clean(x)for x in v]
 if isinstance(v,dict):
  out={k:clean(x)for k,x in v.items()if k not in removed}
  if 'consoleMessages'in out:out['consoleMessages']=[{'level':x['level'],'count':x.get('count',1)}for x in v['consoleMessages']]
  return out
 return v
def packed(v):return(json.dumps(v,indent=2)+'\n').encode()
def digest(v):return hashlib.sha256(v).hexdigest()
def add(name,data,kind,sources):
 (base/name).write_bytes(data);m['files']=[f for f in m['files']if f['path']!=name]+[{'path':name,'bytes':len(data),'sha256':digest(data),'kind':kind,'sources':sources}]
def stats(v):return{'median':statistics.median(v),'min':min(v),'max':max(v)}
r=clean(json.loads(Path('/tmp/h3d-current-spot.json').read_text()));assert len(r['trials'])==5 and not r['context']['diagnosticGlobalsPresent']
assert all(t['camera']['position']==r['context']['camera']['position']for t in r['trials'])
sel=lambda t:t['snapshot']['diagnostics']['renderer']['selectionMetrics']
assert all(sel(t)['portalSelectedCrossingCount']==0 and sel(t)['portalSelectedScopeCount']==1 for t in r['trials'])
getters={'frameWorkMs':lambda t:t['snapshot']['meanFrameWorkMs'],'rendererCpuMs':lambda t:t['snapshot']['diagnostics']['renderer']['profile']['cpu']['mean']['totalMs'],'particleGpuMs':lambda t:t['snapshot']['diagnostics']['renderer']['profile']['gpu']['mean']['particleMs'],'gpuMs':lambda t:t['snapshot']['diagnostics']['renderer']['profile']['gpu']['mean']['totalMs'],'observedFps':lambda t:t['snapshot']['sampledFrameCount']*1000/t['windowMs'],'visibleDynamicEntities':lambda t:sel(t)['visibleDynamicEntityCount'],'particleBatches':lambda t:sel(t)['submittedParticleBatchCount'],'particleInstances':lambda t:sel(t)['submittedParticleInstanceCount']}
assets={str(p.relative_to(root)):digest(p.read_bytes())for p in (root/'apps/holtburger-3d/dist/assets').glob('*.js')}
s={'date':'2026-10-16','status':'Current saved character location checked after user repositioning; ordinary production renderer, no shader modification.','context':r['context'],'method':'Five 4s production profile windows after 10s settling, native Radeon 780M GLES. No V8 sampling, draw hooks, readbacks, build or heavy analysis during measurement. Profiling disabled before disconnect.','timing':{k:stats([f(t)for t in r['trials']])for k,f in getters.items()},'portal':{'selectedScopes':1,'selectedCrossings':0,'constantAcrossAllFiveWindows':True},'positionStableAcrossWindows':True,'servedProductionAssets':assets,'assessment':'Useful heavier particle baseline than the preceding lighter location. Zero selected portal crossings offers a separate exact no-exit shader-admission opportunity without two-way draw expansion. This control has not yet been implemented or measured at this spot.','limits':['Different location/camera/population/viewport from earlier captures; cross-view timing is context, not causal performance evidence.','Records host camera-path position and viewport, not complete rendered view/projection matrices or a guarantee of matching the user camera framing.','No dominant-mesh owner/draw census or numeric image footprint measured in this ordinary production check.','One selected scope and zero selected crossings describe this view only; no doorway/boundary or movement validation.','No visual acceptance check or production source edit.']}
add('current-spot-trials.json.gz',gzip.compress(packed(r),mtime=0),'sanitized current-location ordinary production GPU windows',['h3d-current-spot.json'])
add('current-spot-summary.json',packed(s),'current-location particle workload, stable host camera-path position and zero-crossing observation',['current-spot-trials.json.gz'])
buf=io.BytesIO();names=['h3d-current-spot-probe.mjs','h3d-preserve-current-spot.py','h3d-validate-current-spot.py']
with tarfile.open(fileobj=buf,mode='w')as archive:
 for name in names:
  data=(Path('/tmp')/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
add('current-spot-probes.tar.gz',gzip.compress(buf.getvalue(),mtime=0),'current-location production probe and evidence tools',names)
m['currentSpot']={'summary':'current-spot-summary.json','windows':5,'productionSourceModified':False}
(base/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'artifacts':len(m['files']),'bytes':sum(f['bytes']for f in m['files']),'timing':s['timing'],'position':r['context']['camera']['position']}))
