from pathlib import Path
import gzip,hashlib,json,statistics
root=Path.cwd();base=root/'docs/plans/evidence/world-particle-performance-2026-10-16';m=json.loads((base/'manifest.json').read_text())
for f in m['files']:
 b=(base/f['path']).read_bytes();assert len(b)==f['bytes']and hashlib.sha256(b).hexdigest()==f['sha256'],f['path']
r=json.loads(gzip.decompress((base/'current-spot-trials.json.gz').read_bytes()));s=json.loads((base/'current-spot-summary.json').read_text())
assert len(r['trials'])==5 and not r['context']['diagnosticGlobalsPresent']
for t in r['trials']:
 assert t['windowMs']>=4000 and t['snapshot']['sampledFrameCount']>0
 assert t['camera']['position']==r['context']['camera']['position']
 v=t['snapshot']['diagnostics']['renderer']['selectionMetrics'];assert v['portalSelectedScopeCount']==1 and v['portalSelectedCrossingCount']==0
assert statistics.median([t['snapshot']['diagnostics']['renderer']['profile']['gpu']['mean']['particleMs']for t in r['trials']])==s['timing']['particleGpuMs']['median']
for path,digest in s['servedProductionAssets'].items():assert hashlib.sha256((root/path).read_bytes()).hexdigest()==digest,path
print(json.dumps({'ok':True,'artifacts':len(m['files']),'windows':5,'positionStable':True,'selectedPortalCrossings':0}))
