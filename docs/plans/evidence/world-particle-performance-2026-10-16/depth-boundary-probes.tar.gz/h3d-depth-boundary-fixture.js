({predicate, radius}) => {
 const width=96,height=80;
 const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;
 const gl=canvas.getContext('webgl2',{antialias:false,alpha:false});
 if(!gl)throw Error('WebGL2 unavailable');
 if(!gl.getExtension('EXT_color_buffer_float'))throw Error('Float color unavailable');
 const debug=gl.getExtension('WEBGL_debug_renderer_info');
 const renderer=debug?gl.getParameter(debug.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER);
 const range=Array.from(gl.getParameter(gl.DEPTH_RANGE));
 if(range[0]!==0||range[1]!==1)throw Error('Non-default depth range');
 function compile(type,source){const s=gl.createShader(type);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s;}
 function program(vs,fs){const p=gl.createProgram();const a=compile(gl.VERTEX_SHADER,vs),b=compile(gl.FRAGMENT_SHADER,fs);gl.attachShader(p,a);gl.attachShader(p,b);gl.linkProgram(p);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(p));gl.deleteShader(a);gl.deleteShader(b);return p;}
 const vertex=`#version 300 es
 precision highp float;
 layout(location=0) in vec4 aClip;
 uniform float uOffset;
 out highp vec2 vClipDepth;
 void main(){gl_Position=aClip;gl_Position.z+=uOffset*gl_Position.w;vClipDepth=gl_Position.zw;}`;
 const portal=program(vertex,`#version 300 es
 precision highp float; void main(){}`);
 const fullVertex=`#version 300 es
 void main(){vec2 p=gl_VertexID==0?vec2(-1.,-1.):gl_VertexID==1?vec2(3.,-1.):vec2(-1.,3.);gl_Position=vec4(p,0.,1.);}`;
 // Production frontier format and finite-depth reduction expression, isolated from traversal.
 const reduce=program(fullVertex,`#version 300 es
 precision highp float;uniform highp sampler2D uFrontierDepth;
 void main(){float z=texelFetch(uFrontierDepth,ivec2(gl_FragCoord.xy),0).r;if(z==1.)discard;gl_FragDepth=z*0.5;}`);
 function fragment(depth){return `#version 300 es
 precision highp float;precision highp int;
 in highp vec2 vClipDepth;
 ${predicate.replace('gl_FragCoord.z * 0.5',`${depth} * 0.5`)}
 out vec4 color;
 void main(){ivec2 pixel=ivec2(gl_FragCoord.xy);color=vec4(portalDeferredFragmentVisible()?1.:0.,${depth}*0.5,texelFetch(uPortalEnvelopeDepth,pixel,0).r,1.);}`;}
 const builtin=program(vertex,fragment('gl_FragCoord.z'));
 const reconstructed=program(vertex,fragment('(vClipDepth.x/vClipDepth.y*0.5+0.5)'));
 function discardFragment(depth){return `#version 300 es
 precision highp float;precision highp int;
 in highp vec2 vClipDepth;
 ${predicate.replace('gl_FragCoord.z * 0.5',`${depth} * 0.5`)}
 out vec4 color;
 void main(){if(!portalDeferredFragmentVisible())discard;color=vec4(1.);}`;}
 const plainVertex=vertex.replace('out highp vec2 vClipDepth;','').replace('vClipDepth=gl_Position.zw;','');
 const discardBuiltin=program(plainVertex,discardFragment('gl_FragCoord.z'));
 const discardReconstructed=program(vertex,discardFragment('(vClipDepth.x/vClipDepth.y*0.5+0.5)'));
 function texture(format){const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);gl.texStorage2D(gl.TEXTURE_2D,1,format,width,height);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);return t;}
 function target(t,attachment){const f=gl.createFramebuffer();gl.bindFramebuffer(gl.FRAMEBUFFER,f);gl.framebufferTexture2D(gl.FRAMEBUFFER,attachment,gl.TEXTURE_2D,t,0);if(attachment===gl.DEPTH_ATTACHMENT){gl.drawBuffers([gl.NONE]);gl.readBuffer(gl.NONE);}if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw Error('Incomplete target');return f;}
 const frontier=texture(gl.DEPTH_COMPONENT24),frontierTarget=target(frontier,gl.DEPTH_ATTACHMENT);
 const envelope=texture(gl.DEPTH_COMPONENT32F),envelopeTarget=target(envelope,gl.DEPTH_ATTACHMENT);
 const output=texture(gl.RGBA32F),outputTarget=target(output,gl.COLOR_ATTACHMENT0);
 const colorOutput=texture(gl.RGBA8),colorOutputTarget=target(colorOutput,gl.COLOR_ATTACHMENT0);
 const sceneDepth=texture(gl.DEPTH_COMPONENT24);
 for(const f of [outputTarget,colorOutputTarget]){gl.bindFramebuffer(gl.FRAMEBUFFER,f);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.TEXTURE_2D,sceneDepth,0);if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw Error('Incomplete scene-depth target');}
 gl.depthMask(true);gl.clearDepth(1);gl.clear(gl.DEPTH_BUFFER_BIT);
 const vao=gl.createVertexArray();gl.bindVertexArray(vao);
 const vertices=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,vertices);gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,4,gl.FLOAT,false,0,0);
 const metadata=new Uint8Array(16384);new Uint32Array(metadata.buffer,64+255*32,8).set([0,0,0,0,width,height,0,0]);
 const ubo=gl.createBuffer();gl.bindBuffer(gl.UNIFORM_BUFFER,ubo);gl.bufferData(gl.UNIFORM_BUFFER,metadata,gl.STATIC_DRAW);gl.bindBufferBase(gl.UNIFORM_BUFFER,0,ubo);
 for(const p of [builtin,reconstructed,discardBuiltin,discardReconstructed]){
  const block=gl.getUniformBlockIndex(p,'PortalScopeAtlasMetadata');if(block===gl.INVALID_INDEX)throw Error('Metadata inactive');
  if(gl.getActiveUniformBlockParameter(p,block,gl.UNIFORM_BLOCK_DATA_SIZE)!==16384)throw Error('Metadata size changed');
  gl.uniformBlockBinding(p,block,0);gl.useProgram(p);gl.uniform1ui(gl.getUniformLocation(p,'uPortalRenderDomain'),0);gl.uniform1i(gl.getUniformLocation(p,'uPortalEnvelopeDepth'),1);
 }
 gl.viewport(0,0,width,height);gl.disable(gl.CULL_FACE);gl.disable(gl.BLEND);gl.disable(gl.DITHER);gl.disable(gl.SCISSOR_TEST);
 function draw(p,offset){gl.useProgram(p);const u=gl.getUniformLocation(p,'uOffset');if(u!==null)gl.uniform1f(u,offset);gl.bindVertexArray(vao);gl.drawArrays(gl.TRIANGLES,0,3);}
 function setEnvelope(mode){
  gl.bindFramebuffer(gl.FRAMEBUFFER,envelopeTarget);gl.depthMask(true);gl.clearDepth(mode==='unbounded'?1:0);gl.clear(gl.DEPTH_BUFFER_BIT);
  if(mode!=='finite'&&mode!=='window')return;
  gl.bindFramebuffer(gl.FRAMEBUFFER,frontierTarget);gl.clearDepth(1);gl.clear(gl.DEPTH_BUFFER_BIT);gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.ALWAYS);
  if(mode==='window'){gl.enable(gl.SCISSOR_TEST);gl.scissor(22,17,45,42);}
  draw(portal,0);gl.disable(gl.SCISSOR_TEST);
  gl.bindFramebuffer(gl.FRAMEBUFFER,envelopeTarget);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,frontier);gl.useProgram(reduce);gl.uniform1i(gl.getUniformLocation(reduce,'uFrontierDepth'),0);gl.drawArrays(gl.TRIANGLES,0,3);
  gl.disable(gl.DEPTH_TEST);
 }
 function read(p,offset,depthTest){gl.bindFramebuffer(gl.FRAMEBUFFER,outputTarget);gl.depthMask(false);gl.depthFunc(gl.LEQUAL);(depthTest?gl.enable:gl.disable).call(gl,gl.DEPTH_TEST);gl.clearBufferfv(gl.COLOR,0,new Float32Array(4));gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,envelope);draw(p,offset);const pixels=new Float32Array(width*height*4);gl.readPixels(0,0,width,height,gl.RGBA,gl.FLOAT,pixels);return pixels;}
 function readDiscard(p,offset,depthTest){gl.bindFramebuffer(gl.FRAMEBUFFER,colorOutputTarget);gl.depthMask(false);gl.depthFunc(gl.LEQUAL);(depthTest?gl.enable:gl.disable).call(gl,gl.DEPTH_TEST);gl.clearBufferfv(gl.COLOR,0,new Float32Array(4));gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,envelope);draw(p,offset);const pixels=new Uint8Array(width*height*4);gl.readPixels(0,0,width,height,gl.RGBA,gl.UNSIGNED_BYTE,pixels);return pixels;}
 function triangle(ndc,ws,zs){return new Float32Array(ndc.flatMap(([x,y],i)=>[x*ws[i],y*ws[i],zs[i]*ws[i],ws[i]]));}
 const shape=[[-.95,-.9],[.94,-.84],[-.65,.93]];
 const cases=[
  {name:'constant-mid',ws:[1,1,1],zs:[.25,.25,.25]},
  {name:'constant-far',ws:[1,1,1],zs:[.9999,.9999,.9999]},
  {name:'sloping',ws:[1,1,1],zs:[-.7,.85,.1]},
  {name:'perspective',ws:[.25,20,1000],zs:[-.9,.95,.3]},
  {name:'wide-w-range',ws:[.001,1,100000],zs:[-.999,.9999,.1]},
  {name:'near-clipped',ws:[.2,10,30],zs:[-1.5,.8,.1]},
  {name:'far-clipped',ws:[1,10,500],zs:[.4,1.3,.9]},
  {name:'eye-crossing',ws:[-.3,2,20],zs:[0,.8,-.6]},
  {name:'steep-narrow',ws:[.1,100,2],zs:[-.95,.999,.5],shape:[[-.04,-.98],[.035,-.95],[.012,.98]]},
 ];
 const offsets=[-(2**-16),-(2**-20),-(2**-22),-(2**-24),-(2**-26),0,2**-26,2**-24,2**-22,2**-20,2**-16];
 const records=[];let firstDifference=null;
 for(const c of cases)for(const shift of [0,.0078125,-.01953125]){
  const positions=triangle((c.shape||shape).map(([x,y])=>[x+shift,y-shift]),c.ws,c.zs);
  gl.bindBuffer(gl.ARRAY_BUFFER,vertices);gl.bufferData(gl.ARRAY_BUFFER,positions,gl.STREAM_DRAW);
  for(const depthTest of [true,false])for(const mode of ['finite','window','unbounded','uncovered']){
   setEnvelope(mode);
   for(const offset of mode==='finite'||mode==='window'?offsets:[0]){
    const a=read(builtin,offset,depthTest),b=read(reconstructed,offset,depthTest);
    const da=readDiscard(discardBuiltin,offset,depthTest),db=readDiscard(discardReconstructed,offset,depthTest);
    let discardDifferences=0,originalMaskMismatches=0,candidateMaskMismatches=0;
    for(let i=0;i<da.length;i+=4){if(da[i]!==db[i])discardDifferences++;if((da[i]===255)!==(a[i]===1))originalMaskMismatches++;if((db[i]===255)!==(b[i]===1))candidateMaskMismatches++;}
    let covered=0,coverageDifferences=0,differences=0,acceptedOriginal=0,acceptedCandidate=0,extraVisible=0,extraHidden=0,maxEncodedError=0;
    for(let i=0;i<a.length;i+=4){
     if(a[i+3]!==b[i+3])coverageDifferences++;
     if(a[i+3]===0&&b[i+3]===0)continue;
     covered++;maxEncodedError=Math.max(maxEncodedError,Math.abs(a[i+1]-b[i+1]));
     if(a[i]===1)acceptedOriginal++;if(b[i]===1)acceptedCandidate++;
     if(a[i]!==b[i]){differences++;if(a[i]<b[i])extraVisible++;else extraHidden++;
      if(!firstDifference)firstDifference={name:c.name,shift,mode,offset,depthTest,pixel:[(i/4)%width,Math.floor(i/4/width)],builtin:Array.from(a.slice(i,i+4)),candidate:Array.from(b.slice(i,i+4)),clipPositions:Array.from(positions)};
     }
    }
    records.push({discardDifferences,originalMaskMismatches,candidateMaskMismatches,depthTest,name:c.name,shift,mode,offset,covered,coverageDifferences,differences,acceptedOriginal,acceptedCandidate,extraVisible,extraHidden,maxEncodedError});
   }
  }
 }
 const error=gl.getError();if(error!==gl.NO_ERROR)throw Error('WebGL error '+error);
 const summary={discardDecisionDifferences:records.reduce((n,r)=>n+r.discardDifferences,0),originalMaskMismatches:records.reduce((n,r)=>n+r.originalMaskMismatches,0),candidateMaskMismatches:records.reduce((n,r)=>n+r.candidateMaskMismatches,0),comparisons:records.length,coveredSamplePairs:records.reduce((n,r)=>n+r.covered,0),comparisonFailures:records.filter(r=>r.differences>0).length,coverageDifferences:records.reduce((n,r)=>n+r.coverageDifferences,0),decisionDifferences:records.reduce((n,r)=>n+r.differences,0),extraVisible:records.reduce((n,r)=>n+r.extraVisible,0),extraHidden:records.reduce((n,r)=>n+r.extraHidden,0),maxEncodedError:Math.max(...records.map(r=>r.maxEncodedError))};
 return {renderer,version:gl.getParameter(gl.VERSION),width,height,depthRange:range,gutterRadius:radius,summary,firstDifference,records,shaders:{vertex,original:fragment('gl_FragCoord.z'),candidate:fragment('(vClipDepth.x/vClipDepth.y*0.5+0.5)'),plainVertex,discardOriginal:discardFragment('gl_FragCoord.z'),discardCandidate:discardFragment('(vClipDepth.x/vClipDepth.y*0.5+0.5)')},limitations:['Synthetic isolated predicate test, not full portal traversal or particle material/motion pipeline.','Frontier D24 rasterization and finite-depth D32F reduction mirror production formats and expression.','No GPU timings; repeated readback intentionally allowed on this correctness-only target.','Shared test vertex stage emits a varying in both programs; original linker can remove the unused output.']};
}
