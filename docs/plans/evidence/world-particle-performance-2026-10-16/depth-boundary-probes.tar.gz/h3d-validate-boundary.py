from pathlib import Path
import gzip,hashlib,json,subprocess,tarfile
root=Path.cwd();base=root/'docs/plans/evidence/world-particle-performance-2026-10-16';summary=json.loads((base/'depth-boundary-summary.json').read_text());runs=[]
for i in range(1,4):
 x=json.loads(gzip.decompress((base/f'depth-boundary-run-{i}.json.gz').read_bytes()));runs.append(x)
 records=x['records'];assert len(records)==1296
 assert x['renderer'].endswith('OpenGL ES 3.2)')
 assert x['depthRange']==[0,1]
 assert len({(r['name'],r['shift'],r['depthTest'],r['mode'],r['offset']) for r in records})==len(records)
 for r in records:
  assert r['coverageDifferences']==r['originalMaskMismatches']==r['candidateMaskMismatches']==0
  assert r['discardDifferences']==r['differences']==r['extraVisible']+r['extraHidden']
  assert r['acceptedOriginal']-r['extraHidden']+r['extraVisible']==r['acceptedCandidate']
  if r['mode']=='unbounded':assert r['acceptedOriginal']==r['acceptedCandidate']==r['covered']
  if r['mode']=='uncovered':assert r['acceptedOriginal']==r['acceptedCandidate']==0
 for enabled in [True,False]:assert len([r for r in records if r['depthTest']==enabled])==648
 for enabled_record in [r for r in records if r['depthTest']]:
  match=[r for r in records if not r['depthTest'] and all(r[k]==enabled_record[k] for k in ['name','shift','mode','offset'])];assert len(match)==1
  assert {k:v for k,v in match[0].items() if k!='depthTest'}=={k:v for k,v in enabled_record.items() if k!='depthTest'}
 calculated={'discardDecisionDifferences':sum(r['discardDifferences'] for r in records),'originalMaskMismatches':sum(r['originalMaskMismatches'] for r in records),'candidateMaskMismatches':sum(r['candidateMaskMismatches'] for r in records),'comparisons':len(records),'coveredSamplePairs':sum(r['covered'] for r in records),'comparisonFailures':sum(r['differences']>0 for r in records),'coverageDifferences':sum(r['coverageDifferences'] for r in records),'decisionDifferences':sum(r['differences'] for r in records),'extraVisible':sum(r['extraVisible'] for r in records),'extraHidden':sum(r['extraHidden'] for r in records),'maxEncodedError':max(r['maxEncodedError'] for r in records)}
 assert calculated==x['summary']==summary['method']['summaryPerRun']
 for name,digest in x['sourceHashes'].items():assert hashlib.sha256((root/'apps/holtburger-3d/src/lib/game/renderer'/name).read_bytes()).hexdigest()==digest
assert all(r['records']==runs[0]['records'] for r in runs)
for case in summary['representativeCases']:assert case in runs[0]['records']
first=summary['firstCounterexample'];assert first['builtin'][0]==1 and first['candidate'][0]==0
assert first['builtin'][1]<first['builtin'][2] and first['candidate'][1]==first['candidate'][2]
with tarfile.open(base/'depth-boundary-probes.tar.gz') as archive:
 members=archive.getmembers();assert len(members)==3
 for member in members:
  assert member.name==Path(member.name).name
  path=Path('/tmp')/member.name;assert archive.extractfile(member).read()==path.read_bytes()
  
  if path.suffix in ['.js','.cjs','.mjs']:subprocess.run(['node','--check',str(path)],check=True,capture_output=True)
  else:
   import ast
   ast.parse(path.read_text())
assert json.loads((base/'readback-depth-summary.json').read_text())['boundaryFollowup']['candidateApprovedForProduction'] is False
print(json.dumps({'freshRuns':len(runs),'totalCaseComparisons':sum(len(r['records']) for r in runs),'repeatedRecords':'exact match','independentDiscardMasks':'match diagnostic decisions','coverageAndEnvelopeControls':'pass','bothSceneDepthStates':'identical results','sourceHashesAndSyntax':'pass','originalVsCandidate':'FAIL as documented; candidate rejected'}))
