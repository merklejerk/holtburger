() => {
    const p=WebGL2RenderingContext.prototype;
    const shaderSource=p.shaderSource,link=p.linkProgram,use=p.useProgram,getLocation=p.getUniformLocation,draw=p.drawElementsInstanced;
    const sources=new WeakMap(),pairs=new WeakMap(),locations=new WeakMap(),logical=new WeakMap(),physical=new WeakMap();
    const state=window.__discardAudit={mode:'normal',programs:[],draws:0,dominantDraws:0,blendSignatures:{},unsupported:[],firstDraw:null};
    const methods=['uniform1f','uniform1i','uniform1ui','uniform2f','uniform2i','uniform2ui','uniform3f','uniform3i','uniform3ui','uniform4f','uniform4i','uniform4ui','uniform1fv','uniform2fv','uniform3fv','uniform4fv','uniform1iv','uniform2iv','uniform3iv','uniform4iv','uniform1uiv','uniform2uiv','uniform3uiv','uniform4uiv','uniformMatrix2fv','uniformMatrix3fv','uniformMatrix4fv','uniformMatrix2x3fv','uniformMatrix2x4fv','uniformMatrix3x2fv','uniformMatrix3x4fv','uniformMatrix4x2fv','uniformMatrix4x3fv'];
    const originals=Object.fromEntries(methods.map(name=>[name,p[name]]));
    const locationFor=(gl,pair,name,target)=>{
        if(target===pair.normal)return pair.normalLocations.get(name);
        if(!pair.altLocations.has(name))pair.altLocations.set(name,getLocation.call(gl,pair.alt,name));
        return pair.altLocations.get(name);
    };
    p.shaderSource=function(shader,text){sources.set(shader,text);return shaderSource.call(this,shader,text);};
    p.linkProgram=function(program){
        link.call(this,program);
        const shaders=this.getAttachedShaders(program),fs=shaders.find(s=>this.getShaderParameter(s,this.SHADER_TYPE)===this.FRAGMENT_SHADER);
        const text=fs && sources.get(fs);
        if(!text?.includes('in float vTranslucency;') || !text.includes('bool portalDeferredFragmentVisible()'))return;
        let alternative=text.replace('if (!portalDeferredFragmentVisible()) discard;','bool diagnosticVisible=portalDeferredFragmentVisible();')
            .replace('if (color.a < uAlphaTest) discard;','if (color.a < uAlphaTest) color=vec4(0.0);')
            .replace('outColor = encodeTransparentCanvasEmission(color, uCanvasEmissionMode);','if(!diagnosticVisible)color=vec4(0.0);\noutColor = encodeTransparentCanvasEmission(color, uCanvasEmissionMode);');
        if(alternative===text || /\bdiscard\s*;/.test(alternative))throw new Error('Particle discard replacement incomplete');
        const alternateShader=this.createShader(this.FRAGMENT_SHADER);shaderSource.call(this,alternateShader,alternative);this.compileShader(alternateShader);
        if(!this.getShaderParameter(alternateShader,this.COMPILE_STATUS))throw new Error(this.getShaderInfoLog(alternateShader));
        const alt=this.createProgram(),vs=shaders.find(s=>this.getShaderParameter(s,this.SHADER_TYPE)===this.VERTEX_SHADER);
        this.attachShader(alt,vs);this.attachShader(alt,alternateShader);link.call(this,alt);this.deleteShader(alternateShader);
        if(!this.getProgramParameter(alt,this.LINK_STATUS))throw new Error(this.getProgramInfoLog(alt));
        const block=this.getUniformBlockIndex(alt,'PortalScopeAtlasMetadata');this.uniformBlockBinding(alt,block,0);
        const pair={normal:program,alt,normalLocations:new Map(),altLocations:new Map(),values:new Map(),lastPhysical:null};pairs.set(program,pair);pairs.set(alt,pair);
        state.programs.push({originalBytes:text.length,alternateBytes:alternative.length,remainingDiscardStatements:0});
    };
    p.getUniformLocation=function(program,name){
        const location=getLocation.call(this,program,name),pair=pairs.get(program);
        if(location && pair && program===pair.normal){locations.set(location,{pair,name});pair.normalLocations.set(name,location);}
        return location;
    };
    p.useProgram=function(program){
        const pair=pairs.get(program),target=pair?(state.mode==='transparent-mask'?pair.alt:pair.normal):program;
        logical.set(this,pair?pair.normal:program);physical.set(this,target);use.call(this,target);
        if(pair && pair.lastPhysical!==target){
            for(const [name,value] of pair.values)originals[value.method].call(this,locationFor(this,pair,name,target),...value.args);
            pair.lastPhysical=target;
        }
    };
    for(const name of methods)p[name]=function(location,...args){
        const info=location && locations.get(location);
        if(!info)return originals[name].call(this,location,...args);
        const copied=args.map(value=>ArrayBuffer.isView(value)?Array.from(value):value);
        info.pair.values.set(info.name,{method:name,args:copied});
        const target=logical.get(this)===info.pair.normal?physical.get(this):info.pair.normal;
        return originals[name].call(this,locationFor(this,info.pair,info.name,target),...args);
    };
    const blendState=new WeakMap();
    const blendOf=gl=>{
        if(!blendState.has(gl))blendState.set(gl,{enabled:gl.isEnabled(gl.BLEND),src:gl.getParameter(gl.BLEND_SRC_RGB),dst:gl.getParameter(gl.BLEND_DST_RGB),srcA:gl.getParameter(gl.BLEND_SRC_ALPHA),dstA:gl.getParameter(gl.BLEND_DST_ALPHA),eq:gl.getParameter(gl.BLEND_EQUATION_RGB),eqA:gl.getParameter(gl.BLEND_EQUATION_ALPHA)});
        return blendState.get(gl);
    };
    for(const name of ['enable','disable','blendFunc','blendFuncSeparate','blendEquation','blendEquationSeparate']){
        const original=p[name];p[name]=function(...args){
            const b=blendOf(this);
            if(name==='enable' && args[0]===this.BLEND)b.enabled=true;
            if(name==='disable' && args[0]===this.BLEND)b.enabled=false;
            if(name==='blendFunc')Object.assign(b,{src:args[0],dst:args[1],srcA:args[0],dstA:args[1]});
            if(name==='blendFuncSeparate')Object.assign(b,{src:args[0],dst:args[1],srcA:args[2],dstA:args[3]});
            if(name==='blendEquation')Object.assign(b,{eq:args[0],eqA:args[0]});
            if(name==='blendEquationSeparate')Object.assign(b,{eq:args[0],eqA:args[1]});
            return original.apply(this,args);
        };
    }
    p.drawElementsInstanced=function(mode,count,type,offset,instances){
        const pair=pairs.get(logical.get(this));
        if(pair){
            state.draws++;if(count===330)state.dominantDraws++;
            const b=blendOf(this),key=JSON.stringify(b);state.blendSignatures[key]=(state.blendSignatures[key]??0)+1;
            const neutral=[this.ONE,this.ONE_MINUS_SRC_ALPHA,this.ONE_MINUS_SRC_COLOR];
            if(!b.enabled || b.eq!==this.FUNC_ADD || b.eqA!==this.FUNC_ADD || !neutral.includes(b.dst) || !neutral.includes(b.dstA)) {
                state.unsupported.push({count,blend:{...b}});if(state.mode==='transparent-mask')throw new Error('Zero-output masking does not preserve this blend policy');
            }
            const canvas=pair.values.get('uCanvasEmissionMode')?.args[0];
            if(canvas!==0)throw new Error('Unexpected canvas emission encoding in world particles');
            if(!state.firstDraw)state.firstDraw={canvasEmission:canvas,alphaTest:pair.values.get('uAlphaTest')?.args[0]};
        }
        return draw.call(this,mode,count,type,offset,instances);
    };
}
