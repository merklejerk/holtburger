#!/usr/bin/env node

import { spawn } from "node:child_process";
import { writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { resolve } from "node:path";

import { runClientStreamingProbe } from "file:///home/me/code/holtburger/apps/holtburger-3d/scripts/client-streaming-probe.mjs";
import { createCdpClient } from "file:///home/me/code/holtburger/apps/holtburger-3d/scripts/cdp-client.mjs";
import { stringifyRedactedProbeReport } from "file:///home/me/code/holtburger/apps/holtburger-3d/scripts/live-client-probe-report.mjs";

const PASSIVE_CAMERA_SETTLE_MS = 5_000;
const PASSIVE_CAMERA_INPUT_COUNT = 40;
const PASSIVE_CAMERA_INPUT_INTERVAL_MS = 25;
const PRECISE_JUMP_SWEEP_INPUT_COUNT = 120;
const PRECISE_JUMP_SWEEP_INPUT_INTERVAL_MS = 5;
const PROFILE_SETTLE_MS = 10_000;
const PROFILE_WINDOW_MS = 10_000;
const WORLD_READY_NOTICE = "World ready";

const appRoot = '/home/me/code/holtburger/apps/holtburger-3d';
const account = requiredEnvironment("HOLTBURGER_PROBE_ACCOUNT");
const password = requiredEnvironment("HOLTBURGER_PROBE_PASSWORD");
const mode = probeMode(process.env.HOLTBURGER_PROBE_MODE);
const performanceInstrumentationEnabled =
	process.env.HOLTBURGER_PROBE_PROFILE_INSTRUMENTATION !== "0";
if (
	mode !== "teleport" &&
	process.env.HOLTBURGER_PROBE_TELEPORT_SEQUENCE !== undefined
) {
	throw new Error(`${mode} mode rejects HOLTBURGER_PROBE_TELEPORT_SEQUENCE.`);
}
let commands =
	mode === "teleport" && process.env.HOLTBURGER_PROBE_TELEPORT_SEQUENCE
		? parseCommands(process.env.HOLTBURGER_PROBE_TELEPORT_SEQUENCE)
		: null;
const timeoutMs = Number(process.env.HOLTBURGER_PROBE_TIMEOUT_MS ?? "45000");

if (!Number.isSafeInteger(timeoutMs) || timeoutMs <= 0) {
	throw new Error("HOLTBURGER_PROBE_TIMEOUT_MS must be a positive integer.");
}
// Resolve streaming configuration before launching or moving a live character.
const streamingOptions =
	mode === "streaming"
		? {
				startCommand:
					process.env.HOLTBURGER_STREAMING_START ?? "@tele 33.17s 72.85e",
				startLandblock:
					process.env.HOLTBURGER_STREAMING_START_LANDBLOCK ?? "0xda55ffff",
				destination:
					process.env.HOLTBURGER_STREAMING_DESTINATION ?? "0xda56ffff",
				trials: Number(process.env.HOLTBURGER_STREAMING_TRIALS ?? "1"),
				settleMs: 10000,
				moveMs: 2000,
				drainMs: 4000,
				timeoutMs,
				profile: performanceInstrumentationEnabled,
				outputPrefix: requiredEnvironment("HOLTBURGER_STREAMING_OUTPUT"),
				reportPath: requiredEnvironment("HOLTBURGER_PROBE_REPORT"),
			}
		: null;
if (
	streamingOptions !== null &&
	(!Number.isSafeInteger(streamingOptions.trials) ||
		streamingOptions.trials < 1)
) {
	throw new Error(
		"HOLTBURGER_STREAMING_TRIALS must be a positive safe integer.",
	);
}
const child = spawn(process.execPath, ["/tmp/h3d-production-launch.mjs", "client", "--release", "--vite-port", "0", "--account", account, "--password", password, `--debug=${performanceInstrumentationEnabled}`], { cwd: appRoot, env: {...process.env, HOLTBURGER_ELECTRON_REMOTE_DEBUGGING_PORT: "0"}, stdio: ["ignore", "pipe", "pipe"] });

let output = "";
for (const stream of [child.stdout, child.stderr]) {
	stream.on("data", (chunk) => {
		output += chunk.toString("utf8");
	});
}

let client;
const consoleMessages = new Map();
const hops = [];
try {
	const browserWebSocketUrl = await waitForDevToolsUrl(child, () => output);
	printReport({ stage: "devtools-endpoint" });
 const browserClient = await createCdpClient(browserWebSocketUrl);
 const gpuInfo = await browserClient.send("SystemInfo.getInfo");
 await writeFile("/tmp/h3d-gpu-info.json", JSON.stringify(gpuInfo));
 browserClient.close();
	const pageWebSocketUrl = await waitForPageWebSocketUrl(browserWebSocketUrl);
	printReport({ stage: "client-page-endpoint" });
	client = await createCdpClient(pageWebSocketUrl);
	client.on("Runtime.consoleAPICalled", (message) => {
		recordConsoleMessage({
			level: message.type,
			text: message.args
				.map((argument) => argument.value ?? argument.description ?? "")
				.join(" "),
		});
	});
	client.on("Runtime.exceptionThrown", (message) => {
		recordConsoleMessage({
			level: "exception",
			text:
				message.exceptionDetails.exception?.description ??
				message.exceptionDetails.text,
		});
	});
	await client.send("Runtime.enable");
	await installEvidenceCollector(client);
 await evaluate(client,"() => {\n    const p=WebGL2RenderingContext.prototype;\n    const shaderSource=p.shaderSource,link=p.linkProgram,use=p.useProgram,getLocation=p.getUniformLocation,draw=p.drawElementsInstanced;\n    const sources=new WeakMap(),pairs=new WeakMap(),locations=new WeakMap(),logical=new WeakMap(),physical=new WeakMap();\n    const state=window.__discardAudit={mode:'normal',programs:[],draws:0,dominantDraws:0,blendSignatures:{},unsupported:[],firstDraw:null};\n    const methods=['uniform1f','uniform1i','uniform1ui','uniform2f','uniform2i','uniform2ui','uniform3f','uniform3i','uniform3ui','uniform4f','uniform4i','uniform4ui','uniform1fv','uniform2fv','uniform3fv','uniform4fv','uniform1iv','uniform2iv','uniform3iv','uniform4iv','uniform1uiv','uniform2uiv','uniform3uiv','uniform4uiv','uniformMatrix2fv','uniformMatrix3fv','uniformMatrix4fv','uniformMatrix2x3fv','uniformMatrix2x4fv','uniformMatrix3x2fv','uniformMatrix3x4fv','uniformMatrix4x2fv','uniformMatrix4x3fv'];\n    const originals=Object.fromEntries(methods.map(name=>[name,p[name]]));\n    const locationFor=(gl,pair,name,target)=>{\n        if(target===pair.normal)return pair.normalLocations.get(name);\n        if(!pair.altLocations.has(name))pair.altLocations.set(name,getLocation.call(gl,pair.alt,name));\n        return pair.altLocations.get(name);\n    };\n    p.shaderSource=function(shader,text){sources.set(shader,text);return shaderSource.call(this,shader,text);};\n    p.linkProgram=function(program){\n        link.call(this,program);\n        const shaders=this.getAttachedShaders(program),fs=shaders.find(s=>this.getShaderParameter(s,this.SHADER_TYPE)===this.FRAGMENT_SHADER);\n        const text=fs && sources.get(fs);\n        if(!text?.includes('in float vTranslucency;') || !text.includes('bool portalDeferredFragmentVisible()'))return;\n        let alternative=text.replace('if (!portalDeferredFragmentVisible()) discard;','bool diagnosticVisible=portalDeferredFragmentVisible();')\n            .replace('if (color.a < uAlphaTest) discard;','if (color.a < uAlphaTest) color=vec4(0.0);')\n            .replace('outColor = encodeTransparentCanvasEmission(color, uCanvasEmissionMode);','if(!diagnosticVisible)color=vec4(0.0);\\noutColor = encodeTransparentCanvasEmission(color, uCanvasEmissionMode);');\n        if(alternative===text || /\\bdiscard\\s*;/.test(alternative))throw new Error('Particle discard replacement incomplete');\n        const alternateShader=this.createShader(this.FRAGMENT_SHADER);shaderSource.call(this,alternateShader,alternative);this.compileShader(alternateShader);\n        if(!this.getShaderParameter(alternateShader,this.COMPILE_STATUS))throw new Error(this.getShaderInfoLog(alternateShader));\n        const alt=this.createProgram(),vs=shaders.find(s=>this.getShaderParameter(s,this.SHADER_TYPE)===this.VERTEX_SHADER);\n        this.attachShader(alt,vs);this.attachShader(alt,alternateShader);link.call(this,alt);this.deleteShader(alternateShader);\n        if(!this.getProgramParameter(alt,this.LINK_STATUS))throw new Error(this.getProgramInfoLog(alt));\n        const block=this.getUniformBlockIndex(alt,'PortalScopeAtlasMetadata');this.uniformBlockBinding(alt,block,0);\n        const pair={normal:program,alt,normalLocations:new Map(),altLocations:new Map(),values:new Map(),lastPhysical:null};pairs.set(program,pair);pairs.set(alt,pair);\n        state.programs.push({originalBytes:text.length,alternateBytes:alternative.length,remainingDiscardStatements:0});\n    };\n    p.getUniformLocation=function(program,name){\n        const location=getLocation.call(this,program,name),pair=pairs.get(program);\n        if(location && pair && program===pair.normal){locations.set(location,{pair,name});pair.normalLocations.set(name,location);}\n        return location;\n    };\n    p.useProgram=function(program){\n        const pair=pairs.get(program),target=pair?(state.mode==='transparent-mask'?pair.alt:pair.normal):program;\n        logical.set(this,pair?pair.normal:program);physical.set(this,target);use.call(this,target);\n        if(pair && pair.lastPhysical!==target){\n            for(const [name,value] of pair.values)originals[value.method].call(this,locationFor(this,pair,name,target),...value.args);\n            pair.lastPhysical=target;\n        }\n    };\n    for(const name of methods)p[name]=function(location,...args){\n        const info=location && locations.get(location);\n        if(!info)return originals[name].call(this,location,...args);\n        const copied=args.map(value=>ArrayBuffer.isView(value)?Array.from(value):value);\n        info.pair.values.set(info.name,{method:name,args:copied});\n        const target=logical.get(this)===info.pair.normal?physical.get(this):info.pair.normal;\n        return originals[name].call(this,locationFor(this,info.pair,info.name,target),...args);\n    };\n    const blendState=new WeakMap();\n    const blendOf=gl=>{\n        if(!blendState.has(gl))blendState.set(gl,{enabled:gl.isEnabled(gl.BLEND),src:gl.getParameter(gl.BLEND_SRC_RGB),dst:gl.getParameter(gl.BLEND_DST_RGB),srcA:gl.getParameter(gl.BLEND_SRC_ALPHA),dstA:gl.getParameter(gl.BLEND_DST_ALPHA),eq:gl.getParameter(gl.BLEND_EQUATION_RGB),eqA:gl.getParameter(gl.BLEND_EQUATION_ALPHA)});\n        return blendState.get(gl);\n    };\n    for(const name of ['enable','disable','blendFunc','blendFuncSeparate','blendEquation','blendEquationSeparate']){\n        const original=p[name];p[name]=function(...args){\n            const b=blendOf(this);\n            if(name==='enable' && args[0]===this.BLEND)b.enabled=true;\n            if(name==='disable' && args[0]===this.BLEND)b.enabled=false;\n            if(name==='blendFunc')Object.assign(b,{src:args[0],dst:args[1],srcA:args[0],dstA:args[1]});\n            if(name==='blendFuncSeparate')Object.assign(b,{src:args[0],dst:args[1],srcA:args[2],dstA:args[3]});\n            if(name==='blendEquation')Object.assign(b,{eq:args[0],eqA:args[0]});\n            if(name==='blendEquationSeparate')Object.assign(b,{eq:args[0],eqA:args[1]});\n            return original.apply(this,args);\n        };\n    }\n    p.drawElementsInstanced=function(mode,count,type,offset,instances){\n        const pair=pairs.get(logical.get(this));\n        if(pair){\n            state.draws++;if(count===330)state.dominantDraws++;\n            const b=blendOf(this),key=JSON.stringify(b);state.blendSignatures[key]=(state.blendSignatures[key]??0)+1;\n            const neutral=[this.ONE,this.ONE_MINUS_SRC_ALPHA,this.ONE_MINUS_SRC_COLOR];\n            if(!b.enabled || b.eq!==this.FUNC_ADD || b.eqA!==this.FUNC_ADD || !neutral.includes(b.dst) || !neutral.includes(b.dstA)) {\n                state.unsupported.push({count,blend:{...b}});if(state.mode==='transparent-mask')throw new Error('Zero-output masking does not preserve this blend policy');\n            }\n            const canvas=pair.values.get('uCanvasEmissionMode')?.args[0];\n            if(canvas!==0)throw new Error('Unexpected canvas emission encoding in world particles');\n            if(!state.firstDraw)state.firstDraw={canvasEmission:canvas,alphaTest:pair.values.get('uAlphaTest')?.args[0]};\n        }\n        return draw.call(this,mode,count,type,offset,instances);\n    };\n}\n");
	await waitFor(
		client,
		`() => document.body?.innerText.includes("Choose a character")`,
		timeoutMs,
		"character selection",
	);
	const selectedCharacter = await evaluate(
		client,
		`() => {
			const character = document.querySelector(".client-character");
			if (!character) throw new Error("No character is available for the probe.");
			const label = character.textContent.trim();
			character.click();
			return label;
		}`,
	);
	printReport({ selectedCharacter });
	await evaluate(
		client,
		`() => [...document.querySelectorAll("button")].find((button) => button.textContent?.includes("Enter World"))?.click()`,
	);
	const initial = await waitForReady(
		client,
		timeoutMs,
		"initial world entry",
		true,
	);
	if (!initial.ready) {
		throw new Error("Initial world entry did not produce a destination frame.");
	}

	if (streamingOptions !== null) {
		const result = await runClientStreamingProbe(
			client,
			{ evaluate, submitChat, waitForReady, pageState },
			streamingOptions,
		);
		await writeFile(
			streamingOptions.reportPath,
			stringifyRedactedProbeReport(
				{
					...result,
					selectedCharacter,
					consoleMessages: [...consoleMessages.values()],
					page: await pageState(client),
					hostOutput: redact(output).slice(-30000),
				},
				{ account, password },
			),
		);
		printReport({ ok: result.ok, trials: result.trials.length });
		process.exitCode = result.ok ? 0 : 1;
	} else if (mode === "inventory") {
		await evaluate(
			client,
			`() => document.querySelector('button[aria-label="Inventory"]').click()`,
		);
		await waitFor(
			client,
			`() => {
            const panel = document.querySelector('.client-inventory');
            const images = [...document.querySelectorAll('.client-inventory img.ui-icon')];
            return panel?.getAttribute('aria-busy') === 'false' && images.length > 0 &&
                images.every(image => image.complete && image.naturalWidth === 32);
        }`,
			timeoutMs,
			"decoded inventory artwork",
		);
		const inventoryState = `() => ({
            images: [...document.querySelectorAll('.client-inventory img.ui-icon')].map(image => ({
                guid: image.closest('[data-item-guid]').getAttribute('data-item-guid'),
                url: image.src, width: image.naturalWidth, height: image.naturalHeight,
                count: image.closest("[data-item-guid]").querySelector(".item-count-overlay")?.textContent ?? null,
            })),
            fallbacks: document.querySelectorAll('.client-inventory .ui-icon-fallback').length,
            containers: [...document.querySelectorAll('.client-inventory section')].map(section => section.getAttribute('aria-label')),
        })`;
		const before = await evaluate(client, inventoryState);
		await evaluate(
			client,
			`() => document.querySelector('button[aria-label="Close Inventory"]').click()`,
		);
		await delay(1000);
		await evaluate(
			client,
			`() => document.querySelector('button[aria-label="Inventory"]').click()`,
		);
		await waitFor(
			client,
			`() => document.querySelector('.client-inventory img.ui-icon') !== null`,
			timeoutMs,
			"reopened inventory",
		);
		const after = await evaluate(client, inventoryState);
		const retained =
			JSON.stringify(before.images) === JSON.stringify(after.images);
		const screenshotPath = await captureScreenshot(client);
		printReport({
			ok: retained,
			mode,
			before,
			after,
			retained,
			screenshotPath,
			consoleMessages: [...consoleMessages.values()],
			page: await pageState(client),
		});
		process.exitCode = retained ? 0 : 1;
	} else if (mode === "profile") {

        await delay(PROFILE_SETTLE_MS);
        if([...consoleMessages.values()].some(m=>m.level==='exception'||m.level==='error'))throw new Error('Browser error before measurement');
        const before=await evaluate(client, `() => ({programs:window.__discardAudit.programs,unsupported:window.__discardAudit.unsupported,firstDraw:window.__discardAudit.firstDraw})`);
        if(before.programs.length!==1 || before.unsupported.length)throw new Error('Particle shader or blend preconditions failed');
        await evaluate(client, `() => window.__holtburgerClientPerformance.setRendererProfilingEnabled(true)`);
        const trials=[];
        for(let pair=0;pair<5;pair++) {
            for(const mode of (pair%2?['transparent-mask','normal']:['normal','transparent-mask'])) {
                await evaluate(client, `() => {window.__discardAudit.mode=${JSON.stringify(mode)};}`);
                await delay(1500);
                await evaluate(client, `() => {window.__discardAudit.draws=0;window.__discardAudit.dominantDraws=0;window.__holtburgerClientPerformance.reset();}`);
                const start=Date.now();await delay(4000);
                const result=await evaluate(client, `() => ({snapshot:window.__holtburgerClientPerformance.snapshot(),draws:window.__discardAudit.draws,dominantDraws:window.__discardAudit.dominantDraws,unsupported:window.__discardAudit.unsupported})`);
                const gpu=result.snapshot.diagnostics.renderer.profile?.gpu?.mean;
                if(!gpu || result.snapshot.sampledFrameCount===0 || result.unsupported.length)throw new Error('Invalid capture');
                trials.push({pair,mode,windowMs:Date.now()-start,...result});
                await writeFile('/tmp/h3d-discard-costs.json',stringifyRedactedProbeReport({before,trials,consoleMessages:[...consoleMessages.values()]},{account,password}));
                printReport({pair,mode,particleGpuMs:gpu.particleMs,totalGpuMs:gpu.totalMs,draws:result.draws,dominantDraws:result.dominantDraws,frames:result.snapshot.sampledFrameCount});
            }
        }
        printReport({ok:true,reportPath:'/tmp/h3d-discard-costs.json'});

	} else if (mode === "passive-camera") {
		await delay(PASSIVE_CAMERA_SETTLE_MS);
		const cameraEvidence = await capturePassiveCameraGesture(client);
		const cameraSummary = summarizeCameraEvidence(cameraEvidence);
		const screenshotPath = await captureScreenshot(client);
		const captureComplete =
			cameraSummary.inputEventCount === PASSIVE_CAMERA_INPUT_COUNT &&
			cameraSummary.cameraEventCount > 0 &&
			cameraSummary.animationFrameCount > 0;
		printReport({
			ok: captureComplete,
			mode,
			commands: [],
			teleports: [],
			cameraEvidence: cameraSummary,
			screenshotPath,
			consoleMessages: [...consoleMessages.values()],
			page: await pageState(client),
			hostOutput: redact(output).slice(-30_000),
		});
		process.exitCode = captureComplete ? 0 : 1;
	} else if (mode === "precise-jump") {
		const preciseJump = await capturePreciseJumpEntry(client, timeoutMs);
		const responsive =
			preciseJump.sweep.evaluationCount > 1 &&
			Number.isFinite(preciseJump.sweep.postStopLatencyMs);
		printReport({
			ok:
				responsive &&
				preciseJump.page.error === null &&
				!preciseJump.webgl.contextLost,
			mode,
			commands: [],
			teleports: [],
			preciseJump,
			consoleMessages: [...consoleMessages.values()],
			page: preciseJump.page,
			hostOutput: redact(output).slice(-30_000),
		});
		process.exitCode =
			responsive &&
			preciseJump.page.error === null &&
			!preciseJump.webgl.contextLost
				? 0
				: 1;
	} else {
		commands ??= defaultTeleportSequence(initial.lastState.bodyText);

		for (const command of commands) {
			const before = await pageState(client);
			await submitChat(client, command);
			const outcome = await waitForReady(
				client,
				timeoutMs,
				command,
				true,
				before.camera?.cameraGeneration ?? null,
			);
			const generation = outcome.lastState.camera?.cameraGeneration;
			const cameraGeneration = outcome.lastState.cameraGenerations.find(
				(evidence) => evidence.cameraGeneration === generation,
			);
			const provenInitialReseed =
				cameraGeneration?.first.kind === "reseeded" &&
				cameraGeneration.first.reason === "initial-placement" &&
				cameraGeneration.first.clearance !== null;
			const lastState = {
				notice: outcome.lastState.notice,
				error: outcome.lastState.error,
				camera: outcome.lastState.camera,
				bodyText: outcome.lastState.bodyText,
			};
			hops.push({
				command,
				ready: outcome.ready,
				elapsedMs: outcome.elapsedMs,
				lastState,
				cameraGeneration,
				provenInitialReseed,
			});
			if (!outcome.ready) break;
		}

		printReport({
			ok:
				hops.length === commands.length &&
				hops.every((hop) => hop.ready && hop.provenInitialReseed),
			hops,
			consoleMessages: [...consoleMessages.values()],
			page: await pageState(client),
			hostOutput: redact(output).slice(-30_000),
		});
	}
} catch (error) {
	printReport({
		ok: false,
		error: safeError(error),
		hops,
		consoleMessages: [...consoleMessages.values()],
		page:
			client === undefined ? null : await pageState(client).catch(() => null),
		hostOutput: redact(output).slice(-12_000),
	});
	process.exitCode = 1;
} finally {
	if (client !== undefined) {
		try {
			await evaluate(
				client,
				`async () => window.holtburgerHost.invoke("disconnect_client")`,
			);
			printReport({ cleanup: "disconnected" });
		} catch (error) {
			printReport({ cleanupError: safeError(error) });
			process.exitCode = 1;
		}
	}
	client?.close();
	if (child.exitCode === null && child.signalCode === null)
		child.kill("SIGTERM");
}

// Both camera and profiling probes can retain the rendered frame they measured.
async function captureScreenshot(client_) {
	const path = process.env.HOLTBURGER_PROBE_SCREENSHOT;
	if (path === undefined) return null;
	await client_.send("Page.enable");
	const screenshot = await client_.send("Page.captureScreenshot", {
		format: "png",
	});
	await writeFile(path, screenshot.data, "base64");
	return path;
}

function requiredEnvironment(name) {
	const value = process.env[name];
	if (value === undefined || value.length === 0)
		throw new Error(`${name} must be set.`);
	return value;
}

function probeMode(value) {
	if (value === undefined) {
		throw new Error(
			"HOLTBURGER_PROBE_MODE must be explicitly set to teleport, passive-camera, precise-jump, profile, inventory, or streaming.",
		);
	}
	const mode = value;
	if (
		mode !== "teleport" &&
		mode !== "passive-camera" &&
		mode !== "precise-jump" &&
		mode !== "profile" &&
		mode !== "inventory" &&
		mode !== "streaming"
	) {
		throw new Error(
			"HOLTBURGER_PROBE_MODE must be teleport, passive-camera, precise-jump, profile, inventory, or streaming.",
		);
	}
	return mode;
}

function parseCommands(value) {
	const parsed = value
		.split("|")
		.map((command) => command.trim())
		.filter((command) => command.length > 0);
	if (
		parsed.length === 0 ||
		parsed.some((command) => !command.startsWith("@"))
	) {
		throw new Error(
			"Teleport sequence must contain pipe-separated chat commands.",
		);
	}
	return parsed;
}

function defaultTeleportSequence(bodyText) {
	if (bodyText.includes("22.0S, 2.0W")) {
		return parseCommands(
			"@teledungeon 0288|@tele 22s 2w|@teledungeon 0288|@tele 22s 2w",
		);
	}
	return parseCommands(
		"@tele 22s 2w|@teledungeon 0288|@tele 22s 2w|@teledungeon 0288",
	);
}

function redact(value) {
	return value
		.replaceAll(account, "<account>")
		.replaceAll(password, "<password>");
}

function safeError(error) {
	return redact(error instanceof Error ? error.message : String(error));
}

function printReport(report) {
	console.log(
		stringifyRedactedProbeReport(report, {
			account,
			password,
		}),
	);
}

function recordConsoleMessage(message) {
	const key = `${message.level}\u0000${message.text}`;
	const previous = consoleMessages.get(key);
	consoleMessages.set(key, {
		...message,
		count: (previous?.count ?? 0) + 1,
	});
}

function delay(milliseconds) {
	return new Promise((resolvePromise) =>
		setTimeout(resolvePromise, milliseconds),
	);
}

function summarizePerformanceSnapshot(snapshot) {
	const profile = snapshot.diagnostics.renderer?.profile;
	return {
		frameRates: snapshot.frameRates,
		meanFrameWorkMs: snapshot.meanFrameWorkMs,
		renderedFrames: snapshot.sampledFrameCount,
		rendererCpuMean: profile?.cpu.mean ?? null,
		rendererGpuMean:
			profile?.gpu.kind === "available" ? profile.gpu.mean : null,
		runtimeTickMean: snapshot.diagnostics.tickProfile?.mean ?? null,
		selectionMetrics: snapshot.diagnostics.renderer?.selectionMetrics ?? null,
		dynamicResources: snapshot.diagnostics.renderer?.dynamicResources ?? null,
		viewport: snapshot.diagnostics.viewport,
		playerResidency: snapshot.diagnostics.playerResidency,
		cameraResidency: snapshot.diagnostics.cameraResidency,
	};
}

async function waitForDevToolsUrl(process_, readOutput) {
	const startedAt = Date.now();
	for (;;) {
		const match = readOutput().match(/DevTools listening on (ws:\/\/[^\s]+)/);
		if (match?.[1]) return match[1];
		if (process_.exitCode !== null || process_.signalCode !== null) {
			throw new Error("Electron exited before opening its DevTools endpoint.");
		}
		if (Date.now() - startedAt >= 60_000) {
			throw new Error("Timed out waiting for Electron DevTools endpoint.");
		}
		await delay(100);
	}
}

async function waitForPageWebSocketUrl(browserWebSocketUrl) {
	const { port } = new URL(browserWebSocketUrl);
	const startedAt = Date.now();
	for (;;) {
		const targets = await fetch(`http://127.0.0.1:${port}/json/list`, {
			signal: AbortSignal.timeout(10_000),
		}).then((response) => response.json());
		const page = targets.find(
			(target) => target.type === "page" && target.url.includes("/client/"),
		);
		if (page?.webSocketDebuggerUrl) return page.webSocketDebuggerUrl;
		if (Date.now() - startedAt >= 60_000) {
			throw new Error("Timed out waiting for the Electron client page.");
		}
		await delay(100);
	}
}

async function evaluate(client_, expression) {
	const result = await client_.send("Runtime.evaluate", {
		expression: `(${expression})()`,
		awaitPromise: true,
		returnByValue: true,
	});
	if (result.exceptionDetails) throw new Error(result.exceptionDetails.text);
	return result.result.value;
}

async function waitFor(client_, predicate, milliseconds, description) {
	const startedAt = Date.now();
	for (;;) {
		if (await evaluate(client_, predicate)) return;
		if (Date.now() - startedAt >= milliseconds) {
			throw new Error(`Timed out waiting for ${description}.`);
		}
		await delay(100);
	}
}

async function installEvidenceCollector(client_) {
	await evaluate(
		client_,
		`async () => {
			const bridge = window.holtburgerHost;
			if (bridge === undefined) throw new Error("Electron host bridge is unavailable.");
			const evidence = {
				camera: null,
				cameraGenerations: [],
				lifecycle: null,
				lifecycles: [],
				collecting: false,
				cameraEvents: [],
				animationFrames: [],
				inputEvents: [],
				preciseJumpEvaluations: [],
				preciseJumpEvaluationTimes: [],
			};
			Object.defineProperty(window, "__holtburgerProbeEvidence", {
				configurable: true,
				value: evidence,
			});
			await bridge.listen("client-camera", (tick) => {
				if (evidence.collecting) evidence.cameraEvents.push(performance.now());
				const pathEnd = tick.path.legs.at(-1)?.end.position ?? tick.path.initial.position;
				const summary = {
					cameraGeneration: tick.cameraGeneration,
					sequence: tick.sequence,
					kind: tick.kind,
					reason: tick.reason ?? null,
					clearance: tick.clearance ?? null,
					initialLandblockId: tick.path.initial.position.landblockId,
					finalLandblockId: pathEnd.landblockId,
					position: pathEnd,
				};
				evidence.camera = summary;
				const generation = evidence.cameraGenerations.find(
					(candidate) => candidate.cameraGeneration === tick.cameraGeneration,
				);
				if (generation === undefined) {
					evidence.cameraGenerations.push({
						cameraGeneration: tick.cameraGeneration,
						first: summary,
						latest: summary,
					});
				} else {
					generation.latest = summary;
				}
			});
			await bridge.listen("client-lifecycle-changed", (lifecycle) => {
				evidence.lifecycle = lifecycle;
				evidence.lifecycles.push(lifecycle);
			});
			await bridge.listen("client-precise-jump-evaluation", (evaluation) => {
				evidence.preciseJumpEvaluations.push(evaluation);
				evidence.preciseJumpEvaluationTimes.push(performance.now());
			});
			const collectAnimationFrame = (timestamp) => {
				if (evidence.collecting) evidence.animationFrames.push(timestamp);
				requestAnimationFrame(collectAnimationFrame);
			};
			requestAnimationFrame(collectAnimationFrame);
		}`,
	);
}

async function capturePreciseJumpEntry(client_, milliseconds) {
	// World-ready notices precede gameplay input admission during portal-space activation.
	await waitFor(
		client_,
		"() => window.__holtburgerProbeEvidence.lifecycle?.kind === 'in-world'",
		milliseconds,
		"in-world precise-jump input",
	);
	const bounds = await evaluate(
		client_,
		`() => {
			const canvas = document.querySelector(".client-canvas");
			if (!(canvas instanceof HTMLCanvasElement)) {
				throw new Error("Client canvas is unavailable.");
			}
			canvas.focus();
			const rect = canvas.getBoundingClientRect();
			window.__holtburgerProbeEvidence.preciseJumpEvaluations = [];
			window.__holtburgerProbeEvidence.preciseJumpEvaluationTimes = [];
			return { x: rect.x, y: rect.y, width: rect.width, height: rect.height };
		}`,
	);
	const x = bounds.x + bounds.width * 0.5;
	const y = bounds.y + bounds.height * 0.6;
	await client_.send("Input.dispatchMouseEvent", {
		type: "mouseMoved",
		x,
		y,
		button: "none",
		buttons: 0,
	});
	await evaluate(
		client_,
		`() => {
			const dispatch = (type, key, shiftKey) =>
				window.dispatchEvent(
					new KeyboardEvent(type, { bubbles: true, key, shiftKey }),
				);
			dispatch("keydown", "J", true);
			dispatch("keyup", "J", false);
		}`,
	);
	const startedAt = Date.now();
	for (;;) {
		const state = await evaluate(
			client_,
			`() => ({
				evaluations: window.__holtburgerProbeEvidence.preciseJumpEvaluations,
				error: document.querySelector('[role="alert"]')?.textContent?.trim() ?? null,
			})`,
		);
		if (
			state.evaluations.some(
				(evaluation) => evaluation.phase === "completed",
			) ||
			state.error !== null
		)
			break;
		if (Date.now() - startedAt >= milliseconds) {
			throw new Error("Timed out waiting for precise-jump evaluation.");
		}
		await delay(100);
	}
	const sweepStartedAt = await evaluate(client_, "() => performance.now()");
	for (let index = 0; index < PRECISE_JUMP_SWEEP_INPUT_COUNT; index += 1) {
		const fraction = index / (PRECISE_JUMP_SWEEP_INPUT_COUNT - 1);
		await client_.send("Input.dispatchMouseEvent", {
			type: "mouseMoved",
			x: bounds.x + bounds.width * (0.35 + fraction * 0.3),
			y: bounds.y + bounds.height * 0.6,
			button: "none",
			buttons: 0,
		});
		await delay(PRECISE_JUMP_SWEEP_INPUT_INTERVAL_MS);
	}
	const stoppedAt = await evaluate(client_, "() => performance.now()");
	await waitFor(
		client_,
		`() => window.__holtburgerProbeEvidence.preciseJumpEvaluations.some(
            (evaluation, index) => evaluation.phase === "completed" && window.__holtburgerProbeEvidence.preciseJumpEvaluationTimes[index] >= ${stoppedAt},
		)`,
		milliseconds,
		"post-sweep precise-jump evaluation",
	);
	await delay(100);
	const result = await evaluate(
		client_,
		`() => {
			const canvas = document.querySelector(".client-canvas");
			const gl = canvas instanceof HTMLCanvasElement ? canvas.getContext("webgl2") : null;
			return {
				evaluations: window.__holtburgerProbeEvidence.preciseJumpEvaluations,
				evaluationTimes: window.__holtburgerProbeEvidence.preciseJumpEvaluationTimes,
				page: {
					notice: document.querySelector(".client-toast")?.textContent?.trim() ?? null,
					error: document.querySelector('[role="alert"]')?.textContent?.trim() ?? null,
				},
				webgl: {
					contextLost: gl?.isContextLost() ?? true,
					renderer: gl?.getParameter(gl.RENDERER) ?? null,
					vendor: gl?.getParameter(gl.VENDOR) ?? null,
				},
			};
		}`,
	);
	const sweepEvaluationTimes = result.evaluationTimes.filter(
		(time) => time >= sweepStartedAt,
	);
	return {
		...result,
		sweep: {
			inputCount: PRECISE_JUMP_SWEEP_INPUT_COUNT,
			durationMs: stoppedAt - sweepStartedAt,
			evaluationCount: sweepEvaluationTimes.length,
			maximumEvaluationGapMs: maximumAdjacentGap(sweepEvaluationTimes),
			postStopLatencyMs:
				sweepEvaluationTimes.find((time) => time >= stoppedAt) - stoppedAt,
		},
	};
}

function maximumAdjacentGap(values) {
	let maximum = 0;
	for (let index = 1; index < values.length; index += 1) {
		maximum = Math.max(maximum, values[index] - values[index - 1]);
	}
	return maximum;
}

async function capturePassiveCameraGesture(client_) {
	const bounds = await evaluate(
		client_,
		`() => {
			const canvas = document.querySelector(".client-canvas");
			if (!(canvas instanceof HTMLCanvasElement)) {
				throw new Error("Client canvas is unavailable.");
			}
			const rect = canvas.getBoundingClientRect();
			const evidence = window.__holtburgerProbeEvidence;
			evidence.cameraEvents = [];
			evidence.animationFrames = [];
			evidence.inputEvents = [];
			evidence.collecting = true;
			return { x: rect.x, y: rect.y, width: rect.width, height: rect.height };
		}`,
	);
	const startX = bounds.x + bounds.width * 0.45;
	const startY = bounds.y + bounds.height * 0.5;
	await client_.send("Input.dispatchMouseEvent", {
		type: "mousePressed",
		x: startX,
		y: startY,
		button: "left",
		buttons: 1,
		clickCount: 1,
	});
	for (let step = 1; step <= PASSIVE_CAMERA_INPUT_COUNT; step += 1) {
		await evaluate(
			client_,
			"() => window.__holtburgerProbeEvidence.inputEvents.push(performance.now())",
		);
		await client_.send("Input.dispatchMouseEvent", {
			type: "mouseMoved",
			x: startX + step * 2,
			y: startY + Math.sin(step / 6) * 12,
			button: "left",
			buttons: 1,
		});
		await delay(PASSIVE_CAMERA_INPUT_INTERVAL_MS);
	}
	await client_.send("Input.dispatchMouseEvent", {
		type: "mouseReleased",
		x: startX + 80,
		y: startY,
		button: "left",
		buttons: 0,
		clickCount: 1,
	});
	await delay(2_000);
	return evaluate(
		client_,
		`() => {
			const evidence = window.__holtburgerProbeEvidence;
			evidence.collecting = false;
			return {
				cameraEvents: evidence.cameraEvents,
				animationFrames: evidence.animationFrames,
				inputEvents: evidence.inputEvents,
			};
		}`,
	);
}

function summarizeCameraEvidence(evidence) {
	const cameraIntervals = intervals(evidence.cameraEvents);
	const animationFrameIntervals = intervals(evidence.animationFrames);
	const inputLatencies = evidence.inputEvents.flatMap((input) => {
		const camera = evidence.cameraEvents.find((event) => event >= input);
		return camera === undefined ? [] : [camera - input];
	});
	return {
		cameraEventCount: evidence.cameraEvents.length,
		animationFrameCount: evidence.animationFrames.length,
		inputEventCount: evidence.inputEvents.length,
		cameraIntervalMs: distribution(cameraIntervals),
		animationFrameIntervalMs: distribution(animationFrameIntervals),
		// This measures the next publication, not a causal acknowledgement of orbit input.
		inputToNextCameraEventMs: distribution(inputLatencies),
	};
}

function intervals(values) {
	return values.slice(1).map((value, index) => value - values[index]);
}

function distribution(values) {
	if (values.length === 0) return null;
	const sorted = [...values].sort((left, right) => left - right);
	const percentile = (fraction) =>
		sorted[
			Math.min(
				sorted.length - 1,
				Math.max(0, Math.ceil(sorted.length * fraction) - 1),
			)
		];
	return {
		count: sorted.length,
		mean: sorted.reduce((total, value) => total + value, 0) / sorted.length,
		p50: percentile(0.5),
		p95: percentile(0.95),
		max: sorted.at(-1),
	};
}

async function submitChat(client_, message) {
	await evaluate(
		client_,
		`() => {
			const input = document.querySelector('input[aria-label="Chat message"]');
			if (!(input instanceof HTMLInputElement)) throw new Error("Chat input is unavailable.");
			const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
			setter?.call(input, ${JSON.stringify(message)});
			input.dispatchEvent(new Event("input", { bubbles: true }));
			input.form?.requestSubmit();
		}`,
	);
}

async function waitForReady(
	client_,
	milliseconds,
	description,
	requireLoading,
	previousCameraGeneration = null,
) {
	const startedAt = Date.now();
	let sawLoading = false;
	for (;;) {
		const state = await pageState(client_);
		if (state.notice !== null && state.notice !== WORLD_READY_NOTICE) {
			sawLoading = true;
		}
		const hasCurrentCamera =
			state.camera !== null &&
			(previousCameraGeneration === null ||
				state.camera.cameraGeneration !== previousCameraGeneration);
		if (
			state.notice === WORLD_READY_NOTICE &&
			hasCurrentCamera &&
			(!requireLoading || sawLoading)
		) {
			return {
				ready: true,
				elapsedMs: Date.now() - startedAt,
				lastState: state,
			};
		}
		if (Date.now() - startedAt >= milliseconds) {
			return {
				ready: false,
				elapsedMs: Date.now() - startedAt,
				lastState: state,
			};
		}
		await delay(100);
	}
}

function pageState(client_) {
	return evaluate(
		client_,
		`() => ({
			notice: document.querySelector(".client-toast")?.textContent?.trim() ?? null,
			error: document.querySelector('[role="alert"]')?.textContent?.trim() ?? null,
			camera: window.__holtburgerProbeEvidence?.camera ?? null,
			cameraGenerations: window.__holtburgerProbeEvidence?.cameraGenerations ?? [],
			lifecycle: window.__holtburgerProbeEvidence?.lifecycle ?? null,
			lifecycles: window.__holtburgerProbeEvidence?.lifecycles ?? [],
			bodyText: document.body?.innerText.slice(0, 4000) ?? "",
		})`,
	);
}
