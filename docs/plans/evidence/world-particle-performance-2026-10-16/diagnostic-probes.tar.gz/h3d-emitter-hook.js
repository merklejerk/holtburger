async () => {
    const {ParticleSystem}=await import('/src/lib/game/systems/particle-system.ts');
    const {GamePresentationRuntime}=await import('/src/lib/game/runtime/game-presentation-runtime.ts');
    const p=ParticleSystem.prototype, create=p.create, collect=p.collectDrawRanges, advance=p.advance;
    const state=window.__emitterAudit={creates:[],snapshots:[],ranges:[],system:null,runtime:null,time:0};
    p.create=function(target,emitter,offset,id,time,origin,frameTarget) {
        if(emitter.mesh.id==='0x01003fa7') state.creates.push({target:{...target},emitter:{...emitter},offset:[...offset],id,time,origin:[...origin],frameTarget:frameTarget ? {...frameTarget}:null});
        return create.apply(this,arguments);
    };
    p.advance=function(time) {state.system=this;state.time=time;return advance.apply(this,arguments);};
    p.collectDrawRanges=function() {
        const result=collect.apply(this,arguments);
        state.ranges=result.filter(r=>r.hwGfxObjId==='0x01003fa7').map(r=>({base:r.baseSlot,count:r.count,owner:r.renderOwner,frame:r.frame.kind}));
        return result;
    };
    const tick=GamePresentationRuntime.prototype.tick;
    GamePresentationRuntime.prototype.tick=function() {state.runtime=this;return tick.apply(this,arguments);};
}
