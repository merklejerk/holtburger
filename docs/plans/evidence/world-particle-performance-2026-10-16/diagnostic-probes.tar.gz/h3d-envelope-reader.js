    state.inspectEnvelope=()=>{
        const gl=state.gl;if(!gl)throw new Error('No particle context');
        if(!gl.getExtension('EXT_color_buffer_float'))throw new Error('Float color target unavailable');
        const saved={program:gl.getParameter(gl.CURRENT_PROGRAM),vao:gl.getParameter(gl.VERTEX_ARRAY_BINDING),draw:gl.getParameter(gl.DRAW_FRAMEBUFFER_BINDING),read:gl.getParameter(gl.READ_FRAMEBUFFER_BINDING),viewport:Array.from(gl.getParameter(gl.VIEWPORT)),texture:gl.getParameter(gl.TEXTURE_BINDING_2D)};
        const capabilities=[gl.BLEND,gl.DEPTH_TEST,gl.SCISSOR_TEST,gl.CULL_FACE,gl.STENCIL_TEST].map(cap=>[cap,gl.isEnabled(cap)]);
        const compile=(kind,source)=>{const s=gl.createShader(kind);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(s));return s;};
        const vs=compile(gl.VERTEX_SHADER,'#version 300 es\nvoid main(){vec2 p=gl_VertexID==0?vec2(-1.,-1.):gl_VertexID==1?vec2(3.,-1.):vec2(-1.,3.);gl_Position=vec4(p,0.,1.);}');
        const fs=compile(gl.FRAGMENT_SHADER,'#version 300 es\nprecision highp float;uniform sampler2D envelope;out vec4 color;void main(){float d=texelFetch(envelope,ivec2(gl_FragCoord.xy),0).r;color=vec4(d,d,d,1.);}');
        const program=gl.createProgram();gl.attachShader(program,vs);gl.attachShader(program,fs);gl.linkProgram(program);
        if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(program));
        const width=gl.drawingBufferWidth,height=gl.drawingBufferHeight;
        const color=gl.createTexture(),framebuffer=gl.createFramebuffer();gl.bindTexture(gl.TEXTURE_2D,color);gl.texStorage2D(gl.TEXTURE_2D,1,gl.RGBA32F,width,height);gl.bindTexture(gl.TEXTURE_2D,saved.texture);
        gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,framebuffer);gl.framebufferTexture2D(gl.DRAW_FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,color,0);
        if(gl.checkFramebufferStatus(gl.DRAW_FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw new Error('Envelope readback framebuffer incomplete');
        for(const [cap] of capabilities)disable.call(gl,cap);
        gl.viewport(0,0,width,height);gl.useProgram(program);gl.uniform1i(gl.getUniformLocation(program,'envelope'),5);gl.bindVertexArray(null);gl.drawArrays(gl.TRIANGLES,0,3);
        gl.bindFramebuffer(gl.READ_FRAMEBUFFER,framebuffer);gl.readBuffer(gl.COLOR_ATTACHMENT0);
        const pixels=new Float32Array(width*height*4);gl.readPixels(0,0,width,height,gl.RGBA,gl.FLOAT,pixels);const error=gl.getError();
        gl.useProgram(saved.program);gl.bindVertexArray(saved.vao);gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,saved.draw);gl.bindFramebuffer(gl.READ_FRAMEBUFFER,saved.read);gl.viewport(...saved.viewport);
        for(const [cap,on] of capabilities)(on?enable:disable).call(gl,cap);
        gl.deleteFramebuffer(framebuffer);gl.deleteTexture(color);gl.deleteProgram(program);gl.deleteShader(vs);gl.deleteShader(fs);
        if(error!==gl.NO_ERROR)throw new Error('Envelope readback GL error '+error);
        let uncovered=0,unbounded=0,finite=0,minFinite=Infinity,maxFinite=-Infinity;
        for(let i=0;i<pixels.length;i+=4){const d=pixels[i];if(d===0)uncovered++;else if(d===1)unbounded++;else{finite++;minFinite=Math.min(minFinite,d);maxFinite=Math.max(maxFinite,d);}}
        return {width,height,uncovered,unbounded,finite,minFinite,maxFinite};
    };
