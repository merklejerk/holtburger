() => {
    const p=WebGL2RenderingContext.prototype;
    const source=p.shaderSource, bind=p.useProgram, draw=p.drawElementsInstanced;
    const enable=p.enable, disable=p.disable, scissor=p.scissor;
    const programs=new WeakMap(), facts=new WeakMap();
    const state=window.__fragmentAudit={mode:'normal',counts:{dominantDraws:0,dominantInstances:0},firstDraw:null,capture:null,lastCapture:null};
    p.shaderSource=function(shader,text) {
        if(text.includes('in float vTranslucency;') && text.includes('vec4 sampleMaterial()')) {
            text=text.replace('precision highp int;', 'precision highp int;\nuniform int uDiagnosticPortalBypass;\nuniform int uDiagnosticConstant;\nuniform int uDiagnosticCount;');
            text=text.replace('void main() {','void main() {\nif (uDiagnosticCount == 2) { outColor=vec4(1.0); return; }');
            text=text.replace('if (!portalDeferredFragmentVisible()) discard;', 'if (uDiagnosticPortalBypass == 0 && !portalDeferredFragmentVisible()) discard;');
            text=text.replace('vec4 color = sampleMaterial();','vec4 color = uDiagnosticConstant == 1 ? vec4(0.5) : sampleMaterial();');
            text=text.replace('outColor = encodeTransparentCanvasEmission(color, uCanvasEmissionMode);','outColor = uDiagnosticCount == 1 ? vec4(1.0) : encodeTransparentCanvasEmission(color, uCanvasEmissionMode);');
        }
        return source.call(this,shader,text);
    };
    p.useProgram=function(program) {
        programs.set(this,program);
        if(program && !facts.has(program)) {
            const particle=this.getUniformLocation(program,'uParticleRecords') !== null;
            facts.set(program,particle ? {
                portal:this.getUniformLocation(program,'uDiagnosticPortalBypass'),
                constant:this.getUniformLocation(program,'uDiagnosticConstant'),
                count:this.getUniformLocation(program,'uDiagnosticCount')
            }:null);
        }
        return bind.call(this,program);
    };
    const blendState=gl=>({enabled:gl.isEnabled(gl.BLEND),eq:gl.getParameter(gl.BLEND_EQUATION_RGB),eqA:gl.getParameter(gl.BLEND_EQUATION_ALPHA),src:gl.getParameter(gl.BLEND_SRC_RGB),dst:gl.getParameter(gl.BLEND_DST_RGB),srcA:gl.getParameter(gl.BLEND_SRC_ALPHA),dstA:gl.getParameter(gl.BLEND_DST_ALPHA)});
    const restoreBlend=(gl,b)=>{
        (b.enabled?enable:disable).call(gl,gl.BLEND);
        gl.blendEquationSeparate(b.eq,b.eqA);gl.blendFuncSeparate(b.src,b.dst,b.srcA,b.dstA);
    };
    const makeCounter=(gl,cap)=>{
        if(!gl.getExtension('EXT_color_buffer_float') || !gl.getExtension('EXT_float_blend')) throw new Error('Float blending required for overlap counter');
        const original=gl.getParameter(gl.DRAW_FRAMEBUFFER_BINDING), texture=gl.getParameter(gl.TEXTURE_BINDING_2D);
        const color=gl.createTexture(),framebuffer=gl.createFramebuffer();
        const width=gl.drawingBufferWidth,height=gl.drawingBufferHeight;
        gl.bindTexture(gl.TEXTURE_2D,color);gl.texStorage2D(gl.TEXTURE_2D,1,gl.RGBA32F,width,height);
        const depthType=gl.getFramebufferAttachmentParameter(gl.DRAW_FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE);
        const depth=gl.getFramebufferAttachmentParameter(gl.DRAW_FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.FRAMEBUFFER_ATTACHMENT_OBJECT_NAME);
        gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,framebuffer);
        gl.framebufferTexture2D(gl.DRAW_FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,color,0);
        if(cap.depth) {
            if(depthType===gl.TEXTURE) gl.framebufferTexture2D(gl.DRAW_FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.TEXTURE_2D,depth,0);
            else if(depthType===gl.RENDERBUFFER) gl.framebufferRenderbuffer(gl.DRAW_FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.RENDERBUFFER,depth);
            else throw new Error('No shared scene depth attachment');
        }
        if(gl.checkFramebufferStatus(gl.DRAW_FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE) throw new Error('Overlap framebuffer incomplete');
        const clipped=gl.isEnabled(gl.SCISSOR_TEST);disable.call(gl,gl.SCISSOR_TEST);
        gl.clearBufferfv(gl.COLOR,0,new Float32Array(4));if(clipped)enable.call(gl,gl.SCISSOR_TEST);
        gl.bindTexture(gl.TEXTURE_2D,texture);gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,original);
        Object.assign(cap,{gl,color,framebuffer,width,height,draws:0});
    };
    p.drawElementsInstanced=function(mode,count,type,offset,instances) {
        const program=programs.get(this),f=program && facts.get(program);
        if(!f || count!==330) return draw.call(this,mode,count,type,offset,instances);
        state.counts.dominantDraws++;state.counts.dominantInstances+=instances;
        const portal=state.mode.includes('no-portal'), constant=state.mode.includes('constant');
        if(f.portal)this.uniform1i(f.portal,portal?1:0);
        this.uniform1i(f.constant,constant?1:0);this.uniform1i(f.count,0);
        if(state.firstDraw===null) {
            const get=name=>{const u=this.getUniformLocation(program,name);return u===null?null:this.getUniform(program,u);};
            const ordinal=get('uPortalRenderDomain');
            const buffer=this.getIndexedParameter(this.UNIFORM_BUFFER_BINDING,0);
            const old=this.getParameter(this.UNIFORM_BUFFER_BINDING);
            const metadata=new Uint32Array(8);
            this.bindBuffer(this.UNIFORM_BUFFER,buffer);
            this.getBufferSubData(this.UNIFORM_BUFFER,64+255*32+ordinal*32,metadata);
            this.bindBuffer(this.UNIFORM_BUFFER,old);
            state.firstDraw={ordinal,scopeMetadata:Array.from(metadata),viewport:Array.from(this.getParameter(this.VIEWPORT)),alphaTest:get('uAlphaTest'),materialKind:get('uMaterialKind'),opacity:get('uOpacityScale'),depthTest:this.isEnabled(this.DEPTH_TEST),depthFunc:this.getParameter(this.DEPTH_FUNC),depthWrite:this.getParameter(this.DEPTH_WRITEMASK),cullFace:this.isEnabled(this.CULL_FACE),blend:blendState(this)};
        }
        const cap=state.capture;
        if(cap) {
            if(!cap.framebuffer)makeCounter(this,cap);
            const oldFramebuffer=this.getParameter(this.DRAW_FRAMEBUFFER_BINDING),oldBlend=blendState(this),oldDepth=this.isEnabled(this.DEPTH_TEST);
            this.bindFramebuffer(this.DRAW_FRAMEBUFFER,cap.framebuffer);
            if(!cap.depth)disable.call(this,this.DEPTH_TEST);
            enable.call(this,this.BLEND);this.blendEquation(this.FUNC_ADD);this.blendFunc(this.ONE,this.ONE);
            this.uniform1i(f.count,cap.kind==='coverage'?2:1);
            draw.call(this,mode,count,type,offset,instances);cap.draws++;
            this.uniform1i(f.count,0);this.bindFramebuffer(this.DRAW_FRAMEBUFFER,oldFramebuffer);restoreBlend(this,oldBlend);
            (oldDepth?enable:disable).call(this,this.DEPTH_TEST);
            return;
        }
        const noBlend=state.mode.includes('no-blend'),clip=state.mode==='scissor-half';
        const wasBlend=noBlend?this.isEnabled(this.BLEND):false;
        let oldClip,wasClipped;
        if(noBlend)disable.call(this,this.BLEND);
        if(clip) {
            oldClip=Array.from(this.getParameter(this.SCISSOR_BOX));wasClipped=this.isEnabled(this.SCISSOR_TEST);
            const width=this.drawingBufferWidth,height=this.drawingBufferHeight;
            let x=Math.floor(width/4),y=Math.floor(height/4),right=x+Math.floor(width/2),top=y+Math.floor(height/2);
            if(wasClipped){x=Math.max(x,oldClip[0]);y=Math.max(y,oldClip[1]);right=Math.min(right,oldClip[0]+oldClip[2]);top=Math.min(top,oldClip[1]+oldClip[3]);}
            enable.call(this,this.SCISSOR_TEST);scissor.call(this,x,y,Math.max(0,right-x),Math.max(0,top-y));
        }
        draw.call(this,mode,count,type,offset,instances);
        if(noBlend && wasBlend)enable.call(this,this.BLEND);
        if(clip){scissor.call(this,...oldClip);if(!wasClipped)disable.call(this,this.SCISSOR_TEST);}
    };
    state.startCounter=(kind,depth)=>{state.mode='normal';state.capture={kind,depth};};
    state.finishCounter=()=>{
        const cap=state.capture;state.capture=null;
        if(!cap?.framebuffer)throw new Error('Overlap capture saw no dominant draws');
        const gl=cap.gl,read=gl.getParameter(gl.READ_FRAMEBUFFER_BINDING);
        gl.bindFramebuffer(gl.READ_FRAMEBUFFER,cap.framebuffer);gl.readBuffer(gl.COLOR_ATTACHMENT0);
        const pixels=new Float32Array(cap.width*cap.height*4);gl.readPixels(0,0,cap.width,cap.height,gl.RGBA,gl.FLOAT,pixels);
        const error=gl.getError();gl.bindFramebuffer(gl.READ_FRAMEBUFFER,read);
        gl.deleteFramebuffer(cap.framebuffer);gl.deleteTexture(cap.color);
        if(error!==gl.NO_ERROR)throw new Error('Overlap readback GL error '+error);
        let sum=0,max=0,covered=0;const histogram={};
        for(let i=0;i<pixels.length;i+=4){const n=pixels[i];sum+=n;max=Math.max(max,n);if(n>0)covered++;histogram[n]=(histogram[n]??0)+1;}
        return {kind:cap.kind,depth:cap.depth,width:cap.width,height:cap.height,draws:cap.draws,sum,max,covered,mean:sum/(cap.width*cap.height),histogram};
    };
}
