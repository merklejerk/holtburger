#!/usr/bin/env node

import { spawn } from "node:child_process";
import { writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { resolve } from "node:path";

import { runClientStreamingProbe } from "file:///home/me/code/holtburger/apps/holtburger-3d/scripts/client-streaming-probe.mjs";
import { createCdpClient } from "file:///home/me/code/holtburger/apps/holtburger-3d/scripts/cdp-client.mjs";
import { stringifyRedactedProbeReport } from "file:///home/me/code/holtburger/apps/holtburger-3d/scripts/live-client-probe-report.mjs";

const PASSIVE_CAMERA_SETTLE_MS = 5_000;
const PASSIVE_CAMERA_INPUT_COUNT = 40;
const PASSIVE_CAMERA_INPUT_INTERVAL_MS = 25;
const PRECISE_JUMP_SWEEP_INPUT_COUNT = 120;
const PRECISE_JUMP_SWEEP_INPUT_INTERVAL_MS = 5;
const PROFILE_SETTLE_MS = 10_000;
const PROFILE_WINDOW_MS = 10_000;
const WORLD_READY_NOTICE = "World ready";

const appRoot = '/home/me/code/holtburger/apps/holtburger-3d';
const account = requiredEnvironment("HOLTBURGER_PROBE_ACCOUNT");
const password = requiredEnvironment("HOLTBURGER_PROBE_PASSWORD");
const mode = probeMode(process.env.HOLTBURGER_PROBE_MODE);
const performanceInstrumentationEnabled =
	process.env.HOLTBURGER_PROBE_PROFILE_INSTRUMENTATION !== "0";
if (
	mode !== "teleport" &&
	process.env.HOLTBURGER_PROBE_TELEPORT_SEQUENCE !== undefined
) {
	throw new Error(`${mode} mode rejects HOLTBURGER_PROBE_TELEPORT_SEQUENCE.`);
}
let commands =
	mode === "teleport" && process.env.HOLTBURGER_PROBE_TELEPORT_SEQUENCE
		? parseCommands(process.env.HOLTBURGER_PROBE_TELEPORT_SEQUENCE)
		: null;
const timeoutMs = Number(process.env.HOLTBURGER_PROBE_TIMEOUT_MS ?? "45000");

if (!Number.isSafeInteger(timeoutMs) || timeoutMs <= 0) {
	throw new Error("HOLTBURGER_PROBE_TIMEOUT_MS must be a positive integer.");
}
// Resolve streaming configuration before launching or moving a live character.
const streamingOptions =
	mode === "streaming"
		? {
				startCommand:
					process.env.HOLTBURGER_STREAMING_START ?? "@tele 33.17s 72.85e",
				startLandblock:
					process.env.HOLTBURGER_STREAMING_START_LANDBLOCK ?? "0xda55ffff",
				destination:
					process.env.HOLTBURGER_STREAMING_DESTINATION ?? "0xda56ffff",
				trials: Number(process.env.HOLTBURGER_STREAMING_TRIALS ?? "1"),
				settleMs: 10000,
				moveMs: 2000,
				drainMs: 4000,
				timeoutMs,
				profile: performanceInstrumentationEnabled,
				outputPrefix: requiredEnvironment("HOLTBURGER_STREAMING_OUTPUT"),
				reportPath: requiredEnvironment("HOLTBURGER_PROBE_REPORT"),
			}
		: null;
if (
	streamingOptions !== null &&
	(!Number.isSafeInteger(streamingOptions.trials) ||
		streamingOptions.trials < 1)
) {
	throw new Error(
		"HOLTBURGER_STREAMING_TRIALS must be a positive safe integer.",
	);
}
const child = spawn(process.execPath, ["/tmp/h3d-production-launch.mjs", "client", "--release", "--vite-port", "0", "--account", account, "--password", password, `--debug=${performanceInstrumentationEnabled}`], { cwd: appRoot, env: {...process.env, HOLTBURGER_ELECTRON_REMOTE_DEBUGGING_PORT: "0"}, stdio: ["ignore", "pipe", "pipe"] });

let output = "";
for (const stream of [child.stdout, child.stderr]) {
	stream.on("data", (chunk) => {
		output += chunk.toString("utf8");
	});
}

let client;
const consoleMessages = new Map();
const hops = [];
try {
	const browserWebSocketUrl = await waitForDevToolsUrl(child, () => output);
	printReport({ stage: "devtools-endpoint" });
 const browserClient = await createCdpClient(browserWebSocketUrl);
 const gpuInfo = await browserClient.send("SystemInfo.getInfo");
 await writeFile("/tmp/h3d-gpu-info.json", JSON.stringify(gpuInfo));
 browserClient.close();
	const pageWebSocketUrl = await waitForPageWebSocketUrl(browserWebSocketUrl);
	printReport({ stage: "client-page-endpoint" });
	client = await createCdpClient(pageWebSocketUrl);
	client.on("Runtime.consoleAPICalled", (message) => {
		recordConsoleMessage({
			level: message.type,
			text: message.args
				.map((argument) => argument.value ?? argument.description ?? "")
				.join(" "),
		});
	});
	client.on("Runtime.exceptionThrown", (message) => {
		recordConsoleMessage({
			level: "exception",
			text:
				message.exceptionDetails.exception?.description ??
				message.exceptionDetails.text,
		});
	});
	await client.send("Runtime.enable");
	await installEvidenceCollector(client);
 await evaluate(client, "() => {\n    const p=WebGL2RenderingContext.prototype;\n    const source=p.shaderSource, bind=p.useProgram, draw=p.drawElementsInstanced;\n    const enable=p.enable, disable=p.disable, scissor=p.scissor;\n    const programs=new WeakMap(), facts=new WeakMap();\n    const state=window.__fragmentAudit={mode:'normal',counts:{dominantDraws:0,dominantInstances:0},firstDraw:null,capture:null,lastCapture:null};\n    p.shaderSource=function(shader,text) {\n        if(text.includes('in float vTranslucency;') && text.includes('vec4 sampleMaterial()')) {\n            text=text.replace('precision highp int;', 'precision highp int;\\nuniform int uDiagnosticPortalBypass;\\nuniform int uDiagnosticConstant;\\nuniform int uDiagnosticCount;');\n            text=text.replace('void main() {','void main() {\\nif (uDiagnosticCount == 2) { outColor=vec4(1.0); return; }');\n            text=text.replace('if (!portalDeferredFragmentVisible()) discard;', 'if (uDiagnosticPortalBypass == 0 && !portalDeferredFragmentVisible()) discard;');\n            text=text.replace('vec4 color = sampleMaterial();','vec4 color = uDiagnosticConstant == 1 ? vec4(0.5) : sampleMaterial();');\n            text=text.replace('outColor = encodeTransparentCanvasEmission(color, uCanvasEmissionMode);','outColor = uDiagnosticCount == 1 ? vec4(1.0) : encodeTransparentCanvasEmission(color, uCanvasEmissionMode);');\n        }\n        if(text.includes('in float vTranslucency;') && text.includes('bool portalDeferredFragmentVisible() {')) {\n            text=text.replace('precision highp int;', 'precision highp int;\\nuniform int uDiagnosticRootFast;');\n            text=text.replace('bool portalDeferredFragmentVisible() {','bool portalOriginalFragmentVisible() {');\n            const helpers=`\n                bool portalRootFragmentVisible() {\n                    float d=texelFetch(uPortalEnvelopeDepth,ivec2(gl_FragCoord.xy),0).r;\n                    if(d==0.0)return portalOriginalFragmentVisible();\n                    return d==1.0 || gl_FragCoord.z*0.5<d;\n                }\n                bool portalDeferredFragmentVisible() {\n                    if(uDiagnosticRootFast==1 && uPortalRenderDomain==0u)return portalRootFragmentVisible();\n                    return portalOriginalFragmentVisible();\n                }\n            `;\n            text=text.replace('void main() {',helpers+'\\nvoid main() {\\nif(uDiagnosticCount==3){outColor=vec4(portalOriginalFragmentVisible()!=portalRootFragmentVisible()?1.0:0.0);return;}');\n        }\n        return source.call(this,shader,text);\n    };\n    p.useProgram=function(program) {\n        programs.set(this,program);\n        if(program && !facts.has(program)) {\n            const particle=this.getUniformLocation(program,'uParticleRecords') !== null;\n            facts.set(program,particle ? {\n                portal:this.getUniformLocation(program,'uDiagnosticPortalBypass'),\n                constant:this.getUniformLocation(program,'uDiagnosticConstant'),\n                count:this.getUniformLocation(program,'uDiagnosticCount'),rootFast:this.getUniformLocation(program,'uDiagnosticRootFast')\n            }:null);\n        }\n        return bind.call(this,program);\n    };\n    const blendState=gl=>({enabled:gl.isEnabled(gl.BLEND),eq:gl.getParameter(gl.BLEND_EQUATION_RGB),eqA:gl.getParameter(gl.BLEND_EQUATION_ALPHA),src:gl.getParameter(gl.BLEND_SRC_RGB),dst:gl.getParameter(gl.BLEND_DST_RGB),srcA:gl.getParameter(gl.BLEND_SRC_ALPHA),dstA:gl.getParameter(gl.BLEND_DST_ALPHA)});\n    const restoreBlend=(gl,b)=>{\n        (b.enabled?enable:disable).call(gl,gl.BLEND);\n        gl.blendEquationSeparate(b.eq,b.eqA);gl.blendFuncSeparate(b.src,b.dst,b.srcA,b.dstA);\n    };\n    const makeCounter=(gl,cap)=>{\n        if(!gl.getExtension('EXT_color_buffer_float') || !gl.getExtension('EXT_float_blend')) throw new Error('Float blending required for overlap counter');\n        const original=gl.getParameter(gl.DRAW_FRAMEBUFFER_BINDING), texture=gl.getParameter(gl.TEXTURE_BINDING_2D);\n        const color=gl.createTexture(),framebuffer=gl.createFramebuffer();\n        const width=gl.drawingBufferWidth,height=gl.drawingBufferHeight;\n        gl.bindTexture(gl.TEXTURE_2D,color);gl.texStorage2D(gl.TEXTURE_2D,1,gl.RGBA32F,width,height);\n        const depthType=gl.getFramebufferAttachmentParameter(gl.DRAW_FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE);\n        const depth=gl.getFramebufferAttachmentParameter(gl.DRAW_FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.FRAMEBUFFER_ATTACHMENT_OBJECT_NAME);\n        gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,framebuffer);\n        gl.framebufferTexture2D(gl.DRAW_FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,color,0);\n        if(cap.depth) {\n            if(depthType===gl.TEXTURE) gl.framebufferTexture2D(gl.DRAW_FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.TEXTURE_2D,depth,0);\n            else if(depthType===gl.RENDERBUFFER) gl.framebufferRenderbuffer(gl.DRAW_FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.RENDERBUFFER,depth);\n            else throw new Error('No shared scene depth attachment');\n        }\n        if(gl.checkFramebufferStatus(gl.DRAW_FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE) throw new Error('Overlap framebuffer incomplete');\n        const clipped=gl.isEnabled(gl.SCISSOR_TEST);disable.call(gl,gl.SCISSOR_TEST);\n        gl.clearBufferfv(gl.COLOR,0,new Float32Array(4));if(clipped)enable.call(gl,gl.SCISSOR_TEST);\n        gl.bindTexture(gl.TEXTURE_2D,texture);gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,original);\n        Object.assign(cap,{gl,color,framebuffer,width,height,draws:0});\n    };\n    p.drawElementsInstanced=function(mode,count,type,offset,instances) {\n        const program=programs.get(this),f=program && facts.get(program);\n        if(!f || count!==330) return draw.call(this,mode,count,type,offset,instances);\n        state.gl=this;\n        if(f.rootFast)this.uniform1i(f.rootFast,state.mode==='root-fast'?1:0);\n        state.counts.dominantDraws++;state.counts.dominantInstances+=instances;\n        const portal=state.mode.includes('no-portal'), constant=state.mode.includes('constant');\n        if(f.portal)this.uniform1i(f.portal,portal?1:0);\n        this.uniform1i(f.constant,constant?1:0);this.uniform1i(f.count,0);\n        if(state.firstDraw===null) {\n            const get=name=>{const u=this.getUniformLocation(program,name);return u===null?null:this.getUniform(program,u);};\n            const ordinal=get('uPortalRenderDomain');\n            const buffer=this.getIndexedParameter(this.UNIFORM_BUFFER_BINDING,0);\n            const old=this.getParameter(this.UNIFORM_BUFFER_BINDING);\n            const metadata=new Uint32Array(8);\n            this.bindBuffer(this.UNIFORM_BUFFER,buffer);\n            this.getBufferSubData(this.UNIFORM_BUFFER,64+255*32+ordinal*32,metadata);\n            this.bindBuffer(this.UNIFORM_BUFFER,old);\n            state.firstDraw={ordinal,scopeMetadata:Array.from(metadata),viewport:Array.from(this.getParameter(this.VIEWPORT)),alphaTest:get('uAlphaTest'),materialKind:get('uMaterialKind'),opacity:get('uOpacityScale'),depthTest:this.isEnabled(this.DEPTH_TEST),depthFunc:this.getParameter(this.DEPTH_FUNC),depthWrite:this.getParameter(this.DEPTH_WRITEMASK),cullFace:this.isEnabled(this.CULL_FACE),blend:blendState(this)};\n        }\n        const cap=state.capture;\n        if(cap) {\n            if(!cap.framebuffer)makeCounter(this,cap);\n            const oldFramebuffer=this.getParameter(this.DRAW_FRAMEBUFFER_BINDING),oldBlend=blendState(this),oldDepth=this.isEnabled(this.DEPTH_TEST);\n            this.bindFramebuffer(this.DRAW_FRAMEBUFFER,cap.framebuffer);\n            if(!cap.depth)disable.call(this,this.DEPTH_TEST);\n            enable.call(this,this.BLEND);this.blendEquation(this.FUNC_ADD);this.blendFunc(this.ONE,this.ONE);\n            this.uniform1i(f.count,cap.kind==='coverage'?2:cap.kind==='mismatch'?3:1);\n            draw.call(this,mode,count,type,offset,instances);cap.draws++;\n            this.uniform1i(f.count,0);this.bindFramebuffer(this.DRAW_FRAMEBUFFER,oldFramebuffer);restoreBlend(this,oldBlend);\n            (oldDepth?enable:disable).call(this,this.DEPTH_TEST);\n            return;\n        }\n        const noBlend=state.mode.includes('no-blend'),clip=state.mode==='scissor-half';\n        const wasBlend=noBlend?this.isEnabled(this.BLEND):false;\n        let oldClip,wasClipped;\n        if(noBlend)disable.call(this,this.BLEND);\n        if(clip) {\n            oldClip=Array.from(this.getParameter(this.SCISSOR_BOX));wasClipped=this.isEnabled(this.SCISSOR_TEST);\n            const width=this.drawingBufferWidth,height=this.drawingBufferHeight;\n            let x=Math.floor(width/4),y=Math.floor(height/4),right=x+Math.floor(width/2),top=y+Math.floor(height/2);\n            if(wasClipped){x=Math.max(x,oldClip[0]);y=Math.max(y,oldClip[1]);right=Math.min(right,oldClip[0]+oldClip[2]);top=Math.min(top,oldClip[1]+oldClip[3]);}\n            enable.call(this,this.SCISSOR_TEST);scissor.call(this,x,y,Math.max(0,right-x),Math.max(0,top-y));\n        }\n        draw.call(this,mode,count,type,offset,instances);\n        if(noBlend && wasBlend)enable.call(this,this.BLEND);\n        if(clip){scissor.call(this,...oldClip);if(!wasClipped)disable.call(this,this.SCISSOR_TEST);}\n    };\n    state.startCounter=(kind,depth)=>{state.mode='normal';state.capture={kind,depth};};\n    state.finishCounter=()=>{\n        const cap=state.capture;state.capture=null;\n        if(!cap?.framebuffer)throw new Error('Overlap capture saw no dominant draws');\n        const gl=cap.gl,read=gl.getParameter(gl.READ_FRAMEBUFFER_BINDING);\n        gl.bindFramebuffer(gl.READ_FRAMEBUFFER,cap.framebuffer);gl.readBuffer(gl.COLOR_ATTACHMENT0);\n        const pixels=new Float32Array(cap.width*cap.height*4);gl.readPixels(0,0,cap.width,cap.height,gl.RGBA,gl.FLOAT,pixels);\n        const error=gl.getError();gl.bindFramebuffer(gl.READ_FRAMEBUFFER,read);\n        gl.deleteFramebuffer(cap.framebuffer);gl.deleteTexture(cap.color);\n        if(error!==gl.NO_ERROR)throw new Error('Overlap readback GL error '+error);\n        let sum=0,max=0,covered=0;const histogram={};\n        for(let i=0;i<pixels.length;i+=4){const n=pixels[i];sum+=n;max=Math.max(max,n);if(n>0)covered++;histogram[n]=(histogram[n]??0)+1;}\n        return {kind:cap.kind,depth:cap.depth,width:cap.width,height:cap.height,draws:cap.draws,sum,max,covered,mean:sum/(cap.width*cap.height),histogram};\n    };\n    state.inspectEnvelope=()=>{\n        const gl=state.gl;if(!gl)throw new Error('No particle context');\n        if(!gl.getExtension('EXT_color_buffer_float'))throw new Error('Float color target unavailable');\n        const saved={program:gl.getParameter(gl.CURRENT_PROGRAM),vao:gl.getParameter(gl.VERTEX_ARRAY_BINDING),draw:gl.getParameter(gl.DRAW_FRAMEBUFFER_BINDING),read:gl.getParameter(gl.READ_FRAMEBUFFER_BINDING),viewport:Array.from(gl.getParameter(gl.VIEWPORT)),texture:gl.getParameter(gl.TEXTURE_BINDING_2D)};\n        const capabilities=[gl.BLEND,gl.DEPTH_TEST,gl.SCISSOR_TEST,gl.CULL_FACE,gl.STENCIL_TEST].map(cap=>[cap,gl.isEnabled(cap)]);\n        const compile=(kind,source)=>{const s=gl.createShader(kind);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(s));return s;};\n        const vs=compile(gl.VERTEX_SHADER,'#version 300 es\\nvoid main(){vec2 p=gl_VertexID==0?vec2(-1.,-1.):gl_VertexID==1?vec2(3.,-1.):vec2(-1.,3.);gl_Position=vec4(p,0.,1.);}');\n        const fs=compile(gl.FRAGMENT_SHADER,'#version 300 es\\nprecision highp float;uniform sampler2D envelope;out vec4 color;void main(){float d=texelFetch(envelope,ivec2(gl_FragCoord.xy),0).r;color=vec4(d,d,d,1.);}');\n        const program=gl.createProgram();gl.attachShader(program,vs);gl.attachShader(program,fs);gl.linkProgram(program);\n        if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(program));\n        const width=gl.drawingBufferWidth,height=gl.drawingBufferHeight;\n        const color=gl.createTexture(),framebuffer=gl.createFramebuffer();gl.bindTexture(gl.TEXTURE_2D,color);gl.texStorage2D(gl.TEXTURE_2D,1,gl.RGBA32F,width,height);gl.bindTexture(gl.TEXTURE_2D,saved.texture);\n        gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,framebuffer);gl.framebufferTexture2D(gl.DRAW_FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,color,0);\n        if(gl.checkFramebufferStatus(gl.DRAW_FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw new Error('Envelope readback framebuffer incomplete');\n        for(const [cap] of capabilities)disable.call(gl,cap);\n        gl.viewport(0,0,width,height);gl.useProgram(program);gl.uniform1i(gl.getUniformLocation(program,'envelope'),5);gl.bindVertexArray(null);gl.drawArrays(gl.TRIANGLES,0,3);\n        gl.bindFramebuffer(gl.READ_FRAMEBUFFER,framebuffer);gl.readBuffer(gl.COLOR_ATTACHMENT0);\n        const pixels=new Float32Array(width*height*4);gl.readPixels(0,0,width,height,gl.RGBA,gl.FLOAT,pixels);const error=gl.getError();\n        gl.useProgram(saved.program);gl.bindVertexArray(saved.vao);gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,saved.draw);gl.bindFramebuffer(gl.READ_FRAMEBUFFER,saved.read);gl.viewport(...saved.viewport);\n        for(const [cap,on] of capabilities)(on?enable:disable).call(gl,cap);\n        gl.deleteFramebuffer(framebuffer);gl.deleteTexture(color);gl.deleteProgram(program);gl.deleteShader(vs);gl.deleteShader(fs);\n        if(error!==gl.NO_ERROR)throw new Error('Envelope readback GL error '+error);\n        let uncovered=0,unbounded=0,finite=0,minFinite=Infinity,maxFinite=-Infinity;\n        for(let i=0;i<pixels.length;i+=4){const d=pixels[i];if(d===0)uncovered++;else if(d===1)unbounded++;else{finite++;minFinite=Math.min(minFinite,d);maxFinite=Math.max(maxFinite,d);}}\n        return {width,height,uncovered,unbounded,finite,minFinite,maxFinite};\n    };\n\n}\n");
	await waitFor(
		client,
		`() => document.body?.innerText.includes("Choose a character")`,
		timeoutMs,
		"character selection",
	);
	const selectedCharacter = await evaluate(
		client,
		`() => {
			const character = document.querySelector(".client-character");
			if (!character) throw new Error("No character is available for the probe.");
			const label = character.textContent.trim();
			character.click();
			return label;
		}`,
	);
	printReport({ selectedCharacter });
	await evaluate(
		client,
		`() => [...document.querySelectorAll("button")].find((button) => button.textContent?.includes("Enter World"))?.click()`,
	);
	const initial = await waitForReady(
		client,
		timeoutMs,
		"initial world entry",
		true,
	);
	if (!initial.ready) {
		throw new Error("Initial world entry did not produce a destination frame.");
	}

	if (streamingOptions !== null) {
		const result = await runClientStreamingProbe(
			client,
			{ evaluate, submitChat, waitForReady, pageState },
			streamingOptions,
		);
		await writeFile(
			streamingOptions.reportPath,
			stringifyRedactedProbeReport(
				{
					...result,
					selectedCharacter,
					consoleMessages: [...consoleMessages.values()],
					page: await pageState(client),
					hostOutput: redact(output).slice(-30000),
				},
				{ account, password },
			),
		);
		printReport({ ok: result.ok, trials: result.trials.length });
		process.exitCode = result.ok ? 0 : 1;
	} else if (mode === "inventory") {
		await evaluate(
			client,
			`() => document.querySelector('button[aria-label="Inventory"]').click()`,
		);
		await waitFor(
			client,
			`() => {
            const panel = document.querySelector('.client-inventory');
            const images = [...document.querySelectorAll('.client-inventory img.ui-icon')];
            return panel?.getAttribute('aria-busy') === 'false' && images.length > 0 &&
                images.every(image => image.complete && image.naturalWidth === 32);
        }`,
			timeoutMs,
			"decoded inventory artwork",
		);
		const inventoryState = `() => ({
            images: [...document.querySelectorAll('.client-inventory img.ui-icon')].map(image => ({
                guid: image.closest('[data-item-guid]').getAttribute('data-item-guid'),
                url: image.src, width: image.naturalWidth, height: image.naturalHeight,
                count: image.closest("[data-item-guid]").querySelector(".item-count-overlay")?.textContent ?? null,
            })),
            fallbacks: document.querySelectorAll('.client-inventory .ui-icon-fallback').length,
            containers: [...document.querySelectorAll('.client-inventory section')].map(section => section.getAttribute('aria-label')),
        })`;
		const before = await evaluate(client, inventoryState);
		await evaluate(
			client,
			`() => document.querySelector('button[aria-label="Close Inventory"]').click()`,
		);
		await delay(1000);
		await evaluate(
			client,
			`() => document.querySelector('button[aria-label="Inventory"]').click()`,
		);
		await waitFor(
			client,
			`() => document.querySelector('.client-inventory img.ui-icon') !== null`,
			timeoutMs,
			"reopened inventory",
		);
		const after = await evaluate(client, inventoryState);
		const retained =
			JSON.stringify(before.images) === JSON.stringify(after.images);
		const screenshotPath = await captureScreenshot(client);
		printReport({
			ok: retained,
			mode,
			before,
			after,
			retained,
			screenshotPath,
			consoleMessages: [...consoleMessages.values()],
			page: await pageState(client),
		});
		process.exitCode = retained ? 0 : 1;
	} else if (mode === "profile") {


        await delay(PROFILE_SETTLE_MS);
        if([...consoleMessages.values()].some(m=>m.level==='exception'||m.level==='error'))throw new Error('Browser error before measurement');
        await evaluate(client, `() => window.__holtburgerClientPerformance.setRendererProfilingEnabled(true)`);
        const modes=['normal','root-fast','no-portal'];
        const trials=[];
        for(let round=0;round<5;round++) {
            const order=round%2?[...modes].reverse():modes.slice(round).concat(modes.slice(0,round));
            for(const mode of order) {
                await evaluate(client, `() => {window.__fragmentAudit.mode=${JSON.stringify(mode)};}`);
                await delay(1000);
                await evaluate(client, `() => {window.__fragmentAudit.counts={dominantDraws:0,dominantInstances:0};window.__holtburgerClientPerformance.reset();}`);
                const start=Date.now();await delay(3000);
                const result=await evaluate(client, `() => ({snapshot:window.__holtburgerClientPerformance.snapshot(),counts:window.__fragmentAudit.counts,firstDraw:window.__fragmentAudit.firstDraw})`);
                if(result.firstDraw.ordinal!==0 || result.firstDraw.scopeMetadata.slice(0,4).some(x=>x!==0))throw new Error('Root tile mapping differs from diagnostic preconditions');
                const gpu=result.snapshot.diagnostics.renderer.profile?.gpu?.mean;
                if(!gpu||result.snapshot.sampledFrameCount===0)throw new Error('No valid GPU profile');
                trials.push({round,mode,windowMs:Date.now()-start,...result});
                await writeFile('/tmp/h3d-root-fast-costs.json',stringifyRedactedProbeReport({trials,consoleMessages:[...consoleMessages.values()]},{account,password}));
                printReport({round,mode,particleGpuMs:gpu.particleMs,totalGpuMs:gpu.totalMs,counts:result.counts,frames:result.snapshot.sampledFrameCount});
            }
        }
        await evaluate(client, `() => {window.__fragmentAudit.mode='normal';window.__holtburgerClientPerformance.setRendererProfilingEnabled(false);}`);
        await delay(1000);
        const envelope=await evaluate(client, `() => window.__fragmentAudit.inspectEnvelope()`);
        await writeFile('/tmp/h3d-outdoor-envelope.json',JSON.stringify(envelope));
        const overlap=[];
        for(const [kind,depth] of [['visible',true],['coverage',true],['coverage',false],['mismatch',true]]) {
            const result=await evaluate(client, `async () => {
                const state=window.__fragmentAudit;state.startCounter(${JSON.stringify(kind)},${depth});
                await new Promise(resolve=>requestAnimationFrame(resolve));return state.finishCounter();
            }`);
            overlap.push(result);printReport({capture:kind,depth,mean:result.mean,max:result.max,draws:result.draws});
        }
        await writeFile('/tmp/h3d-root-overlap-counters.json',JSON.stringify(overlap));
        printReport({ok:true,reportPath:'/tmp/h3d-root-fast-costs.json',overlapPath:'/tmp/h3d-root-overlap-counters.json'});

	} else if (mode === "passive-camera") {
		await delay(PASSIVE_CAMERA_SETTLE_MS);
		const cameraEvidence = await capturePassiveCameraGesture(client);
		const cameraSummary = summarizeCameraEvidence(cameraEvidence);
		const screenshotPath = await captureScreenshot(client);
		const captureComplete =
			cameraSummary.inputEventCount === PASSIVE_CAMERA_INPUT_COUNT &&
			cameraSummary.cameraEventCount > 0 &&
			cameraSummary.animationFrameCount > 0;
		printReport({
			ok: captureComplete,
			mode,
			commands: [],
			teleports: [],
			cameraEvidence: cameraSummary,
			screenshotPath,
			consoleMessages: [...consoleMessages.values()],
			page: await pageState(client),
			hostOutput: redact(output).slice(-30_000),
		});
		process.exitCode = captureComplete ? 0 : 1;
	} else if (mode === "precise-jump") {
		const preciseJump = await capturePreciseJumpEntry(client, timeoutMs);
		const responsive =
			preciseJump.sweep.evaluationCount > 1 &&
			Number.isFinite(preciseJump.sweep.postStopLatencyMs);
		printReport({
			ok:
				responsive &&
				preciseJump.page.error === null &&
				!preciseJump.webgl.contextLost,
			mode,
			commands: [],
			teleports: [],
			preciseJump,
			consoleMessages: [...consoleMessages.values()],
			page: preciseJump.page,
			hostOutput: redact(output).slice(-30_000),
		});
		process.exitCode =
			responsive &&
			preciseJump.page.error === null &&
			!preciseJump.webgl.contextLost
				? 0
				: 1;
	} else {
		commands ??= defaultTeleportSequence(initial.lastState.bodyText);

		for (const command of commands) {
			const before = await pageState(client);
			await submitChat(client, command);
			const outcome = await waitForReady(
				client,
				timeoutMs,
				command,
				true,
				before.camera?.cameraGeneration ?? null,
			);
			const generation = outcome.lastState.camera?.cameraGeneration;
			const cameraGeneration = outcome.lastState.cameraGenerations.find(
				(evidence) => evidence.cameraGeneration === generation,
			);
			const provenInitialReseed =
				cameraGeneration?.first.kind === "reseeded" &&
				cameraGeneration.first.reason === "initial-placement" &&
				cameraGeneration.first.clearance !== null;
			const lastState = {
				notice: outcome.lastState.notice,
				error: outcome.lastState.error,
				camera: outcome.lastState.camera,
				bodyText: outcome.lastState.bodyText,
			};
			hops.push({
				command,
				ready: outcome.ready,
				elapsedMs: outcome.elapsedMs,
				lastState,
				cameraGeneration,
				provenInitialReseed,
			});
			if (!outcome.ready) break;
		}

		printReport({
			ok:
				hops.length === commands.length &&
				hops.every((hop) => hop.ready && hop.provenInitialReseed),
			hops,
			consoleMessages: [...consoleMessages.values()],
			page: await pageState(client),
			hostOutput: redact(output).slice(-30_000),
		});
	}
} catch (error) {
	printReport({
		ok: false,
		error: safeError(error),
		hops,
		consoleMessages: [...consoleMessages.values()],
		page:
			client === undefined ? null : await pageState(client).catch(() => null),
		hostOutput: redact(output).slice(-12_000),
	});
	process.exitCode = 1;
} finally {
	if (client !== undefined) {
		try {
			await evaluate(
				client,
				`async () => window.holtburgerHost.invoke("disconnect_client")`,
			);
			printReport({ cleanup: "disconnected" });
		} catch (error) {
			printReport({ cleanupError: safeError(error) });
			process.exitCode = 1;
		}
	}
	client?.close();
	if (child.exitCode === null && child.signalCode === null)
		child.kill("SIGTERM");
}

// Both camera and profiling probes can retain the rendered frame they measured.
async function captureScreenshot(client_) {
	const path = process.env.HOLTBURGER_PROBE_SCREENSHOT;
	if (path === undefined) return null;
	await client_.send("Page.enable");
	const screenshot = await client_.send("Page.captureScreenshot", {
		format: "png",
	});
	await writeFile(path, screenshot.data, "base64");
	return path;
}

function requiredEnvironment(name) {
	const value = process.env[name];
	if (value === undefined || value.length === 0)
		throw new Error(`${name} must be set.`);
	return value;
}

function probeMode(value) {
	if (value === undefined) {
		throw new Error(
			"HOLTBURGER_PROBE_MODE must be explicitly set to teleport, passive-camera, precise-jump, profile, inventory, or streaming.",
		);
	}
	const mode = value;
	if (
		mode !== "teleport" &&
		mode !== "passive-camera" &&
		mode !== "precise-jump" &&
		mode !== "profile" &&
		mode !== "inventory" &&
		mode !== "streaming"
	) {
		throw new Error(
			"HOLTBURGER_PROBE_MODE must be teleport, passive-camera, precise-jump, profile, inventory, or streaming.",
		);
	}
	return mode;
}

function parseCommands(value) {
	const parsed = value
		.split("|")
		.map((command) => command.trim())
		.filter((command) => command.length > 0);
	if (
		parsed.length === 0 ||
		parsed.some((command) => !command.startsWith("@"))
	) {
		throw new Error(
			"Teleport sequence must contain pipe-separated chat commands.",
		);
	}
	return parsed;
}

function defaultTeleportSequence(bodyText) {
	if (bodyText.includes("22.0S, 2.0W")) {
		return parseCommands(
			"@teledungeon 0288|@tele 22s 2w|@teledungeon 0288|@tele 22s 2w",
		);
	}
	return parseCommands(
		"@tele 22s 2w|@teledungeon 0288|@tele 22s 2w|@teledungeon 0288",
	);
}

function redact(value) {
	return value
		.replaceAll(account, "<account>")
		.replaceAll(password, "<password>");
}

function safeError(error) {
	return redact(error instanceof Error ? error.message : String(error));
}

function printReport(report) {
	console.log(
		stringifyRedactedProbeReport(report, {
			account,
			password,
		}),
	);
}

function recordConsoleMessage(message) {
	const key = `${message.level}\u0000${message.text}`;
	const previous = consoleMessages.get(key);
	consoleMessages.set(key, {
		...message,
		count: (previous?.count ?? 0) + 1,
	});
}

function delay(milliseconds) {
	return new Promise((resolvePromise) =>
		setTimeout(resolvePromise, milliseconds),
	);
}

function summarizePerformanceSnapshot(snapshot) {
	const profile = snapshot.diagnostics.renderer?.profile;
	return {
		frameRates: snapshot.frameRates,
		meanFrameWorkMs: snapshot.meanFrameWorkMs,
		renderedFrames: snapshot.sampledFrameCount,
		rendererCpuMean: profile?.cpu.mean ?? null,
		rendererGpuMean:
			profile?.gpu.kind === "available" ? profile.gpu.mean : null,
		runtimeTickMean: snapshot.diagnostics.tickProfile?.mean ?? null,
		selectionMetrics: snapshot.diagnostics.renderer?.selectionMetrics ?? null,
		dynamicResources: snapshot.diagnostics.renderer?.dynamicResources ?? null,
		viewport: snapshot.diagnostics.viewport,
		playerResidency: snapshot.diagnostics.playerResidency,
		cameraResidency: snapshot.diagnostics.cameraResidency,
	};
}

async function waitForDevToolsUrl(process_, readOutput) {
	const startedAt = Date.now();
	for (;;) {
		const match = readOutput().match(/DevTools listening on (ws:\/\/[^\s]+)/);
		if (match?.[1]) return match[1];
		if (process_.exitCode !== null || process_.signalCode !== null) {
			throw new Error("Electron exited before opening its DevTools endpoint.");
		}
		if (Date.now() - startedAt >= 60_000) {
			throw new Error("Timed out waiting for Electron DevTools endpoint.");
		}
		await delay(100);
	}
}

async function waitForPageWebSocketUrl(browserWebSocketUrl) {
	const { port } = new URL(browserWebSocketUrl);
	const startedAt = Date.now();
	for (;;) {
		const targets = await fetch(`http://127.0.0.1:${port}/json/list`, {
			signal: AbortSignal.timeout(10_000),
		}).then((response) => response.json());
		const page = targets.find(
			(target) => target.type === "page" && target.url.includes("/client/"),
		);
		if (page?.webSocketDebuggerUrl) return page.webSocketDebuggerUrl;
		if (Date.now() - startedAt >= 60_000) {
			throw new Error("Timed out waiting for the Electron client page.");
		}
		await delay(100);
	}
}

async function evaluate(client_, expression) {
	const result = await client_.send("Runtime.evaluate", {
		expression: `(${expression})()`,
		awaitPromise: true,
		returnByValue: true,
	});
	if (result.exceptionDetails) throw new Error(result.exceptionDetails.text);
	return result.result.value;
}

async function waitFor(client_, predicate, milliseconds, description) {
	const startedAt = Date.now();
	for (;;) {
		if (await evaluate(client_, predicate)) return;
		if (Date.now() - startedAt >= milliseconds) {
			throw new Error(`Timed out waiting for ${description}.`);
		}
		await delay(100);
	}
}

async function installEvidenceCollector(client_) {
	await evaluate(
		client_,
		`async () => {
			const bridge = window.holtburgerHost;
			if (bridge === undefined) throw new Error("Electron host bridge is unavailable.");
			const evidence = {
				camera: null,
				cameraGenerations: [],
				lifecycle: null,
				lifecycles: [],
				collecting: false,
				cameraEvents: [],
				animationFrames: [],
				inputEvents: [],
				preciseJumpEvaluations: [],
				preciseJumpEvaluationTimes: [],
			};
			Object.defineProperty(window, "__holtburgerProbeEvidence", {
				configurable: true,
				value: evidence,
			});
			await bridge.listen("client-camera", (tick) => {
				if (evidence.collecting) evidence.cameraEvents.push(performance.now());
				const pathEnd = tick.path.legs.at(-1)?.end.position ?? tick.path.initial.position;
				const summary = {
					cameraGeneration: tick.cameraGeneration,
					sequence: tick.sequence,
					kind: tick.kind,
					reason: tick.reason ?? null,
					clearance: tick.clearance ?? null,
					initialLandblockId: tick.path.initial.position.landblockId,
					finalLandblockId: pathEnd.landblockId,
					position: pathEnd,
				};
				evidence.camera = summary;
				const generation = evidence.cameraGenerations.find(
					(candidate) => candidate.cameraGeneration === tick.cameraGeneration,
				);
				if (generation === undefined) {
					evidence.cameraGenerations.push({
						cameraGeneration: tick.cameraGeneration,
						first: summary,
						latest: summary,
					});
				} else {
					generation.latest = summary;
				}
			});
			await bridge.listen("client-lifecycle-changed", (lifecycle) => {
				evidence.lifecycle = lifecycle;
				evidence.lifecycles.push(lifecycle);
			});
			await bridge.listen("client-precise-jump-evaluation", (evaluation) => {
				evidence.preciseJumpEvaluations.push(evaluation);
				evidence.preciseJumpEvaluationTimes.push(performance.now());
			});
			const collectAnimationFrame = (timestamp) => {
				if (evidence.collecting) evidence.animationFrames.push(timestamp);
				requestAnimationFrame(collectAnimationFrame);
			};
			requestAnimationFrame(collectAnimationFrame);
		}`,
	);
}

async function capturePreciseJumpEntry(client_, milliseconds) {
	// World-ready notices precede gameplay input admission during portal-space activation.
	await waitFor(
		client_,
		"() => window.__holtburgerProbeEvidence.lifecycle?.kind === 'in-world'",
		milliseconds,
		"in-world precise-jump input",
	);
	const bounds = await evaluate(
		client_,
		`() => {
			const canvas = document.querySelector(".client-canvas");
			if (!(canvas instanceof HTMLCanvasElement)) {
				throw new Error("Client canvas is unavailable.");
			}
			canvas.focus();
			const rect = canvas.getBoundingClientRect();
			window.__holtburgerProbeEvidence.preciseJumpEvaluations = [];
			window.__holtburgerProbeEvidence.preciseJumpEvaluationTimes = [];
			return { x: rect.x, y: rect.y, width: rect.width, height: rect.height };
		}`,
	);
	const x = bounds.x + bounds.width * 0.5;
	const y = bounds.y + bounds.height * 0.6;
	await client_.send("Input.dispatchMouseEvent", {
		type: "mouseMoved",
		x,
		y,
		button: "none",
		buttons: 0,
	});
	await evaluate(
		client_,
		`() => {
			const dispatch = (type, key, shiftKey) =>
				window.dispatchEvent(
					new KeyboardEvent(type, { bubbles: true, key, shiftKey }),
				);
			dispatch("keydown", "J", true);
			dispatch("keyup", "J", false);
		}`,
	);
	const startedAt = Date.now();
	for (;;) {
		const state = await evaluate(
			client_,
			`() => ({
				evaluations: window.__holtburgerProbeEvidence.preciseJumpEvaluations,
				error: document.querySelector('[role="alert"]')?.textContent?.trim() ?? null,
			})`,
		);
		if (
			state.evaluations.some(
				(evaluation) => evaluation.phase === "completed",
			) ||
			state.error !== null
		)
			break;
		if (Date.now() - startedAt >= milliseconds) {
			throw new Error("Timed out waiting for precise-jump evaluation.");
		}
		await delay(100);
	}
	const sweepStartedAt = await evaluate(client_, "() => performance.now()");
	for (let index = 0; index < PRECISE_JUMP_SWEEP_INPUT_COUNT; index += 1) {
		const fraction = index / (PRECISE_JUMP_SWEEP_INPUT_COUNT - 1);
		await client_.send("Input.dispatchMouseEvent", {
			type: "mouseMoved",
			x: bounds.x + bounds.width * (0.35 + fraction * 0.3),
			y: bounds.y + bounds.height * 0.6,
			button: "none",
			buttons: 0,
		});
		await delay(PRECISE_JUMP_SWEEP_INPUT_INTERVAL_MS);
	}
	const stoppedAt = await evaluate(client_, "() => performance.now()");
	await waitFor(
		client_,
		`() => window.__holtburgerProbeEvidence.preciseJumpEvaluations.some(
            (evaluation, index) => evaluation.phase === "completed" && window.__holtburgerProbeEvidence.preciseJumpEvaluationTimes[index] >= ${stoppedAt},
		)`,
		milliseconds,
		"post-sweep precise-jump evaluation",
	);
	await delay(100);
	const result = await evaluate(
		client_,
		`() => {
			const canvas = document.querySelector(".client-canvas");
			const gl = canvas instanceof HTMLCanvasElement ? canvas.getContext("webgl2") : null;
			return {
				evaluations: window.__holtburgerProbeEvidence.preciseJumpEvaluations,
				evaluationTimes: window.__holtburgerProbeEvidence.preciseJumpEvaluationTimes,
				page: {
					notice: document.querySelector(".client-toast")?.textContent?.trim() ?? null,
					error: document.querySelector('[role="alert"]')?.textContent?.trim() ?? null,
				},
				webgl: {
					contextLost: gl?.isContextLost() ?? true,
					renderer: gl?.getParameter(gl.RENDERER) ?? null,
					vendor: gl?.getParameter(gl.VENDOR) ?? null,
				},
			};
		}`,
	);
	const sweepEvaluationTimes = result.evaluationTimes.filter(
		(time) => time >= sweepStartedAt,
	);
	return {
		...result,
		sweep: {
			inputCount: PRECISE_JUMP_SWEEP_INPUT_COUNT,
			durationMs: stoppedAt - sweepStartedAt,
			evaluationCount: sweepEvaluationTimes.length,
			maximumEvaluationGapMs: maximumAdjacentGap(sweepEvaluationTimes),
			postStopLatencyMs:
				sweepEvaluationTimes.find((time) => time >= stoppedAt) - stoppedAt,
		},
	};
}

function maximumAdjacentGap(values) {
	let maximum = 0;
	for (let index = 1; index < values.length; index += 1) {
		maximum = Math.max(maximum, values[index] - values[index - 1]);
	}
	return maximum;
}

async function capturePassiveCameraGesture(client_) {
	const bounds = await evaluate(
		client_,
		`() => {
			const canvas = document.querySelector(".client-canvas");
			if (!(canvas instanceof HTMLCanvasElement)) {
				throw new Error("Client canvas is unavailable.");
			}
			const rect = canvas.getBoundingClientRect();
			const evidence = window.__holtburgerProbeEvidence;
			evidence.cameraEvents = [];
			evidence.animationFrames = [];
			evidence.inputEvents = [];
			evidence.collecting = true;
			return { x: rect.x, y: rect.y, width: rect.width, height: rect.height };
		}`,
	);
	const startX = bounds.x + bounds.width * 0.45;
	const startY = bounds.y + bounds.height * 0.5;
	await client_.send("Input.dispatchMouseEvent", {
		type: "mousePressed",
		x: startX,
		y: startY,
		button: "left",
		buttons: 1,
		clickCount: 1,
	});
	for (let step = 1; step <= PASSIVE_CAMERA_INPUT_COUNT; step += 1) {
		await evaluate(
			client_,
			"() => window.__holtburgerProbeEvidence.inputEvents.push(performance.now())",
		);
		await client_.send("Input.dispatchMouseEvent", {
			type: "mouseMoved",
			x: startX + step * 2,
			y: startY + Math.sin(step / 6) * 12,
			button: "left",
			buttons: 1,
		});
		await delay(PASSIVE_CAMERA_INPUT_INTERVAL_MS);
	}
	await client_.send("Input.dispatchMouseEvent", {
		type: "mouseReleased",
		x: startX + 80,
		y: startY,
		button: "left",
		buttons: 0,
		clickCount: 1,
	});
	await delay(2_000);
	return evaluate(
		client_,
		`() => {
			const evidence = window.__holtburgerProbeEvidence;
			evidence.collecting = false;
			return {
				cameraEvents: evidence.cameraEvents,
				animationFrames: evidence.animationFrames,
				inputEvents: evidence.inputEvents,
			};
		}`,
	);
}

function summarizeCameraEvidence(evidence) {
	const cameraIntervals = intervals(evidence.cameraEvents);
	const animationFrameIntervals = intervals(evidence.animationFrames);
	const inputLatencies = evidence.inputEvents.flatMap((input) => {
		const camera = evidence.cameraEvents.find((event) => event >= input);
		return camera === undefined ? [] : [camera - input];
	});
	return {
		cameraEventCount: evidence.cameraEvents.length,
		animationFrameCount: evidence.animationFrames.length,
		inputEventCount: evidence.inputEvents.length,
		cameraIntervalMs: distribution(cameraIntervals),
		animationFrameIntervalMs: distribution(animationFrameIntervals),
		// This measures the next publication, not a causal acknowledgement of orbit input.
		inputToNextCameraEventMs: distribution(inputLatencies),
	};
}

function intervals(values) {
	return values.slice(1).map((value, index) => value - values[index]);
}

function distribution(values) {
	if (values.length === 0) return null;
	const sorted = [...values].sort((left, right) => left - right);
	const percentile = (fraction) =>
		sorted[
			Math.min(
				sorted.length - 1,
				Math.max(0, Math.ceil(sorted.length * fraction) - 1),
			)
		];
	return {
		count: sorted.length,
		mean: sorted.reduce((total, value) => total + value, 0) / sorted.length,
		p50: percentile(0.5),
		p95: percentile(0.95),
		max: sorted.at(-1),
	};
}

async function submitChat(client_, message) {
	await evaluate(
		client_,
		`() => {
			const input = document.querySelector('input[aria-label="Chat message"]');
			if (!(input instanceof HTMLInputElement)) throw new Error("Chat input is unavailable.");
			const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
			setter?.call(input, ${JSON.stringify(message)});
			input.dispatchEvent(new Event("input", { bubbles: true }));
			input.form?.requestSubmit();
		}`,
	);
}

async function waitForReady(
	client_,
	milliseconds,
	description,
	requireLoading,
	previousCameraGeneration = null,
) {
	const startedAt = Date.now();
	let sawLoading = false;
	for (;;) {
		const state = await pageState(client_);
		if (state.notice !== null && state.notice !== WORLD_READY_NOTICE) {
			sawLoading = true;
		}
		const hasCurrentCamera =
			state.camera !== null &&
			(previousCameraGeneration === null ||
				state.camera.cameraGeneration !== previousCameraGeneration);
		if (
			state.notice === WORLD_READY_NOTICE &&
			hasCurrentCamera &&
			(!requireLoading || sawLoading)
		) {
			return {
				ready: true,
				elapsedMs: Date.now() - startedAt,
				lastState: state,
			};
		}
		if (Date.now() - startedAt >= milliseconds) {
			return {
				ready: false,
				elapsedMs: Date.now() - startedAt,
				lastState: state,
			};
		}
		await delay(100);
	}
}

function pageState(client_) {
	return evaluate(
		client_,
		`() => ({
			notice: document.querySelector(".client-toast")?.textContent?.trim() ?? null,
			error: document.querySelector('[role="alert"]')?.textContent?.trim() ?? null,
			camera: window.__holtburgerProbeEvidence?.camera ?? null,
			cameraGenerations: window.__holtburgerProbeEvidence?.cameraGenerations ?? [],
			lifecycle: window.__holtburgerProbeEvidence?.lifecycle ?? null,
			lifecycles: window.__holtburgerProbeEvidence?.lifecycles ?? [],
			bodyText: document.body?.innerText.slice(0, 4000) ?? "",
		})`,
	);
}
