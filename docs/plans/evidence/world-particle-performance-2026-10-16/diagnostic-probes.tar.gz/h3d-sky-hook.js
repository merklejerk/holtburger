() => {
    const p = WebGL2RenderingContext.prototype;
    const source = p.shaderSource, bind = p.useProgram, draw = p.drawElementsInstanced;
    const programs = new WeakMap(), facts = new WeakMap();
    const state = window.__skyProbe = {mode:'normal', patchedShaders:0, programFacts:[],counts:{skyDraws:0,worldDraws:0,skyInstances:0,worldInstances:0,skyTriangles:0,worldTriangles:0}};
    p.shaderSource = function(shader, text) {
        if (text.includes('uniform highp sampler2D uParticleRecords;')) {
            const expression = 'aPosition * scale';
            if (!text.includes(expression)) throw new Error('Particle size expression changed');
            text = text.replace('uniform highp sampler2D uParticleRecords;', 'uniform highp sampler2D uParticleRecords;\nuniform float uDiagnosticParticleSize;').replace(expression, 'aPosition * scale * uDiagnosticParticleSize');
            state.patchedShaders++;
        }
        return source.call(this, shader, text);
    };
    p.useProgram = function(program) {
        programs.set(this, program);
        if (program && !facts.has(program)) {
            const particle = this.getUniformLocation(program,'uParticleRecords') !== null;
            if (particle) {
                const sky = this.getUniformLocation(program,'uPortalRenderDomain') === null;
                const size = this.getUniformLocation(program,'uDiagnosticParticleSize');
                if (size === null) throw new Error('Particle shader missed diagnostic size injection');
                facts.set(program,{sky,size});
                state.programFacts.push({sky});
            } else facts.set(program,null);
        }
        return bind.call(this,program);
    };
    p.drawElementsInstanced = function(mode,count,type,offset,instances) {
        const program = programs.get(this), f = program && facts.get(program);
        if (f) {
            const prefix = f.sky ? 'sky' : 'world';
            state.counts[prefix+'Draws']++;
            state.counts[prefix+'Instances'] += instances;
            state.counts[prefix+'Triangles'] += count/3*instances;
            if ((f.sky && state.mode === 'skip-sky') || (!f.sky && state.mode === 'skip-world')) return;
            const factor = f.sky && state.mode.startsWith('size-') ? Number(state.mode.slice(5)) : 1;
            this.uniform1f(f.size, factor);
        }
        return draw.call(this,mode,count,type,offset,instances);
    };
}
