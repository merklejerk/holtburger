from pathlib import Path
import gzip,hashlib,io,json,statistics,tarfile
root=Path('/home/me/code/holtburger');base=root/'docs/plans/evidence/world-particle-performance-2026-10-16';m=json.loads((base/'manifest.json').read_text());removed=set(m['sanitization']['removedKeys'])
def clean(v):
 if isinstance(v,list):return [clean(x)for x in v]
 if isinstance(v,dict):
  out={k:clean(x)for k,x in v.items()if k not in removed}
  if 'consoleMessages'in out:out['consoleMessages']=[{'level':x['level'],'count':x.get('count',1)}for x in v['consoleMessages']]
  return out
 return v
def packed(v):return(json.dumps(v,indent=2)+'\n').encode()
def digest(v):return hashlib.sha256(v).hexdigest()
def add(name,data,kind,sources):
 (base/name).write_bytes(data);m['files']=[f for f in m['files']if f['path']!=name]+[{'path':name,'bytes':len(data),'sha256':digest(data),'kind':kind,'sources':sources}]
def stats(v):return{'median':statistics.median(v),'min':min(v),'max':max(v)}
r=clean(json.loads(Path('/tmp/h3d-door-spot.json').read_text()));assert len(r['trials'])==5 and not r['context']['diagnosticGlobalsPresent']
assert all(t['camera']['position']==r['context']['camera']['position']for t in r['trials'])
sel=lambda t:t['snapshot']['diagnostics']['renderer']['selectionMetrics']
assert all(sel(t)['portalSelectedCrossingCount']>0 and sel(t)['portalSelectedScopeCount']>1 for t in r['trials']);assert r['context']['matrixCapture']['hooksRestored']
getters={'frameWorkMs':lambda t:t['snapshot']['meanFrameWorkMs'],'rendererCpuMs':lambda t:t['snapshot']['diagnostics']['renderer']['profile']['cpu']['mean']['totalMs'],'particleGpuMs':lambda t:t['snapshot']['diagnostics']['renderer']['profile']['gpu']['mean']['particleMs'],'gpuMs':lambda t:t['snapshot']['diagnostics']['renderer']['profile']['gpu']['mean']['totalMs'],'observedFps':lambda t:t['snapshot']['sampledFrameCount']*1000/t['windowMs'],'visibleDynamicEntities':lambda t:sel(t)['visibleDynamicEntityCount'],'particleBatches':lambda t:sel(t)['submittedParticleBatchCount'],'particleInstances':lambda t:sel(t)['submittedParticleInstanceCount']}
assets={str(p.relative_to(root)):digest(p.read_bytes())for p in (root/'apps/holtburger-3d/dist/assets').glob('*.js')}
s={'date':'2026-10-16','status':'Current saved character orientation checked after user turned toward a door; production renderer and shaders unchanged.','context':r['context'],'method':'Five 4s production profile windows after 10s settling, native Radeon 780M GLES. Startup-only uniform observers capture scoped particle view/projection matrices and restore both GL methods before timing. No V8 sampling, draw hooks, readbacks, build or heavy analysis during measurement. Profiling disabled before disconnect.','timing':{k:stats([f(t)for t in r['trials']])for k,f in getters.items()},'portal':{'selectedScopes':stats([sel(t)['portalSelectedScopeCount']for t in r['trials']]),'selectedCrossings':stats([sel(t)['portalSelectedCrossingCount']for t in r['trials']])},'positionStableAcrossWindows':True,'servedProductionAssets':assets,'assessment':'Turning toward the door activates selected portal crossings and scopes. This is a necessary complementary workload to the preceding zero-crossing view. The zero-exit admission condition no longer applies; any cheaper path needs spatial proof or the original portal predicate.','limits':['Different location/camera/population/viewport from earlier captures; cross-view timing is context, not causal performance evidence.','Records host camera-path position, viewport and startup scoped-particle view/projection matrices. Probe initializes yaw from authoritative character facing, but uses its configured default camera pitch/distance; exact user framing is not asserted.','No dominant-mesh owner/draw census or numeric image footprint measured in this ordinary production check.','Selected crossings establish the CPU visibility workload, not a numeric finite-envelope census or per-fragment portal-decision proof. No movement or candidate-shader validation in this check.','No visual acceptance check or production source edit.']}
add('door-spot-trials.json.gz',gzip.compress(packed(r),mtime=0),'sanitized current-location ordinary production GPU windows',['h3d-door-spot.json'])
add('door-spot-summary.json',packed(s),'current-location particle workload, stable host camera-path position and zero-crossing observation',['door-spot-trials.json.gz'])
buf=io.BytesIO();names=['h3d-door-spot-probe.mjs','h3d-preserve-door-spot.py','h3d-validate-door-spot.py']
with tarfile.open(fileobj=buf,mode='w')as archive:
 for name in names:
  data=(Path('/tmp')/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
add('door-spot-probes.tar.gz',gzip.compress(buf.getvalue(),mtime=0),'current-location production probe and evidence tools',names)
m['doorFacingSpot']={'summary':'door-spot-summary.json','windows':5,'productionSourceModified':False}
(base/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'artifacts':len(m['files']),'bytes':sum(f['bytes']for f in m['files']),'timing':s['timing'],'position':r['context']['camera']['position']}))
