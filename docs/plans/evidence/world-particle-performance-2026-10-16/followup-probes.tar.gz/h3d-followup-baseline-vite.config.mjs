import {readFileSync} from 'node:fs';
import base from '/home/me/code/holtburger/apps/holtburger-3d/vite.config.ts';
const names=new Set(['webgl2-renderer.ts','render-world.ts','entity-grounding.ts','scene-graph.ts','dynamic-depth-preparation.ts']);
export default {...base,plugins:[{name:'h3d-exact-pre-followup-source',enforce:'pre',transform(code,id){
 const name=id.split('/').at(-1);
 if(id.includes('/src/lib/game/')&&names.has(name))return {code:readFileSync('/tmp/h3d-followup-original/'+name,'utf8'),map:null};
 if(id.endsWith('/src/lib/game/renderer/outdoor-pssm-casters.ts'))return {code:code.replaceAll('readRenderContribution','getRenderContributionDescriptor'),map:null};
}},...base.plugins]};
