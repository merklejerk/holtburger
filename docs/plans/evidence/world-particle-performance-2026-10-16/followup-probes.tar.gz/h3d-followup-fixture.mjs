import {writeFile} from 'node:fs/promises';
import {createServer} from '/home/me/code/holtburger/apps/holtburger-3d/node_modules/vite/dist/node/index.js';
const root='/home/me/code/holtburger/apps/holtburger-3d';
const server=await createServer({root,configFile:false,server:{middlewareMode:true,watch:null,hmr:false,ws:false},appType:'custom'});
try {
 const {DynamicDepthPreparations}=await server.ssrLoadModule('/src/lib/game/renderer/dynamic-depth-preparation.ts');
 const {resolveEntityShadowCaster}=await server.ssrLoadModule('/src/lib/game/renderer/entity-grounding.ts');
 const {isEntityShadowCasterClass,DEFAULT_ENTITY_SHADOW_SETTINGS}=await server.ssrLoadModule('/src/lib/game/renderer/entity-shadow-policy.ts');
 const {Mat4,AABB3,Vec3}=await server.ssrLoadModule('/src/lib/game/math/types.ts');
 const {summarizeDynamicRangeAdmission,EMPTY_DYNAMIC_RANGE_ADMISSION}=await server.ssrLoadModule('/src/lib/game/renderer/object-rendering-policy.ts');
 const {scopeKey}=await server.ssrLoadModule('/src/lib/game/scene/scope.ts');
 const {compileDynamicIndexBatches}=await server.ssrLoadModule('/src/lib/game/renderer/dynamic-index-batches.ts');
 const {TextureWrapMode}=await server.ssrLoadModule('/src/lib/game/textures/types.ts');
 const settings=DEFAULT_ENTITY_SHADOW_SETTINGS.indoorGrounding;
 const indoor={kind:'env-cell',landblockId:'0x482dffff',envCellId:'0x482d0100'},outdoor={kind:'outdoor'};
 const island='env-cell-island:late-admission-fixture',islands=new Map([[scopeKey(indoor),island]]);
 const results=[];
 for(const entityClass of ['other','portal','player','npc','mob'])for(const scopes of [[outdoor],[indoor],[outdoor,indoor]])for(const geometry of ['opaque','transparent','zero-opacity','retail-hidden','empty'])for(const showHidden of [false,true])for(const publication of ['ready','unavailable']){
  const parts=[1,0.4,1,1].map(alpha=>({frameInstance:{color:{r:1,g:1,b:1,a:geometry==='zero-opacity'?0:alpha},sourceToLandblock:Mat4.identity()},renderState:{translucency:0,textureVelocity:[0,0]}}));
  const sourceAppearance={materials:[{source:{id:'material:late-admission-fixture',kind:'solid-color',color:[1,1,1,1],rawSurfaceFlags:0,translucency:0,luminosity:0,diffuseScale:1},detailRole:null,textures:{base:null,palette:null},sampler:{wrap:TextureWrapMode.Clamp},palettedClipMap:false}],ranges:geometry==='empty'?[]:[0,1,2,3].map(partSelector=>({transparentSort:{key:'fixture-order',center:Vec3.zero()},partSelector,materialSelector:0,indexStart:partSelector*3,indexCount:3,ordering:geometry==='transparent'?'transparent':'opaque',polygon:{cullFace:partSelector===3?'front':'back',stippled:false},retailVisibility:geometry==='retail-hidden'?'degrade-hidden':'normally-visible'}))};
  const plan=compileDynamicIndexBatches(new Uint32Array(geometry==='empty'?0:12),sourceAppearance,[{material:{kind:'solid-color',color:[1,1,1,1]},alphaTest:0,luminosity:0,palettedClipMap:false,wrapRepeat:false}]);
  const appearance=geometry==='empty'?{kind:'empty'}:{kind:'drawable',table:{},indexBuffer:{},plan};
  const presentation={landblockId:indoor.landblockId,renderScopes:scopes,visual:{layout:{key:'late-admission-fixture'},appearance:sourceAppearance,parts}};
  const input={entityClass,identity:'fixture',rigidBounds:new AABB3(new Vec3(-1,0,-1),new Vec3(1,2,1)),placement:{landblockId:indoor.landblockId,localToLandblock:Mat4.identity(),envCellId:scopes[0].kind==='env-cell'?indoor.envCellId:null,scope:scopes[0]},spatialMembership:{scopes}};
  const run=early=>{
   let publications=0,appearanceReads=0,depthRequests=0;
   const depth=new DynamicDepthPreparations(()=>{publications++;return publication==='ready'?presentation:null;},()=>{appearanceReads++;return appearance;});depth.beginFrame();
   let caster=null;
   const admission=publication==='ready'?summarizeDynamicRangeAdmission(sourceAppearance,parts,showHidden,new Set()):EMPTY_DYNAMIC_RANGE_ADMISSION;
   if(!early){
    depthRequests++;const prepared=depth.prepare('scene-node:fixture',showHidden);
    if(admission.hasMaterialFreeShadowGeometry!==(prepared!==null))throw Error('Logical/physical geometry admission mismatch');
    if(prepared!==null&&isEntityShadowCasterClass(entityClass))caster=resolveEntityShadowCaster(input,islands,settings);
   }else if(isEntityShadowCasterClass(entityClass)&&admission.hasMaterialFreeShadowGeometry){
    caster=resolveEntityShadowCaster(input,islands,settings);
   }
   return {output:JSON.stringify(caster),depthRequests,publications,appearanceReads};
  };
  const baseline=run(false),early=run(true);if(baseline.output!==early.output)throw new Error('Frozen grounding output changed');
  results.push({publication,entityClass,scopes:scopes.map(scopeKey),geometry,showHidden,equal:true,nonemptyOutput:baseline.output!=='null',baseline:{depthRequests:baseline.depthRequests,publications:baseline.publications,appearanceReads:baseline.appearanceReads},early:{depthRequests:early.depthRequests,publications:early.publications,appearanceReads:early.appearanceReads}});
 }
 const summary={cases:results.length,equal:results.every(x=>x.equal),indoorCases:results.filter(x=>x.scopes.includes(scopeKey(indoor))).length,nonemptyIndoorCases:results.filter(x=>x.scopes.includes(scopeKey(indoor))&&x.nonemptyOutput).length,results,limits:['Real source/physical compiler, new admission summary, depth reference and grounding geometry resolver; live full-renderer proof is captured separately.','No synthetic timing claim.','No live indoor scene or camera movement tested.']};
 await writeFile('/tmp/h3d-followup-fixture.json',JSON.stringify(summary,null,2)+'\n');
 process.stdout.write(JSON.stringify({ok:true,cases:summary.cases,indoorCases:summary.indoorCases,nonemptyIndoorCases:summary.nonemptyIndoorCases,geometryAdmissionMatchesDepth:true})+'\n');
} finally {await server.close();}
