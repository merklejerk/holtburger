"""Extract this run's canonical fixture reports and reproduced portal failure; no screenshots."""
from pathlib import Path
import hashlib,json,sys
rows=[]
for name in ['outdoor-pssm','entity-selection']:
 text=Path('/tmp/h3d-followup-gpu-'+name+'.log').read_text();decoder=json.JSONDecoder();found=[]
 for i,c in enumerate(text):
  if c!='{':continue
  try:value,end=decoder.raw_decode(text[i:])
  except json.JSONDecodeError:continue
  if isinstance(value,dict) and 'glRenderer'in value and value.get('fixture')==name:found.append(value)
 assert len(found)==1,(name,len(found))
 report=found[0];evidence=report['outdoorPssm'] if name=='outdoor-pssm' else report['initialState']['entitySelection'];evidence.pop('appearancePreview',None)
 rows.append({'fixture':name,'exitCode':0,'glRenderer':report['glRenderer'],'evidence':evidence,'consoleMessages':[{'level':item['level'],'count':item.get('count',1)} for item in report.get('consoleMessages',[])]})
runs=[]
for label,name in [('current','portal-scope-atlas'),('repeat','portal-scope-atlas-repeat'),('baseline','portal-baseline')]:
 text=Path('/tmp/h3d-followup-gpu-'+name+'.log').read_text();marker='fixture failed particleMatchesEquivalentTransparency: ';assert marker in text
 evidence,end=json.JSONDecoder().raw_decode(text.split(marker,1)[1]);data=json.dumps(evidence,sort_keys=True).encode()
 difference=[abs(a-b) for a,b in zip(evidence['particlePixels'],evidence['deferredPixels'])]
 runs.append({'variant':label,'exitCode':1,'failedAssertion':'particleMatchesEquivalentTransparency','evidenceSha256':hashlib.sha256(data).hexdigest(),'differingBytes':sum(x!=0 for x in difference),'maximumByteDelta':max(difference),'evidence':evidence})
assert len({row['evidenceSha256'] for row in runs})==1
rows.append({'fixture':'portal-scope-atlas','exitCode':1,'baselineReproduced':True,'identicalAcrossCurrentRepeatBaseline':True,'runs':runs,'command':'npm run harness:browser -- --fixture portal-scope-atlas --gpu --full-report','baselineVitePort':int(sys.argv[1]),'backend':'Hardware requested with --gpu; assertion aborts before normal renderer report.'})
Path('/tmp/h3d-followup-gpu-fixtures.json').write_text(json.dumps({'fixtures':rows},indent=2)+'\n')
print(json.dumps({'passed':2,'baselineReproducedPortalFailure':True}))
