() => {
 const c=globalThis.__h3dFollowClasses;
 if(!c?.RenderWorld||!c?.WebGL2Renderer||!c?.baselineResolver||!c?.WebGL2OutdoorPssmPass)throw Error('Follow-up diagnostic build missing');
 const s=window.__h3dFollowAudit={mode:'borrow',counting:false,frames:0,counts:{},groundingNode:null,shadow:false,phase:'other',classes:new Map(),proofRemaining:0,proofs:[],shadowProofRemaining:0,shadowProofs:[],proving:false,owners:new Set()};
 s.reset=()=>{s.frames=0;s.counts={colorDescriptors:0,shadowDescriptors:0,colorDescriptorClones:0,shadowDescriptorClones:0,scopeClones:0,indoorFactClones:0,staticCompilationClones:0,otherClones:0,groundingDepthRequests:0,nonCasterGroundingDepthRequests:0,mappedDepthRequests:0,selectionDepthRequests:0};s.classes.clear();};s.reset();
 const world=c.RenderWorld.prototype,depth=c.DynamicDepthPreparations.prototype;
 const read=world.readRenderContribution,scope=world.getRenderScopeKey,indoor=world.getIndoorGroundingEnvCellFacts,staticNode=world.resolveStaticObjectNode,clone=c.Mat4.prototype.clone,prepare=depth.prepare,selection=depth.prepareSelection,collect=c.ParticleSystem.prototype.collectDrawRanges,pssm=c.WebGL2OutdoorPssmPass.prototype.prepare;
 function phase(name,fn){const old=s.phase;s.phase=name;try{return fn();}finally{s.phase=old;}}
 world.readRenderContribution=function(id){return phase(s.shadow?'shadowDescriptor':'colorDescriptor',()=>{const value=s.mode==='borrow'?read.call(this,id):this.__h3dBaselineContribution(id);if(s.counting){s.counts[s.shadow?'shadowDescriptors':'colorDescriptors']++;if(value?.kind==='dynamic')s.classes.set(id,value.entityClass);}return value;});};
 world.getRenderScopeKey=function(id){return phase('scope',()=>s.mode==='borrow'?scope.call(this,id):this.__h3dBaselineScopeKey(id));};
 world.getIndoorGroundingEnvCellFacts=function(id){return phase('indoorFact',()=>s.mode==='borrow'?indoor.call(this,id):this.__h3dBaselineIndoorFacts(id));};
 world.resolveStaticObjectNode=function(){return phase('staticCompilation',()=>staticNode.apply(this,arguments));};
 c.Mat4.prototype.clone=function(){if(s.counting)s.counts[s.phase+'Clones']++;return clone.apply(this,arguments);};
 depth.prepare=function(id){if(s.counting){if(s.shadow)s.counts.mappedDepthRequests++;else if(s.groundingNode===id){s.counts.groundingDepthRequests++;const cls=s.classes.get(id);if(cls!==undefined&&!c.isEntityShadowCasterClass(cls))s.counts.nonCasterGroundingDepthRequests++;}}return prepare.apply(this,arguments);};
 depth.prepareSelection=function(){if(s.counting)s.counts.selectionDepthRequests++;return selection.apply(this,arguments);};
 c.ParticleSystem.prototype.collectDrawRanges=function(){const ranges=collect.apply(this,arguments);if(s.counting){s.owners.clear();for(const r of ranges)if(r.hwGfxObjId==='0x01003fa7')s.owners.add(r.renderOwner);}return ranges;};
 const resources=new WeakMap();let nextResource=0;
 function serialize(value){return JSON.stringify(value,(key,item)=>{
  if(item instanceof Map||item instanceof Set)return [...item];
  if(ArrayBuffer.isView(item))return Array.from(item);
  if(item!==null&&typeof item==='object'&&['drawUnit','appearance','geometry','program'].includes(key)){let id=resources.get(item);if(id===undefined){id=nextResource++;resources.set(item,id);}return {resourceIdentity:id};}
  return item;
 });}
 const pose=state=>({selected:state.selected,pose:state.pose.map(([id,parts])=>[id,parts.map(p=>({frameInstance:p.frameInstance,renderState:p.renderState}))])});
 const hash=value=>{let n=2166136261;for(let i=0;i<value.length;i++)n=Math.imul(n^value.charCodeAt(i),16777619);return(n>>>0).toString(16);};
 s.prove=(renderer,args)=>{
  const mode=s.mode,initial=renderer.__h3dSelection(),outputs=[];s.proving=true;
  try{
   let result;
   for(const variant of ['baseline','grounding','borrow']){s.mode=variant;renderer.__h3dRestoreSelection(initial);result=renderer.__h3dResolve(...args.slice(0,3),null,...args.slice(4));outputs.push(serialize({contributions:result,selection:pose(renderer.__h3dSelection())}));}
   if(outputs.some(x=>x!==outputs[0])){s.failure='Same-frame contribution/selection mismatch';throw Error(s.failure);}
   s.proofs.push({equal:true,signatureHash:hash(outputs[0]),signatureCharacters:outputs[0].length,shadowMode:args[2].entityShadows.mode,selected:renderer.__h3dSelection().selected.length});s.proofRemaining--;return result;
  }finally{s.proving=false;s.mode=mode;}
 };
 function shadowSignature(result,input){return result===null?null:{cascades:result.storage.cascades,casters:result.storage.batches.map(b=>b.casters.map(d=>({nodeId:d.nodeId,landblockId:d.landblockId,geometry:d.geometry,renderScopes:d.renderScopes,ranges:d.ranges,parts:d.parts.map(p=>({frameInstance:p.frameInstance,renderState:p.renderState})),selectedPartCount:d.selectedPartCount,selectedTriangleCount:d.selectedTriangleCount}))),analytic:result.storage.analyticCasters,candidates:result.storage.casterSelectionScratch.candidates,selected:[...input.selectedDynamicNodeIds]};}
 c.WebGL2OutdoorPssmPass.prototype.prepare=function(input,metrics){
  const old=s.shadow;s.shadow=true;
  try{
   if(s.shadowProofRemaining===0)return pssm.apply(this,arguments);
   const mode=s.mode,selected=[...input.selectedDynamicNodeIds],values=[];let result;
   try{for(const variant of ['baseline','grounding','borrow']){s.mode=variant;input.selectedDynamicNodeIds.clear();for(const id of selected)input.selectedDynamicNodeIds.add(id);result=pssm.call(this,input,null);values.push(serialize(shadowSignature(result,input)));}}finally{s.mode=mode;}
   if(values.some(x=>x!==values[0])){s.failure='Same-frame mapped shadow mismatch';throw Error(s.failure);}
   s.shadowProofs.push({equal:true,signatureHash:hash(values[0]),signatureCharacters:values[0].length,candidates:result?.storage.casterSelectionScratch.candidates.length??0});s.shadowProofRemaining--;return result;
  }finally{s.shadow=old;}
 };
 s.stopCounters=()=>{s.counting=false;c.Mat4.prototype.clone=clone;depth.prepare=prepare;depth.prepareSelection=selection;c.ParticleSystem.prototype.collectDrawRanges=collect;};
 s.restore=()=>{s.stopCounters();world.readRenderContribution=read;world.getRenderScopeKey=scope;world.getIndoorGroundingEnvCellFacts=indoor;world.resolveStaticObjectNode=staticNode;c.WebGL2OutdoorPssmPass.prototype.prepare=pssm;s.mode='borrow';};
}
