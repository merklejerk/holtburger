import {readFileSync} from 'node:fs';
import {createRequire} from 'node:module';
import base from '/home/me/code/holtburger/apps/holtburger-3d/vite.config.ts';
const ts=createRequire('/home/me/code/holtburger/apps/holtburger-3d/package.json')('typescript');
const original=name=>readFileSync('/tmp/h3d-followup-original/'+name+'.ts','utf8');
function section(source,start,end){const a=source.indexOf(start),b=source.indexOf(end,a);if(a<0||b<0)throw Error('Missing baseline section '+start);return source.slice(a,b);}
const js=source=>ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ESNext}}).outputText;
function methods(source){const wrapper=js('class Baseline {\n'+source+'\n}');return wrapper.slice(wrapper.indexOf('{')+1,wrapper.lastIndexOf('}'));}
const oldWorld=original('render-world');
let worldMethods=[
 section(oldWorld,'\tgetRenderContributionDescriptor(','\n\t/** Publish installed layout').replace('getRenderContributionDescriptor','__h3dBaselineContribution'),
 section(oldWorld,'\t#staticObjectFootprint(','\n\t#requiredPlacement('),
 section(oldWorld,'\t#requiredPlacement(','\n\tresolveEnvCellRenderable('),
 section(oldWorld,'\tgetRenderScopeKey(','\n\t/** Visual ocean').replace('getRenderScopeKey','__h3dBaselineScopeKey'),
 section(oldWorld,'\tgetIndoorGroundingEnvCellFacts(','\n\tgetPortalDrawUnit(').replace('getIndoorGroundingEnvCellFacts','__h3dBaselineIndoorFacts'),
].join('\n').replaceAll('#staticObjectFootprint','#__h3dBaselineFootprint').replaceAll('#requiredPlacement','#__h3dBaselinePlacement').replaceAll('getResolvedBounds','__h3dBaselineBounds');
let baselineResolve=section(original('webgl2-renderer'),'\t#resolveSceneContributions(','\n\t#retainsObjectFootprint(').replace('#resolveSceneContributions','#resolveSceneContributionsBaseline').replaceAll('getRenderContributionDescriptor','readRenderContribution').replaceAll('resolveEntityShadowCaster(','globalThis.__h3dFollowClasses.baselineResolver(');
baselineResolve=baselineResolve.replace('const facts = this.#world.getEntityShadowDynamicFacts(nodeId);',`if(globalThis.__h3dFollowAudit?.counting)globalThis.__h3dFollowAudit.groundingNode=nodeId;
 const facts = this.#world.getEntityShadowDynamicFacts(nodeId);`).replace('if (caster?.indoorGrounding) {',`if(globalThis.__h3dFollowAudit?.counting)globalThis.__h3dFollowAudit.groundingNode=null;
 if (caster?.indoorGrounding) {`);
const baselineBounds=section(original('scene-graph'),'\tgetResolvedBounds(','\n\tupdateRootPlacement(').replace('getResolvedBounds','__h3dBaselineBounds');
const baselineResolver=section(original('entity-grounding'),'export function resolveEntityShadowCaster(','\n/** Resolve one EnvCell scope').replace('export function resolveEntityShadowCaster','function baselineResolver').replace('!isEntityShadowCasterClass(input.entityClass)','!globalThis.__h3dFollowClasses.isEntityShadowCasterClass(input.entityClass)');
const refs=new Map([
 ['/src/lib/game/renderer/render-world.ts','RenderWorld'],['/src/lib/game/scene/scene-graph.ts','SceneGraph'],
 ['/src/lib/game/renderer/webgl2-renderer.ts','WebGL2Renderer'],['/src/lib/game/renderer/webgl2-outdoor-pssm-pass.ts','WebGL2OutdoorPssmPass'],
 ['/src/lib/game/renderer/dynamic-depth-preparation.ts','DynamicDepthPreparations'],['/src/lib/game/renderer/entity-shadow-policy.ts','isEntityShadowCasterClass'],
 ['/src/lib/game/systems/particle-system.ts','ParticleSystem'],['/src/lib/game/math/types.ts','Mat4']]);
export default {...base,plugins:[...base.plugins,{name:'h3d-followup-proof-and-timing',transform(code,id){
 if(id.endsWith('/src/lib/game/renderer/render-world.ts'))code=code.replace('class RenderWorld {','class RenderWorld {\n'+methods(worldMethods));
 if(id.endsWith('/src/lib/game/scene/scene-graph.ts'))code=code.replace('class SceneGraph {','class SceneGraph {\n'+methods(baselineBounds));
 if(id.endsWith('/src/lib/game/renderer/entity-grounding.ts'))code+='\n'+js(baselineResolver)+'\nglobalThis.__h3dFollowClasses ??= {};globalThis.__h3dFollowClasses.baselineResolver=baselineResolver;\n';
 if(id.endsWith('/src/lib/game/renderer/webgl2-renderer.ts')){
  const start=code.indexOf('\t#resolveSceneContributions('),body=code.indexOf('const resolutionStartedAt',start);if(start<0||body<0)throw Error('Missing current collector');
  const inject=`const audit=globalThis.__h3dFollowAudit;
   if(audit?.proofRemaining>0&&!audit.proving)return audit.prove(this,[prepared,visibleEntries,frameSettings,profile,portalVisibility,shadows]);
   if(audit?.counting)audit.frames++;
   if(audit?.mode==='baseline')return this.#resolveSceneContributionsBaseline(prepared,visibleEntries,frameSettings,profile,portalVisibility,shadows);
   `;
  code=code.slice(0,body)+inject+code.slice(body);
  code=code.replace('class WebGL2Renderer {',`class WebGL2Renderer {
   __h3dResolve(...args){return this.#resolveSceneContributions(...args);}
   __h3dSelection(){return {selected:[...this.#selectedDynamicNodeIds],pose:[...this.#poseUploadParts]};}
   __h3dRestoreSelection(value){this.#selectedDynamicNodeIds.clear();for(const id of value.selected)this.#selectedDynamicNodeIds.add(id);this.#poseUploadParts.clear();for(const [id,parts]of value.pose)this.#poseUploadParts.set(id,parts);}
   `+methods(baselineResolve));
 }
 for(const [suffix,name] of refs)if(id.endsWith(suffix))return {code:code+`\nglobalThis.__h3dFollowClasses ??= {};globalThis.__h3dFollowClasses.${name}=${name};\n`,map:null};
 if(id.endsWith('/src/lib/game/renderer/entity-grounding.ts'))return {code,map:null};
 }}],build:{...base.build,outDir:'/tmp/h3d-followup-dist',emptyOutDir:true}};
