from pathlib import Path
import gzip,hashlib,io,json,statistics,tarfile
root=Path('/home/me/code/holtburger');base=root/'docs/plans/evidence/world-particle-performance-2026-10-16';manifest=json.loads((base/'manifest.json').read_text());removed=set(manifest['sanitization']['removedKeys'])
def clean(v):
 if isinstance(v,list):return [clean(x) for x in v]
 if isinstance(v,dict):
  out={k:clean(x) for k,x in v.items() if k not in removed}
  if 'consoleMessages' in out:
   counts={}
   for row in v['consoleMessages']:counts[row['level']]=counts.get(row['level'],0)+row.get('count',1)
   out['consoleMessages']=[{'level':k,'count':n} for k,n in counts.items()]
  return out
 return v
def packed(v):return (json.dumps(v,indent=2)+'\n').encode()
def add(name,data,kind,sources):
 (base/name).write_bytes(data);manifest['files']=[x for x in manifest['files'] if x['path']!=name]+[{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'kind':kind,'sources':sources}]
def stats(v):return {'median':statistics.median(v),'min':min(v),'max':max(v)}
raw=clean(json.loads(Path('/tmp/h3d-followup.json').read_text()));assert len(raw['trials'])==45 and len(raw['proofs'])==30 and len(raw['shadowProofs'])==10 and raw['cleanup']['hooksRestored']
fixture=json.loads(Path('/tmp/h3d-followup-fixture.json').read_text());assert fixture['cases']==300 and fixture['equal']
gpu=clean(json.loads(Path('/tmp/h3d-followup-gpu-fixtures.json').read_text()))
production=clean(json.loads(Path('/tmp/h3d-followup-production.json').read_text()));assert len(production['trials'])==5
for name,v in [('trials',raw),('fixture',fixture),('gpu-fixtures',gpu),('production',production)]:add('followup-'+name+'.json.gz',gzip.compress(packed(v),mtime=0),'sanitized implementation proof, work counts, timing or runtime fixture evidence',[f'h3d-followup-{name}.json'])
getters={'frameWorkMs':lambda t:t['snapshot']['meanFrameWorkMs'],'rendererCpuMs':lambda t:t['snapshot']['diagnostics']['renderer']['profile']['cpu']['mean']['totalMs'],'sceneCpuMs':lambda t:t['snapshot']['diagnostics']['renderer']['profile']['cpu']['mean']['sceneContributionResolutionMs'],'shadowCpuMs':lambda t:t['snapshot']['diagnostics']['renderer']['profile']['cpu']['mean']['outdoorShadowMapMs'],'gpuMs':lambda t:t['snapshot']['diagnostics']['renderer']['profile']['gpu']['mean']['totalMs'],'particleGpuMs':lambda t:t['snapshot']['diagnostics']['renderer']['profile']['gpu']['mean']['particleMs'],'dynamicEntities':lambda t:t['snapshot']['diagnostics']['renderer']['selectionMetrics']['visibleDynamicEntityCount'],'fps':lambda t:t['snapshot']['sampledFrameCount']*1000/t['windowMs']}
timing={}
for shadowMode in ['simple','shadow-maps','none']:
 timing[shadowMode]={}
 for mode in ['baseline','grounding','borrow']:
  ts=[t for t in raw['trials'] if t['mode']==mode and t['shadowMode']==shadowMode];assert len(ts)==5
  timing[shadowMode][mode]={k:stats([f(t) for t in ts]) for k,f in getters.items()}
 for label,a,b in [('groundingSaving','baseline','grounding'),('borrowingSaving','grounding','borrow'),('combinedSaving','baseline','borrow')]:
  timing[shadowMode][label]={}
  for k,f in getters.items():
   diffs=[f(next(t for t in raw['trials'] if t['shadowMode']==shadowMode and t['mode']==a and t['round']==i))-f(next(t for t in raw['trials'] if t['shadowMode']==shadowMode and t['mode']==b and t['round']==i)) for i in range(5)]
   timing[shadowMode][label][k]={**stats(diffs),'positiveRounds':sum(x>0 for x in diffs)}
audits=[]
for a in raw['audits']:
 counts={('shadowPassDepthRequests' if k=='mappedDepthRequests' else k):v/a['frames'] for k,v in a['counts'].items()}
 counts['targetedMatrixClones']=sum(counts[k] for k in ['colorDescriptorClones','shadowDescriptorClones','scopeClones','indoorFactClones'])
 audits.append({'mode':a['mode'],'shadowMode':a['shadowMode'],'frames':a['frames'],'dominantOwners':a['dominantOwners'],'perFrame':counts})
paths=['renderer/object-rendering-policy.ts','renderer/dynamic-depth-preparation.ts','renderer/entity-grounding.ts','renderer/render-world.ts','renderer/webgl2-renderer.ts','renderer/outdoor-pssm-casters.ts','scene/index.ts','scene/scene-graph.ts']
sourceHashes={'apps/holtburger-3d/src/lib/game/'+p:hashlib.sha256((root/'apps/holtburger-3d/src/lib/game'/p).read_bytes()).hexdigest() for p in paths}
originalHashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('/tmp/h3d-followup-original').glob('*.ts')}
summary={'date':'2026-10-16','status':'Both scoped follow-up fixes implemented and validated in working tree; uncommitted.','productionSourceHashes':sourceHashes,'originalSnapshotHashes':originalHashes,'method':{'baseline':'Exact pre-follow-up collector and RenderWorld copied-read helpers plus original scene copied-bounds getter embedded only by a disposable Vite transform. Baseline already includes the completed early outdoor-shadow query fix.','grounding':'New admission summary and early class gate with original copied renderer reads.','borrow':'Both implemented fixes.','measurement':'Five matched rounds per shadow mode, three alternating variants per round; reverse order on alternate rounds. Each 1.5s settle then 4s capture. Forty-five windows.','attribution':'Within-round baseline minus grounding isolates Fix 1; grounding minus borrow isolates Fix 2. This is a three-way crossover with live drift, not independent frozen workload pairs.','proof':'Ten same-frame collector triples per shadow mode; ten mapped-pass triples. Complete serialized strings compared exactly after restoring selected roots and pose-input maps before each variant. Immutable staged draw units/resources use identity tokens; receiver arrays, ordered inputs, selected roots and pose matrices/colors are compared as values. Hashes are labels.','overhead':'Both modes retain identical method-dispatch/prototype wrappers and build-only globals. Matrix/depth/particle counter wrappers removed before timing. No V8 sampling, readback, builds or heavy analysis during windows. Diagnostic wrappers create common overhead; normal production smoke is separate.','counts':'Nine 2s work audits, normalized by each frame count. Raw mappedDepthRequests means prepares inside the outdoor PSSM feature, including analytic fallback, and is renamed shadowPassDepthRequests here. It is not a mapped-root or GPU-draw count.','frozenFixture':'300 real compiler/admission/depth-reference/geometry-resolver compositions, including unavailable publication. New class gate is outside geometry resolution; baseline applies the original class rule after depth preparation.','lifetime':'Borrowed contribution/bounds valid synchronously before next scene mutation. Owned placement retained only at cold static compilation; inspection snapshots preserved.','residual':'PSSM analytic fallback still uses depth preparation for geometry/outdoor-scope admission before color collection. It can include off-camera roots and cannot read the color-only summary. No new eligibility query/cache was added for that separate path.','cleanup':raw['cleanup'],'productionSmoke':'Normal npm build, original native GLES backend, five 4s windows with diagnostic globals absent; separate session, not causal timing evidence.'},'timing':timing,'audits':audits,'proofs':raw['proofs'],'shadowProofs':raw['shadowProofs'],'fixture':{k:v for k,v in fixture.items() if k!='results'},'validation':{'focusedTests':{'files':10,'passed':164},'typeChecks':'passed; zero errors and warnings','typescriptLint':'passed','deadCodeLint':'passed','formatting':'passed for touched files','productionBuild':'passed; chunk-size/plugin timing advisories only','gpu':'Outdoor PSSM and selection pass. Portal particle/transparency oracle fails identically in current, repeated current and preserved baseline.','bundleVerification':json.loads(Path('/tmp/h3d-followup-bundle-verification.json').read_text()),'initialFailures':'Corrected child-transform test misuse and an unrelated receiver argument removed by a broad edit before accepted checks. No failed timing windows retained.'},'gpuFixtures':gpu,'productionSmoke':{'context':production['context'],'timing':{k:stats([f(t) for t in production['trials']]) for k,f in getters.items()}},'limits':['No visual acceptance, moving-camera or streaming acceptance.','Synthetic indoor composition passes; no live indoor actor measurement.','No claim that all remaining CPU/GPU time is removable or that matrix bytes equal measured saving.','Rolling phase snapshots and live workload drift limit end-to-end/FPS claims.']}
add('followup-summary.json',packed(summary),'separate grounding/borrowing implementation results, original-source provenance, complete ranges and runtime proof',['followup-trials.json.gz','followup-fixture.json.gz','followup-production.json.gz','followup-gpu-fixtures.json.gz'])
add('followup-change.patch',Path('/tmp/h3d-followup-change.patch').read_bytes(),'complete accumulated production/test diff against repository HEAD; includes earlier shadow-query fix',['git diff -- apps/holtburger-3d/src'])
names=['h3d-followup-vite.config.mjs','h3d-followup-baseline-vite.config.mjs','h3d-followup-hook.js','h3d-followup-probe.mjs','h3d-followup-launch.mjs','h3d-followup-fixture.mjs','h3d-followup-gpu-evidence.py','h3d-followup-bundle-verification.json','h3d-followup-production-probe.mjs','h3d-preserve-followup.py','h3d-validate-followup.py']
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as archive:
 for name in names:
  data=(Path('/tmp')/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;archive.addfile(info,io.BytesIO(data))
 for name in originalHashes:
  data=(Path('/tmp/h3d-followup-original')/name).read_bytes();info=tarfile.TarInfo('original/'+name);info.size=len(data);info.mtime=0;info.mode=0o644;archive.addfile(info,io.BytesIO(data))
add('followup-probes.tar.gz',gzip.compress(buffer.getvalue(),mtime=0),'disposable three-variant transform/probes, frozen fixture, validator and exact original source snapshots',names+['original/'+x for x in originalHashes])
manifest['scope']='Stationary outdoor GPU/CPU investigation, synthetic validation, and three app-local CPU improvements implemented in the working tree. Historical source/build assumptions are retained. Portal particle-oracle failure reproduced identically before the two follow-up changes.'
manifest['implementedFollowups']={'summary':'followup-summary.json','productionCodeModified':True,'committed':False,'sameFrameContributionTriples':30,'sameFrameShadowTriples':10,'timingWindows':45,'countAudits':9,'frozenCases':300}
(base/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'artifacts':len(manifest['files']),'bytes':sum(x['bytes'] for x in manifest['files']),'timing':timing,'audits':audits}))
