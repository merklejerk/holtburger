"""Read-only validation of retained implementation evidence; run from repository root."""
from pathlib import Path
import gzip,hashlib,json,statistics,tarfile
root=Path.cwd();base=root/'docs/plans/evidence/world-particle-performance-2026-10-16';m=json.loads((base/'manifest.json').read_text())
for item in m['files']:
 data=(base/item['path']).read_bytes();assert len(data)==item['bytes'],item['path'];assert hashlib.sha256(data).hexdigest()==item['sha256'],item['path']
def read(name):return json.loads(gzip.decompress((base/('followup-'+name+'.json.gz')).read_bytes()))
r=read('trials');s=json.loads((base/'followup-summary.json').read_text());f=read('fixture');p=read('production');gpu=read('gpu-fixtures')
assert len(r['proofs'])==30 and len(r['shadowProofs'])==10
assert all(x['equal'] for x in r['proofs']+r['shadowProofs'])
assert len(r['trials'])==45 and len(r['audits'])==9
assert r['cleanup']=={'restoredShadowMode':r['context']['savedGraphics']['entityShadowMode'],'hooksRestored':True}
for shadows in ['simple','shadow-maps','none']:
 for mode in ['baseline','grounding','borrow']:
  ts=[t for t in r['trials'] if t['shadowMode']==shadows and t['mode']==mode];assert sorted(t['round'] for t in ts)==list(range(5))
  assert all(t['windowMs']>=4000 and t['snapshot']['sampledFrameCount']>0 for t in ts)
  values=[t['snapshot']['diagnostics']['renderer']['profile']['cpu']['mean']['sceneContributionResolutionMs'] for t in ts]
  assert statistics.median(values)==s['timing'][shadows][mode]['sceneCpuMs']['median']
  audit=next(a for a in r['audits'] if a['shadowMode']==shadows and a['mode']==mode)
  assert audit['frames']==audit['snapshot']['sampledFrameCount'] and audit['dominantOwners']==206
  if mode!='baseline':assert audit['counts']['groundingDepthRequests']==0
  if mode=='borrow':
   for key in ['colorDescriptorClones','shadowDescriptorClones','scopeClones','indoorFactClones']:assert audit['counts'][key]==0,key
  if shadows=='none':assert audit['counts']['mappedDepthRequests']==audit['counts']['groundingDepthRequests']==0
assert f['cases']==len(f['results'])==300 and f['equal'] and f['nonemptyIndoorCases']>0
for case in f['results']:assert case['equal'] and case['early']['depthRequests']==0
assert len(p['trials'])==5 and not p['context']['diagnosticGlobalsPresent']
assert p['context']['graphics']['entityShadowMode']==r['cleanup']['restoredShadowMode']
assert 'OpenGL ES' in p['context']['renderer']
assert len(gpu['fixtures'])==3
assert sum(x['exitCode']==0 for x in gpu['fixtures'])==2
portal=next(x for x in gpu['fixtures'] if x['fixture']=='portal-scope-atlas')
assert portal['exitCode']==1 and portal['baselineReproduced'] and portal['identicalAcrossCurrentRepeatBaseline']
assert len({x['evidenceSha256'] for x in portal['runs']})==1
assert all(not x['evidence']['particleMatchesEquivalentTransparency'] for x in portal['runs'])
for path,digest in s['productionSourceHashes'].items():
 data=(root/path).read_bytes();assert hashlib.sha256(data).hexdigest()==digest,path
 assert not any(token in data for token in [b'__h3dFollow',b'__h3dLate',b'BaselineContribution',b'resolveSceneContributionsBaseline']),path
removed=set(m['sanitization']['removedKeys'])
def sanitized(value):
 if isinstance(value,list):
  for item in value:sanitized(item)
 if isinstance(value,dict):
  assert not removed.intersection(value)
  if 'consoleMessages'in value:assert all(set(row)<={'level','count'} for row in value['consoleMessages'])
  for item in value.values():sanitized(item)
for v in [r,s,f,p,gpu]:sanitized(v)
with tarfile.open(base/'followup-probes.tar.gz')as archive:
 for member in archive.getmembers():
  assert member.isfile() and '..' not in Path(member.name).parts and not Path(member.name).is_absolute()
  data=archive.extractfile(member).read()
  if member.name.startswith('original/'):assert hashlib.sha256(data).hexdigest()==s['originalSnapshotHashes'][Path(member.name).name]
print(json.dumps({'ok':True,'artifacts':len(m['files']),'contributionTriples':30,'shadowTriples':10,'timingWindows':45,'countAudits':9,'frozenCases':300,'productionWindows':5,'passedGpuFixtures':2,'baselineReproducedPortalFailure':True}))
