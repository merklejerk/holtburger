() => {
    const p=WebGL2RenderingContext.prototype;
    const shaderSource=p.shaderSource, attachShader=p.attachShader, useProgram=p.useProgram;
    const bindBuffer=p.bindBuffer, bindBufferBase=p.bindBufferBase, bufferSubData=p.bufferSubData;
    const drawArrays=p.drawArrays, drawElements=p.drawElementsInstanced;
    const programs=new WeakMap(), attached=new WeakMap(), shaderTexts=new WeakMap(), facts=new WeakMap();
    const buffers=new WeakMap(), bindings=new Map();
    const state=window.__spatialAudit={mode:'normal',frames:0,counts:{draws:0,instances:0},bounds:null,firstDraw:null,proofs:[]};
    const inject=(text)=>text;
    p.shaderSource=function(shader,text){text=inject(text);shaderTexts.set(shader,text);return shaderSource.call(this,shader,text);};
    p.attachShader=function(program,shader){let list=attached.get(program);if(!list){list=[];attached.set(program,list);}list.push(shader);return attachShader.call(this,program,shader);};
    p.useProgram=function(program){
        programs.set(this,program);
        if(program && !facts.has(program)){
            const texts=(attached.get(program)||[]).map(s=>shaderTexts.get(s)||'');
            const root=texts.some(t=>t.includes('uint current = 1u;')&&t.includes('flat in uint vOutputArrival;'));
            const particle=this.getUniformLocation(program,'uParticleRecords')!==null;
            facts.set(program,{root,particle,mode:particle?this.getUniformLocation(program,'uDiagnosticSpatialMode'):null,affected:particle?this.getUniformLocation(program,'uDiagnosticAffected'):null,ordinal:particle?this.getUniformLocation(program,'uPortalRenderDomain'):null});
        }
        return useProgram.call(this,program);
    };
    p.bindBuffer=function(target,buffer){bindings.set(target,buffer);return bindBuffer.call(this,target,buffer);};
    let metadataBuffer=null;
    p.bindBufferBase=function(target,index,buffer){if(target===this.UNIFORM_BUFFER&&index===0)metadataBuffer=buffer;return bindBufferBase.call(this,target,index,buffer);};
    p.bufferSubData=function(target,dst,src,srcOffset=0,length){
        if(dst===0 && ArrayBuffer.isView(src) && src.BYTES_PER_ELEMENT===1 && (target===this.ARRAY_BUFFER || target===this.UNIFORM_BUFFER)){
            const bytes=length===undefined?src.byteLength-srcOffset:length;
            buffers.set(bindings.get(target),new Uint8Array(src.buffer,src.byteOffset+srcOffset,bytes).slice());
        }
        return bufferSubData.apply(this,arguments);
    };
    p.drawArrays=function(mode,first,count){
        const f=facts.get(programs.get(this));
        if(f?.root){
            const metadata=buffers.get(metadataBuffer);if(!metadata || metadata.byteLength!==16384)throw new Error('Missing mirrored portal metadata');
            const buffer=this.getVertexAttrib(0,this.VERTEX_ATTRIB_ARRAY_BUFFER_BINDING),triangles=buffers.get(buffer);
            if(!triangles || first!==0 || count%3!==0 || triangles.byteLength!==count*24)throw new Error('Crossing stream layout differs');
            const matrix=new Float32Array(metadata.buffer,metadata.byteOffset,16),verts=new DataView(triangles.buffer,triangles.byteOffset,triangles.byteLength);
            const width=this.drawingBufferWidth,height=this.drawingBufferHeight;
            let left=width,bottom=height,right=0,top=0,rootTriangles=0,eyePlaneFallback=false;
            const routes=new Set();
            for(let i=0;i<count;i+=3){
                const offset=i*24;if(verts.getUint32(offset+16,true)!==0)continue;
                rootTriangles++;routes.add(verts.getUint32(offset+12,true));
                for(let v=0;v<3;v++){
                    const o=offset+v*24,x=verts.getFloat32(o,true),y=verts.getFloat32(o+4,true),z=verts.getFloat32(o+8,true);
                    const w=matrix[3]*x+matrix[7]*y+matrix[11]*z+matrix[15];
                    if(w<=0.00001){eyePlaneFallback=true;continue;}
                    const px=((matrix[0]*x+matrix[4]*y+matrix[8]*z+matrix[12])/w+1)*width/2;
                    const py=((matrix[1]*x+matrix[5]*y+matrix[9]*z+matrix[13])/w+1)*height/2;
                    left=Math.min(left,px);right=Math.max(right,px);bottom=Math.min(bottom,py);top=Math.max(top,py);
                }
            }
            const rect=eyePlaneFallback?[0,0,width,height]:rootTriangles?[Math.max(0,Math.floor(left)-3),Math.max(0,Math.floor(bottom)-3),Math.min(width,Math.ceil(right)+3),Math.min(height,Math.ceil(top)+3)]:[0,0,0,0];
            const slots=new Uint32Array(metadata.buffer,metadata.byteOffset+8224,8);
            if(slots[0]!==0||slots[1]!==0||slots[2]!==0||slots[3]!==0||slots[4]!==width||slots[5]!==height)throw new Error('Root mapping is not full viewport');
            state.bounds={rect,rootTriangles,rootCrossings:routes.size,eyePlaneFallback,width,height,area:Math.max(0,rect[2]-rect[0])*Math.max(0,rect[3]-rect[1])};state.frames++;
        }
        return drawArrays.apply(this,arguments);
    };
    p.drawElementsInstanced=function(mode,count,type,offset,instances){
        const f=facts.get(programs.get(this));if(f?.particle&&count===330){state.gl=this;state.counts.draws++;state.counts.instances+=instances;}
        return drawElements.apply(this,arguments);
    };
    state.inspectEnvelope=()=>{
        const gl=state.gl;if(!gl || !state.bounds)throw new Error('Missing spatial draw state');
        const rect=[...state.bounds.rect];
        if(!gl.getExtension('EXT_color_buffer_float'))throw new Error('Float color target unavailable');
        const saved={program:gl.getParameter(gl.CURRENT_PROGRAM),vao:gl.getParameter(gl.VERTEX_ARRAY_BINDING),draw:gl.getParameter(gl.DRAW_FRAMEBUFFER_BINDING),read:gl.getParameter(gl.READ_FRAMEBUFFER_BINDING),viewport:Array.from(gl.getParameter(gl.VIEWPORT)),texture:gl.getParameter(gl.TEXTURE_BINDING_2D)};
        const capabilities=[gl.BLEND,gl.DEPTH_TEST,gl.SCISSOR_TEST,gl.CULL_FACE,gl.STENCIL_TEST].map(cap=>[cap,gl.isEnabled(cap)]);
        const compile=(kind,source)=>{const shader=gl.createShader(kind);shaderSource.call(gl,shader,source);gl.compileShader(shader);if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(shader));return shader;};
        const vs=compile(gl.VERTEX_SHADER,'#version 300 es\nvoid main(){vec2 p=gl_VertexID==0?vec2(-1.,-1.):gl_VertexID==1?vec2(3.,-1.):vec2(-1.,3.);gl_Position=vec4(p,0.,1.);}');
        const fs=compile(gl.FRAGMENT_SHADER,'#version 300 es\nprecision highp float;uniform sampler2D envelope;out vec4 color;void main(){float d=texelFetch(envelope,ivec2(gl_FragCoord.xy),0).r;color=vec4(d,d,d,1.);}');
        const program=gl.createProgram();attachShader.call(gl,program,vs);attachShader.call(gl,program,fs);gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(program));
        const width=gl.drawingBufferWidth,height=gl.drawingBufferHeight;
        const color=gl.createTexture(),framebuffer=gl.createFramebuffer();gl.bindTexture(gl.TEXTURE_2D,color);gl.texStorage2D(gl.TEXTURE_2D,1,gl.RGBA32F,width,height);gl.bindTexture(gl.TEXTURE_2D,saved.texture);
        gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,framebuffer);gl.framebufferTexture2D(gl.DRAW_FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,color,0);if(gl.checkFramebufferStatus(gl.DRAW_FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw new Error('Envelope proof framebuffer incomplete');
        for(const [cap] of capabilities)gl.disable(cap);
        gl.viewport(0,0,width,height);useProgram.call(gl,program);gl.uniform1i(gl.getUniformLocation(program,'envelope'),5);gl.bindVertexArray(null);drawArrays.call(gl,gl.TRIANGLES,0,3);
        gl.bindFramebuffer(gl.READ_FRAMEBUFFER,framebuffer);gl.readBuffer(gl.COLOR_ATTACHMENT0);const pixels=new Float32Array(width*height*4);gl.readPixels(0,0,width,height,gl.RGBA,gl.FLOAT,pixels);const error=gl.getError();
        useProgram.call(gl,saved.program);gl.bindVertexArray(saved.vao);gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,saved.draw);gl.bindFramebuffer(gl.READ_FRAMEBUFFER,saved.read);gl.viewport(...saved.viewport);
        for(const [cap,on] of capabilities)(on?gl.enable:gl.disable).call(gl,cap);
        gl.deleteFramebuffer(framebuffer);gl.deleteTexture(color);gl.deleteProgram(program);gl.deleteShader(vs);gl.deleteShader(fs);
        if(error!==gl.NO_ERROR)throw new Error('Envelope proof GL error '+error);
        let skippedPixels=0,unsafePixels=0,unbounded=0,finite=0,uncovered=0;
        for(let y=0;y<height;y++)for(let x=0;x<width;x++){
            const d=pixels[(y*width+x)*4],outside=x+0.5<rect[0]||y+0.5<rect[1]||x+0.5>=rect[2]||y+0.5>=rect[3];
            if(d===1)unbounded++;else if(d===0)uncovered++;else finite++;
            if(outside){skippedPixels++;if(d!==1)unsafePixels++;}
        }
        const result={bounds:state.bounds,skippedPixels,unsafePixels,unbounded,finite,uncovered};state.proofs.push(result);return result;
    };
    // Retain one frame's GPU resources in their original GLES context. No assets leave the page.
    const raf=window.requestAnimationFrame.bind(window);let paused=false,armed=false,capturing=false,replaying=false;
    window.requestAnimationFrame=callback=>raf(time=>{if(!paused)callback(time);});
    const isolated=window.__isolatedParticles={ready:false,error:null,externalDraws:0,draws:[]};
    const baseDraw=p.drawElementsInstanced;
    const uniformsOf=(gl,program)=>{
        const uniforms=[];
        for(let i=0;i<gl.getProgramParameter(program,gl.ACTIVE_UNIFORMS);i++){
            const info=gl.getActiveUniform(program,i),location=gl.getUniformLocation(program,info.name);if(location===null)continue;
            const value=gl.getUniform(program,location);
            uniforms.push({name:info.name,type:info.type,size:info.size,value:ArrayBuffer.isView(value)?Array.from(value):value});
        }
        return uniforms;
    };
    const saveDraw=(gl,mode,count,type,offset,instances)=>{
        const program=gl.getParameter(gl.CURRENT_PROGRAM),uniforms=uniformsOf(gl,program);
        const active=gl.getParameter(gl.ACTIVE_TEXTURE),textures=[];
        for(const uniform of uniforms){
            if(uniform.type!==gl.SAMPLER_2D)continue;
            gl.activeTexture(gl.TEXTURE0+uniform.value);
            textures.push({unit:uniform.value,texture:gl.getParameter(gl.TEXTURE_BINDING_2D),sampler:gl.getParameter(gl.SAMPLER_BINDING)});
        }
        gl.activeTexture(active);
        return {program,uniforms,textures,vao:gl.getParameter(gl.VERTEX_ARRAY_BINDING),mode,count,type,offset,instances,
            caps:[gl.BLEND,gl.DEPTH_TEST,gl.SCISSOR_TEST,gl.CULL_FACE,gl.STENCIL_TEST,gl.RASTERIZER_DISCARD,gl.POLYGON_OFFSET_FILL].map(cap=>[cap,gl.isEnabled(cap)]),
            viewport:Array.from(gl.getParameter(gl.VIEWPORT)),scissor:Array.from(gl.getParameter(gl.SCISSOR_BOX)),
            depthMask:gl.getParameter(gl.DEPTH_WRITEMASK),depthFunc:gl.getParameter(gl.DEPTH_FUNC),depthRange:Array.from(gl.getParameter(gl.DEPTH_RANGE)),
            colorMask:Array.from(gl.getParameter(gl.COLOR_WRITEMASK)),blend:[gl.BLEND_SRC_RGB,gl.BLEND_DST_RGB,gl.BLEND_SRC_ALPHA,gl.BLEND_DST_ALPHA,gl.BLEND_EQUATION_RGB,gl.BLEND_EQUATION_ALPHA].map(x=>gl.getParameter(x)),
            cull:gl.getParameter(gl.CULL_FACE_MODE),front:gl.getParameter(gl.FRONT_FACE)};
    };
    isolated.arm=()=>{if(armed||capturing||isolated.ready)throw new Error('Capture already requested');armed=true;};
    p.drawElementsInstanced=function(mode,count,type,offset,instances){
        if(paused&&!replaying)isolated.externalDraws++;
        const program=this.getParameter(this.CURRENT_PROGRAM),f=facts.get(program);
        if((armed||capturing)&&f?.particle&&count===330){
            if(armed){
                armed=false;capturing=true;isolated.gl=this;isolated.bounds=structuredClone(state.bounds);
                isolated.vertex=(attached.get(program)||[]).map(s=>shaderTexts.get(s)).find(t=>t?.includes('gl_InstanceID'));
                isolated.fragment=(attached.get(program)||[]).map(s=>shaderTexts.get(s)).find(t=>t?.includes('in float vTranslucency;'));
                isolated.metadata=metadataBuffer;
                isolated.first=saveDraw(this,mode,count,type,offset,instances);
                if(isolated.first.depthMask)throw new Error('Particle draw writes depth');
                const gl=this,width=gl.drawingBufferWidth,height=gl.drawingBufferHeight;
                const saved={draw:gl.getParameter(gl.DRAW_FRAMEBUFFER_BINDING),read:gl.getParameter(gl.READ_FRAMEBUFFER_BINDING),texture:gl.getParameter(gl.TEXTURE_BINDING_2D),scissor:gl.isEnabled(gl.SCISSOR_TEST)};
                const makeTarget=depth=>{
                    const framebuffer=gl.createFramebuffer(),color=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,color);gl.texStorage2D(gl.TEXTURE_2D,1,gl.RGBA8,width,height);
                    gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,framebuffer);gl.framebufferTexture2D(gl.DRAW_FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,color,0);
                    if(depth){const texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,texture);gl.texStorage2D(gl.TEXTURE_2D,1,gl.DEPTH_COMPONENT24,width,height);gl.framebufferTexture2D(gl.DRAW_FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.TEXTURE_2D,texture,0);}
                    if(gl.checkFramebufferStatus(gl.DRAW_FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw new Error('Isolated framebuffer incomplete');
                    return framebuffer;
                };
                isolated.target=makeTarget(true);isolated.background=makeTarget(false);
                gl.disable(gl.SCISSOR_TEST);gl.bindFramebuffer(gl.READ_FRAMEBUFFER,saved.draw);
                gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,isolated.target);gl.blitFramebuffer(0,0,width,height,0,0,width,height,gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT,gl.NEAREST);
                gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,isolated.background);gl.blitFramebuffer(0,0,width,height,0,0,width,height,gl.COLOR_BUFFER_BIT,gl.NEAREST);
                gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,saved.draw);gl.bindFramebuffer(gl.READ_FRAMEBUFFER,saved.read);gl.bindTexture(gl.TEXTURE_2D,saved.texture);if(saved.scissor)gl.enable(gl.SCISSOR_TEST);
                const error=gl.getError();if(error)throw new Error('Isolated snapshot GL error '+error);
                queueMicrotask(()=>{capturing=false;paused=true;isolated.ready=true;});
            }
            isolated.draws.push(saveDraw(this,mode,count,type,offset,instances));
        }
        return baseDraw.apply(this,arguments);
    };
    isolated.prepare=()=>{
        const gl=isolated.gl;if(!isolated.ready||isolated.draws.length!==206)throw new Error('Expected 206 frozen particle draws, got '+isolated.draws.length);
        const width=gl.drawingBufferWidth,height=gl.drawingBufferHeight,rect=isolated.bounds.rect;
        const first=isolated.draws[0];
        for(const draw of isolated.draws){
            if(draw.program!==first.program||draw.instances!==1||draw.depthMask||draw.uniforms.find(u=>u.name==='uPortalRenderDomain').value!==0)throw new Error('Frozen workload differs from the expected root gloom draws');
            if(JSON.stringify({...draw,program:0,vao:0,uniforms:0,textures:0})!==JSON.stringify({...first,program:0,vao:0,uniforms:0,textures:0}))throw new Error('Draw raster state differs');
            if(draw.vao!==first.vao||draw.textures.some((t,i)=>t.texture!==first.textures[i].texture||t.sampler!==first.textures[i].sampler))throw new Error('Gloom resources differ between draws');
        }
        const source=isolated.fragment;
        const start=source.indexOf('bool portalDeferredFragmentVisible() {');if(start<0)throw new Error('Missing portal predicate');
        let end=start+source.slice(start).indexOf('{')+1,nesting=1;while(nesting){if(source[end]==='{')nesting++;if(source[end]==='}')nesting--;end++;}
        const replacePredicate=body=>source.slice(0,start)+'bool portalDeferredFragmentVisible(){'+body+'}'+source.slice(end);
        const direct='float e=texelFetch(uPortalEnvelopeDepth,ivec2(gl_FragCoord.xy),0).r;return e==1.0||gl_FragCoord.z*0.5<e;';
        const region=`vec2 p=gl_FragCoord.xy;if(p.x<${rect[0]}.0||p.y<${rect[1]}.0||p.x>=${rect[2]}.0||p.y>=${rect[3]}.0)return true;`;
        const fullRegion=source.slice(0,start)+source.slice(start,end).replace('portalDeferredFragmentVisible','originalPortalVisible')+'\nbool portalDeferredFragmentVisible(){'+region+'return originalPortalVisible();}\n'+source.slice(end);
        const bypass=source.replace('if (!portalDeferredFragmentVisible()) discard;','').replace(/struct PortalArrivalMetadata[\s\S]*?in vec2 vTextureCoordinate;/,'in vec2 vTextureCoordinate;');
        const sources={normal:source,region:fullRegion,'direct-envelope':replacePredicate(direct),'region-direct':replacePredicate(region+direct),'no-portal':bypass};
        const compile=(type,text)=>{const shader=gl.createShader(type);shaderSource.call(gl,shader,text);gl.compileShader(shader);if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(shader));return shader;};
        const vertex=compile(gl.VERTEX_SHADER,isolated.vertex);isolated.programs={};
        const setter=(type)=>{
            if(type===gl.FLOAT)return 'uniform1f';if(type===gl.INT||type===gl.BOOL||type===gl.SAMPLER_2D)return 'uniform1i';if(type===gl.UNSIGNED_INT)return 'uniform1ui';
            for(let n=2;n<=4;n++){if(type===gl['FLOAT_VEC'+n])return 'uniform'+n+'fv';if(type===gl['INT_VEC'+n])return 'uniform'+n+'iv';if(type===gl['UNSIGNED_INT_VEC'+n])return 'uniform'+n+'uiv';if(type===gl['FLOAT_MAT'+n])return 'uniformMatrix'+n+'fv';}
            throw new Error('Unsupported uniform type '+type);
        };
        for(const [label,text] of Object.entries(sources)){
            const program=gl.createProgram(),fragment=compile(gl.FRAGMENT_SHADER,text);attachShader.call(gl,program,vertex);attachShader.call(gl,program,fragment);gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(program));gl.deleteShader(fragment);
            const block=gl.getUniformBlockIndex(program,'PortalScopeAtlasMetadata');if(block!==gl.INVALID_INDEX)gl.uniformBlockBinding(program,block,0);
            const locations=new Map(),last=new Map();
            const draws=isolated.draws.map(draw=>({...draw,updates:draw.uniforms.flatMap(uniform=>{
                const key=JSON.stringify(uniform.value);if(last.get(uniform.name)===key)return [];last.set(uniform.name,key);
                if(!locations.has(uniform.name))locations.set(uniform.name,gl.getUniformLocation(program,uniform.name));const location=locations.get(uniform.name);if(location===null)return [];
                const method=setter(uniform.type),args=method.includes('Matrix')?[false,uniform.value]:[uniform.value];return [{method,location,args}];
            })}));
            // First draw always resets the complete program state, including repeat replays.
            isolated.programs[label]={program,draws,sourceBytes:text.length};
        }
        gl.deleteShader(vertex);
        isolated.replay=(label,depth=true)=>{
            const variant=isolated.programs[label];if(!variant)throw new Error('Unknown replay mode');replaying=true;
            gl.disable(gl.SCISSOR_TEST);gl.colorMask(true,true,true,true);gl.bindFramebuffer(gl.READ_FRAMEBUFFER,isolated.background);gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,isolated.target);gl.blitFramebuffer(0,0,width,height,0,0,width,height,gl.COLOR_BUFFER_BIT,gl.NEAREST);
            for(const [cap,on] of first.caps)(on?gl.enable:gl.disable).call(gl,cap);if(!depth)gl.disable(gl.DEPTH_TEST);
            gl.viewport(...first.viewport);gl.scissor(...first.scissor);gl.depthMask(false);gl.depthFunc(first.depthFunc);gl.depthRange(...first.depthRange);gl.colorMask(...first.colorMask);gl.blendFuncSeparate(...first.blend.slice(0,4));gl.blendEquationSeparate(...first.blend.slice(4));gl.cullFace(first.cull);gl.frontFace(first.front);
            gl.bindBufferBase(gl.UNIFORM_BUFFER,0,isolated.metadata);useProgram.call(gl,variant.program);gl.bindVertexArray(first.vao);
            for(const texture of first.textures){gl.activeTexture(gl.TEXTURE0+texture.unit);gl.bindTexture(gl.TEXTURE_2D,texture.texture);gl.bindSampler(texture.unit,texture.sampler);}
            return ()=>{for(const draw of variant.draws){for(const update of draw.updates)gl[update.method](update.location,...update.args);drawElements.call(gl,draw.mode,draw.count,draw.type,draw.offset,draw.instances);}replaying=false;};
        };
        isolated.pixels=(label,depth=true)=>{isolated.replay(label,depth)();const pixels=new Uint8Array(width*height*4);gl.bindFramebuffer(gl.READ_FRAMEBUFFER,isolated.target);gl.readPixels(0,0,width,height,gl.RGBA,gl.UNSIGNED_BYTE,pixels);return pixels;};
        const baseline=isolated.pixels('normal');isolated.comparisons=[];
        for(const label of Object.keys(sources)){
            const pixels=isolated.pixels(label);let differentPixels=0,maxDifference=0,totalDifference=0;
            for(let i=0;i<pixels.length;i+=4){let different=false;for(let c=0;c<4;c++){const difference=Math.abs(pixels[i+c]-baseline[i+c]);if(difference)different=true;maxDifference=Math.max(maxDifference,difference);totalDifference+=difference;}if(different)differentPixels++;}
            isolated.comparisons.push({label,differentPixels,maxDifference,totalDifference});
        }
        isolated.validate=()=>{
            const pixels=isolated.pixels('normal');let differentPixels=0;
            for(let i=0;i<pixels.length;i+=4)if(pixels[i]!==baseline[i]||pixels[i+1]!==baseline[i+1]||pixels[i+2]!==baseline[i+2]||pixels[i+3]!==baseline[i+3])differentPixels++;
            gl.bindFramebuffer(gl.READ_FRAMEBUFFER,isolated.background);const background=new Uint8Array(width*height*4);gl.readPixels(0,0,width,height,gl.RGBA,gl.UNSIGNED_BYTE,background);let affectedPixels=0;
            for(let i=0;i<pixels.length;i+=4)if(pixels[i]!==background[i]||pixels[i+1]!==background[i+1]||pixels[i+2]!==background[i+2]||pixels[i+3]!==background[i+3])affectedPixels++;
            const result={differentPixels,affectedPixels,externalDraws:isolated.externalDraws,error:gl.getError()};if(differentPixels||!affectedPixels||result.externalDraws||result.error)throw new Error('Frozen output validation failed '+JSON.stringify(result));return result;
        };
        const debug=gl.getExtension('WEBGL_debug_renderer_info');
        return {draws:isolated.draws.length,width,height,bounds:isolated.bounds,comparisons:isolated.comparisons,uniforms:first.uniforms.filter(u=>!['uProjection','uView','uCameraPosition','uRangeLocalOrigin','uRangeLandblockOrigin','uAnchorOrigin','uRangeRotation'].includes(u.name)),raster:{caps:first.caps,blend:first.blend,depthFunc:first.depthFunc,depthMask:first.depthMask},renderer:debug?gl.getParameter(debug.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER),context:gl.getContextAttributes(),error:gl.getError()};
    };
    isolated.prepareNarrow=()=>{
        const gl=isolated.gl;if(!isolated.ready||isolated.draws.length!==206)throw new Error('Expected 206 frozen particle draws, got '+isolated.draws.length);
        const width=gl.drawingBufferWidth,height=gl.drawingBufferHeight,rect=isolated.bounds.rect;
        const first=isolated.draws[0];
        for(const draw of isolated.draws){
            if(draw.program!==first.program||draw.instances!==1||draw.depthMask||draw.uniforms.find(u=>u.name==='uPortalRenderDomain').value!==0)throw new Error('Frozen workload differs from the expected root gloom draws');
            if(JSON.stringify({...draw,program:0,vao:0,uniforms:0,textures:0})!==JSON.stringify({...first,program:0,vao:0,uniforms:0,textures:0}))throw new Error('Draw raster state differs');
            if(draw.vao!==first.vao||draw.textures.some((t,i)=>t.texture!==first.textures[i].texture||t.sampler!==first.textures[i].sampler))throw new Error('Gloom resources differ between draws');
        }
        const source=isolated.fragment;
        const start=source.indexOf('bool portalDeferredFragmentVisible() {');if(start<0)throw new Error('Missing portal predicate');
        let end=start+source.slice(start).indexOf('{')+1,nesting=1;while(nesting){if(source[end]==='{')nesting++;if(source[end]==='}')nesting--;end++;}
        const replacePredicate=body=>source.slice(0,start)+'bool portalDeferredFragmentVisible(){'+body+'}'+source.slice(end);
        const direct='float e=texelFetch(uPortalEnvelopeDepth,ivec2(gl_FragCoord.xy),0).r;return e==1.0||gl_FragCoord.z*0.5<e;';
        const region=`vec2 p=gl_FragCoord.xy;if(p.x<${rect[0]}.0||p.y<${rect[1]}.0||p.x>=${rect[2]}.0||p.y>=${rect[3]}.0)return true;`;
        const fullRegion=source.slice(0,start)+source.slice(start,end).replace('portalDeferredFragmentVisible','originalPortalVisible')+'\nbool portalDeferredFragmentVisible(){'+region+'return originalPortalVisible();}\n'+source.slice(end);
        const bypass=source.replace('if (!portalDeferredFragmentVisible()) discard;','').replace(/struct PortalArrivalMetadata[\s\S]*?in vec2 vTextureCoordinate;/,'in vec2 vTextureCoordinate;');
        const zeroAlpha=text=>text.replace('if (!portalDeferredFragmentVisible()) discard;', '').replace('if (color.a < uAlphaTest) discard;', 'color.a *= float(color.a >= uAlphaTest && portalDeferredFragmentVisible());');
        const sources={normal:source,region:fullRegion,'direct-envelope':replacePredicate(direct),'region-direct':replacePredicate(region+direct),'no-portal':bypass,'zero-alpha':zeroAlpha(source),'region-zero-alpha':zeroAlpha(fullRegion),'coordinate-kill':replacePredicate('return gl_FragCoord.x>=0.0;')};
        isolated.changingUniforms=first.uniforms.filter(u=>isolated.draws.some(d=>JSON.stringify(d.uniforms.find(v=>v.name===u.name).value)!==JSON.stringify(u.value))).map(u=>u.name);
        if(isolated.draws.some(d=>d.uniforms.find(u=>u.name==='uUsesRangeFrame').value!==0)||isolated.changingUniforms.some(n=>!['uInstanceBase','uRangeLandblockOrigin','uRangeLocalOrigin','uRangeRotation'].includes(n)))throw new Error('Cannot batch varying live uniforms: '+isolated.changingUniforms.join(','));
        isolated.slots=isolated.draws.map(d=>d.uniforms.find(u=>u.name==='uInstanceBase').value);
        const compile=(type,text)=>{const shader=gl.createShader(type);shaderSource.call(gl,shader,text);gl.compileShader(shader);if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(shader));return shader;};
        const vertex=compile(gl.VERTEX_SHADER,isolated.vertex);isolated.programs={};
        const batchText=isolated.vertex.replace('uniform int uInstanceBase;', 'uniform int uInstanceBase;uniform int uReplaySlots[206];').replace('uInstanceBase + gl_InstanceID','uReplaySlots[gl_InstanceID]');
        if(batchText===isolated.vertex||batchText.includes('uInstanceBase + gl_InstanceID'))throw new Error('Batch vertex replacement failed');
        const batchVertex=compile(gl.VERTEX_SHADER,batchText);
        for(const label of isolated.omitBatch?[]:['normal','region','no-portal'])sources['batch-'+label]=sources[label];
        const setter=(type)=>{
            if(type===gl.FLOAT)return 'uniform1f';if(type===gl.INT||type===gl.BOOL||type===gl.SAMPLER_2D)return 'uniform1i';if(type===gl.UNSIGNED_INT)return 'uniform1ui';
            for(let n=2;n<=4;n++){if(type===gl['FLOAT_VEC'+n])return 'uniform'+n+'fv';if(type===gl['INT_VEC'+n])return 'uniform'+n+'iv';if(type===gl['UNSIGNED_INT_VEC'+n])return 'uniform'+n+'uiv';if(type===gl['FLOAT_MAT'+n])return 'uniformMatrix'+n+'fv';}
            throw new Error('Unsupported uniform type '+type);
        };
        for(const [label,text] of Object.entries(sources)){
            const program=gl.createProgram(),fragment=compile(gl.FRAGMENT_SHADER,text);attachShader.call(gl,program,label.startsWith('batch-')?batchVertex:vertex);attachShader.call(gl,program,fragment);gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(program));gl.deleteShader(fragment);
            const block=gl.getUniformBlockIndex(program,'PortalScopeAtlasMetadata');if(block!==gl.INVALID_INDEX)gl.uniformBlockBinding(program,block,0);
            const locations=new Map(),last=new Map();
            const draws=isolated.draws.map(draw=>({...draw,updates:draw.uniforms.flatMap(uniform=>{
                const key=JSON.stringify(uniform.value);if(last.get(uniform.name)===key)return [];last.set(uniform.name,key);
                if(!locations.has(uniform.name))locations.set(uniform.name,gl.getUniformLocation(program,uniform.name));const location=locations.get(uniform.name);if(location===null)return [];
                const method=setter(uniform.type),args=method.includes('Matrix')?[false,uniform.value]:[uniform.value];return [{method,location,args}];
            })}));
            // First draw always resets the complete program state, including repeat replays.
            if(label.startsWith('batch-')){
                useProgram.call(gl,program);gl.uniform1iv(gl.getUniformLocation(program,'uReplaySlots[0]'),new Int32Array(isolated.slots));
                draws[0].instances=206;draws.splice(1);
            }
            isolated.programs[label]={program,draws,sourceBytes:text.length};
        }
        gl.deleteShader(vertex);gl.deleteShader(batchVertex);
        isolated.replay=(label,depth=true)=>{
            const variant=isolated.programs[label];if(!variant)throw new Error('Unknown replay mode');replaying=true;
            gl.disable(gl.SCISSOR_TEST);gl.colorMask(true,true,true,true);gl.bindFramebuffer(gl.READ_FRAMEBUFFER,isolated.background);gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,isolated.target);gl.blitFramebuffer(0,0,width,height,0,0,width,height,gl.COLOR_BUFFER_BIT,gl.NEAREST);
            for(const [cap,on] of first.caps)(on?gl.enable:gl.disable).call(gl,cap);if(!depth)gl.disable(gl.DEPTH_TEST);
            gl.viewport(...first.viewport);gl.scissor(...first.scissor);gl.depthMask(false);gl.depthFunc(first.depthFunc);gl.depthRange(...first.depthRange);gl.colorMask(...first.colorMask);gl.blendFuncSeparate(...first.blend.slice(0,4));gl.blendEquationSeparate(...first.blend.slice(4));gl.cullFace(first.cull);gl.frontFace(first.front);
            gl.bindBufferBase(gl.UNIFORM_BUFFER,0,isolated.metadata);useProgram.call(gl,variant.program);gl.bindVertexArray(first.vao);
            for(const texture of first.textures){gl.activeTexture(gl.TEXTURE0+texture.unit);gl.bindTexture(gl.TEXTURE_2D,texture.texture);gl.bindSampler(texture.unit,texture.sampler);}
            return ()=>{for(const draw of variant.draws){for(const update of draw.updates)gl[update.method](update.location,...update.args);drawElements.call(gl,draw.mode,draw.count,draw.type,draw.offset,draw.instances);}replaying=false;};
        };
        isolated.pixels=(label,depth=true)=>{isolated.replay(label,depth)();const pixels=new Uint8Array(width*height*4);gl.bindFramebuffer(gl.READ_FRAMEBUFFER,isolated.target);gl.readPixels(0,0,width,height,gl.RGBA,gl.UNSIGNED_BYTE,pixels);return pixels;};
        const baseline=isolated.pixels('normal');isolated.comparisons=[];
        for(const label of Object.keys(isolated.programs)){
            const pixels=isolated.pixels(label);let differentPixels=0,maxDifference=0,totalDifference=0;
            for(let i=0;i<pixels.length;i+=4){let different=false;for(let c=0;c<4;c++){const difference=Math.abs(pixels[i+c]-baseline[i+c]);if(difference)different=true;maxDifference=Math.max(maxDifference,difference);totalDifference+=difference;}if(different)differentPixels++;}
            isolated.comparisons.push({label,differentPixels,maxDifference,totalDifference});
        }
        isolated.validate=()=>{
            const pixels=isolated.pixels('normal');let differentPixels=0;
            for(let i=0;i<pixels.length;i+=4)if(pixels[i]!==baseline[i]||pixels[i+1]!==baseline[i+1]||pixels[i+2]!==baseline[i+2]||pixels[i+3]!==baseline[i+3])differentPixels++;
            gl.bindFramebuffer(gl.READ_FRAMEBUFFER,isolated.background);const background=new Uint8Array(width*height*4);gl.readPixels(0,0,width,height,gl.RGBA,gl.UNSIGNED_BYTE,background);let affectedPixels=0;
            for(let i=0;i<pixels.length;i+=4)if(pixels[i]!==background[i]||pixels[i+1]!==background[i+1]||pixels[i+2]!==background[i+2]||pixels[i+3]!==background[i+3])affectedPixels++;
            const result={differentPixels,affectedPixels,externalDraws:isolated.externalDraws,error:gl.getError()};if(differentPixels||!affectedPixels||result.externalDraws||result.error)throw new Error('Frozen output validation failed '+JSON.stringify(result));return result;
        };
        const debug=gl.getExtension('WEBGL_debug_renderer_info');
        return {draws:isolated.draws.length,width,height,bounds:isolated.bounds,changingUniforms:isolated.changingUniforms,slots:isolated.slots,envelopeProof:isolated.envelopeProof,comparisons:isolated.comparisons,uniforms:first.uniforms.filter(u=>!['uProjection','uView','uCameraPosition','uRangeLocalOrigin','uRangeLandblockOrigin','uAnchorOrigin','uRangeRotation'].includes(u.name)),raster:{caps:first.caps,blend:first.blend,depthFunc:first.depthFunc,depthMask:first.depthMask},renderer:debug?gl.getParameter(debug.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER),context:gl.getContextAttributes(),error:gl.getError()};
    };

    isolated.prepareExpanded=()=>{
        const gl=isolated.gl;if(!isolated.ready||isolated.draws.length!==206)throw new Error('Expected 206 frozen particle draws, got '+isolated.draws.length);
        const width=gl.drawingBufferWidth,height=gl.drawingBufferHeight,rect=isolated.bounds.rect;
        const first=isolated.draws[0];
        for(const draw of isolated.draws){
            if(draw.program!==first.program||draw.instances!==1||draw.depthMask||draw.uniforms.find(u=>u.name==='uPortalRenderDomain').value!==0)throw new Error('Frozen workload differs from the expected root gloom draws');
            if(JSON.stringify({...draw,program:0,vao:0,uniforms:0,textures:0})!==JSON.stringify({...first,program:0,vao:0,uniforms:0,textures:0}))throw new Error('Draw raster state differs');
            if(draw.vao!==first.vao||draw.textures.some((t,i)=>t.texture!==first.textures[i].texture||t.sampler!==first.textures[i].sampler))throw new Error('Gloom resources differ between draws');
        }
        const source=isolated.fragment;
        const start=source.indexOf('bool portalDeferredFragmentVisible() {');if(start<0)throw new Error('Missing portal predicate');
        let end=start+source.slice(start).indexOf('{')+1,nesting=1;while(nesting){if(source[end]==='{')nesting++;if(source[end]==='}')nesting--;end++;}
        const replacePredicate=body=>source.slice(0,start)+'bool portalDeferredFragmentVisible(){'+body+'}'+source.slice(end);
        const direct='float e=texelFetch(uPortalEnvelopeDepth,ivec2(gl_FragCoord.xy),0).r;return e==1.0||gl_FragCoord.z*0.5<e;';
        const region=`vec2 p=gl_FragCoord.xy;if(p.x<${rect[0]}.0||p.y<${rect[1]}.0||p.x>=${rect[2]}.0||p.y>=${rect[3]}.0)return true;`;
        const fullRegion=source.slice(0,start)+source.slice(start,end).replace('portalDeferredFragmentVisible','originalPortalVisible')+'\nbool portalDeferredFragmentVisible(){'+region+'return originalPortalVisible();}\n'+source.slice(end);
        const bypass=source.replace('if (!portalDeferredFragmentVisible()) discard;','').replace(/struct PortalArrivalMetadata[\s\S]*?in vec2 vTextureCoordinate;/,'in vec2 vTextureCoordinate;');
        const zeroAlpha=text=>text.replace('if (!portalDeferredFragmentVisible()) discard;', '').replace('if (color.a < uAlphaTest) discard;', 'color.a *= float(color.a >= uAlphaTest && portalDeferredFragmentVisible());');
        const sources={normal:source,region:fullRegion,'direct-envelope':replacePredicate(direct),'region-direct':replacePredicate(region+direct),'no-portal':bypass,'zero-alpha':zeroAlpha(source),'region-zero-alpha':zeroAlpha(fullRegion),'coordinate-kill':replacePredicate('return gl_FragCoord.x>=0.0;')};
        isolated.changingUniforms=first.uniforms.filter(u=>isolated.draws.some(d=>JSON.stringify(d.uniforms.find(v=>v.name===u.name).value)!==JSON.stringify(u.value))).map(u=>u.name);
        if(isolated.draws.some(d=>d.uniforms.find(u=>u.name==='uUsesRangeFrame').value!==0)||isolated.changingUniforms.some(n=>!['uInstanceBase','uRangeLandblockOrigin','uRangeLocalOrigin','uRangeRotation'].includes(n)))throw new Error('Cannot batch varying live uniforms: '+isolated.changingUniforms.join(','));
        isolated.slots=isolated.draws.map(d=>d.uniforms.find(u=>u.name==='uInstanceBase').value);
        const compile=(type,text)=>{const shader=gl.createShader(type);shaderSource.call(gl,shader,text);gl.compileShader(shader);if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(shader));return shader;};
        const vertex=compile(gl.VERTEX_SHADER,isolated.vertex);isolated.programs={};
        const batchText=isolated.vertex.replace('uniform int uInstanceBase;', 'uniform int uInstanceBase;uniform int uReplaySlots[206];').replace('uInstanceBase + gl_InstanceID','uReplaySlots[gl_InstanceID]');
        if(batchText===isolated.vertex||batchText.includes('uInstanceBase + gl_InstanceID'))throw new Error('Batch vertex replacement failed');
        const batchVertex=compile(gl.VERTEX_SHADER,batchText);
        for(const label of isolated.omitBatch?[]:['normal','region','no-portal'])sources['batch-'+label]=sources[label];
        const setter=(type)=>{
            if(type===gl.FLOAT)return 'uniform1f';if(type===gl.INT||type===gl.BOOL||type===gl.SAMPLER_2D)return 'uniform1i';if(type===gl.UNSIGNED_INT)return 'uniform1ui';
            for(let n=2;n<=4;n++){if(type===gl['FLOAT_VEC'+n])return 'uniform'+n+'fv';if(type===gl['INT_VEC'+n])return 'uniform'+n+'iv';if(type===gl['UNSIGNED_INT_VEC'+n])return 'uniform'+n+'uiv';if(type===gl['FLOAT_MAT'+n])return 'uniformMatrix'+n+'fv';}
            throw new Error('Unsupported uniform type '+type);
        };
        for(const [label,text] of Object.entries(sources)){
            const program=gl.createProgram(),fragment=compile(gl.FRAGMENT_SHADER,text);attachShader.call(gl,program,label.startsWith('batch-')?batchVertex:vertex);attachShader.call(gl,program,fragment);gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(program));gl.deleteShader(fragment);
            const block=gl.getUniformBlockIndex(program,'PortalScopeAtlasMetadata');if(block!==gl.INVALID_INDEX)gl.uniformBlockBinding(program,block,0);
            const locations=new Map(),last=new Map();
            const draws=isolated.draws.map(draw=>({...draw,updates:draw.uniforms.flatMap(uniform=>{
                const key=JSON.stringify(uniform.value);if(last.get(uniform.name)===key)return [];last.set(uniform.name,key);
                if(!locations.has(uniform.name))locations.set(uniform.name,gl.getUniformLocation(program,uniform.name));const location=locations.get(uniform.name);if(location===null)return [];
                const method=setter(uniform.type),args=method.includes('Matrix')?[false,uniform.value]:[uniform.value];return [{method,location,args}];
            })}));
            // First draw always resets the complete program state, including repeat replays.
            if(label.startsWith('batch-')){
                useProgram.call(gl,program);gl.uniform1iv(gl.getUniformLocation(program,'uReplaySlots[0]'),new Int32Array(isolated.slots));
                draws[0].instances=206;draws.splice(1);
            }
            isolated.programs[label]={program,draws,sourceBytes:text.length};
        }
        gl.deleteShader(vertex);gl.deleteShader(batchVertex);
        // Copy the real depth-format envelope into an ordinary float color texture.
        const originalEnvelope=first.textures.find(t=>t.unit===5).texture;
        const copyVertex=compile(gl.VERTEX_SHADER,'#version 300 es\nvoid main(){vec2 p=gl_VertexID==0?vec2(-1.,-1.):gl_VertexID==1?vec2(3.,-1.):vec2(-1.,3.);gl_Position=vec4(p,0.,1.);}');
        const copyFragment=compile(gl.FRAGMENT_SHADER,'#version 300 es\nprecision highp float;uniform highp sampler2D source;out vec4 color;void main(){color=vec4(texelFetch(source,ivec2(gl_FragCoord.xy),0).r,0.,0.,1.);}');
        const copyProgram=gl.createProgram();attachShader.call(gl,copyProgram,copyVertex);attachShader.call(gl,copyProgram,copyFragment);gl.linkProgram(copyProgram);if(!gl.getProgramParameter(copyProgram,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(copyProgram));
        if(!gl.getExtension('EXT_color_buffer_float'))throw new Error('Float color targets unavailable');
        const colorEnvelope=gl.createTexture(),copyFramebuffer=gl.createFramebuffer();gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,colorEnvelope);gl.texStorage2D(gl.TEXTURE_2D,1,gl.R32F,width,height);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);gl.bindSampler(0,null);
        gl.bindFramebuffer(gl.FRAMEBUFFER,copyFramebuffer);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,colorEnvelope,0);if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw new Error('Envelope copy framebuffer incomplete');
        for(const [cap] of first.caps)gl.disable(cap);gl.colorMask(true,true,true,true);gl.viewport(0,0,width,height);gl.activeTexture(gl.TEXTURE0+5);gl.bindTexture(gl.TEXTURE_2D,originalEnvelope);gl.bindSampler(5,null);useProgram.call(gl,copyProgram);gl.uniform1i(gl.getUniformLocation(copyProgram,'source'),5);gl.bindVertexArray(null);drawArrays.call(gl,gl.TRIANGLES,0,3);
        gl.bindFramebuffer(gl.READ_FRAMEBUFFER,copyFramebuffer);const envelopePixels=new Float32Array(width*height*4);gl.readPixels(0,0,width,height,gl.RGBA,gl.FLOAT,envelopePixels);let unsafePixels=0,finitePixels=0,uncoveredPixels=0;
        for(let y=0;y<height;y++)for(let x=0;x<width;x++){const e=envelopePixels[(y*width+x)*4];if(e===0)uncoveredPixels++;else if(e!==1)finitePixels++;if((x+.5<rect[0]||y+.5<rect[1]||x+.5>=rect[2]||y+.5>=rect[3])&&e!==1)unsafePixels++;}
        isolated.envelopeProof={unsafePixels,finitePixels,uncoveredPixels};if(unsafePixels)throw new Error('Unsafe frozen portal rectangle');
        for(const label of ['normal','region','direct-envelope','region-direct','no-portal'])isolated.programs['color-'+label]=isolated.programs[label];
        isolated.replay=(label,depth=true)=>{
            const variant=isolated.programs[label];if(!variant)throw new Error('Unknown replay mode');replaying=true;
            gl.disable(gl.SCISSOR_TEST);gl.colorMask(true,true,true,true);gl.bindFramebuffer(gl.READ_FRAMEBUFFER,isolated.background);gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,isolated.target);gl.blitFramebuffer(0,0,width,height,0,0,width,height,gl.COLOR_BUFFER_BIT,gl.NEAREST);
            for(const [cap,on] of first.caps)(on?gl.enable:gl.disable).call(gl,cap);if(!depth)gl.disable(gl.DEPTH_TEST);
            gl.viewport(...first.viewport);gl.scissor(...first.scissor);gl.depthMask(false);gl.depthFunc(first.depthFunc);gl.depthRange(...first.depthRange);gl.colorMask(...first.colorMask);gl.blendFuncSeparate(...first.blend.slice(0,4));gl.blendEquationSeparate(...first.blend.slice(4));gl.cullFace(first.cull);gl.frontFace(first.front);
            gl.bindBufferBase(gl.UNIFORM_BUFFER,0,isolated.metadata);useProgram.call(gl,variant.program);gl.bindVertexArray(first.vao);
            for(const texture of first.textures){gl.activeTexture(gl.TEXTURE0+texture.unit);gl.bindTexture(gl.TEXTURE_2D,label.startsWith('color-')&&texture.unit===5?colorEnvelope:texture.texture);gl.bindSampler(texture.unit,texture.sampler);}
            return ()=>{for(const draw of variant.draws){for(const update of draw.updates)gl[update.method](update.location,...update.args);drawElements.call(gl,draw.mode,draw.count,draw.type,draw.offset,draw.instances);}replaying=false;};
        };
        isolated.pixels=(label,depth=true)=>{isolated.replay(label,depth)();const pixels=new Uint8Array(width*height*4);gl.bindFramebuffer(gl.READ_FRAMEBUFFER,isolated.target);gl.readPixels(0,0,width,height,gl.RGBA,gl.UNSIGNED_BYTE,pixels);return pixels;};
        const baseline=isolated.pixels('normal');isolated.comparisons=[];
        for(const label of Object.keys(isolated.programs)){
            const pixels=isolated.pixels(label);let differentPixels=0,maxDifference=0,totalDifference=0;
            for(let i=0;i<pixels.length;i+=4){let different=false;for(let c=0;c<4;c++){const difference=Math.abs(pixels[i+c]-baseline[i+c]);if(difference)different=true;maxDifference=Math.max(maxDifference,difference);totalDifference+=difference;}if(different)differentPixels++;}
            isolated.comparisons.push({label,differentPixels,maxDifference,totalDifference});
        }
        const debug=gl.getExtension('WEBGL_debug_renderer_info');
        return {draws:isolated.draws.length,width,height,bounds:isolated.bounds,changingUniforms:isolated.changingUniforms,slots:isolated.slots,envelopeProof:isolated.envelopeProof,comparisons:isolated.comparisons,uniforms:first.uniforms.filter(u=>!['uProjection','uView','uCameraPosition','uRangeLocalOrigin','uRangeLandblockOrigin','uAnchorOrigin','uRangeRotation'].includes(u.name)),raster:{caps:first.caps,blend:first.blend,depthFunc:first.depthFunc,depthMask:first.depthMask},renderer:debug?gl.getParameter(debug.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER),context:gl.getContextAttributes(),error:gl.getError()};
    };

    isolated.measure=async(label,depth=true,samples=40)=>{
        const gl=isolated.gl,ext=gl.getExtension('EXT_disjoint_timer_query_webgl2');if(!ext)throw new Error('GPU timer unavailable');
        const values=[],cpuValues=[];for(let i=0;i<samples+8;i++){
            const draw=isolated.replay(label,depth),query=gl.createQuery();gl.beginQuery(ext.TIME_ELAPSED_EXT,query);const cpuStart=performance.now();draw();const cpuMs=performance.now()-cpuStart;gl.endQuery(ext.TIME_ELAPSED_EXT);gl.flush();
            const deadline=performance.now()+10000;while(!gl.getQueryParameter(query,gl.QUERY_RESULT_AVAILABLE)){if(performance.now()>deadline)throw new Error('Query timed out');await new Promise(resolve=>setTimeout(resolve,2));}
            if(gl.getParameter(ext.GPU_DISJOINT_EXT))throw new Error('GPU clock disjoint');const ms=gl.getQueryParameter(query,gl.QUERY_RESULT)/1e6;gl.deleteQuery(query);if(i>=8){values.push(ms);cpuValues.push(cpuMs);}
        }
        const error=gl.getError();if(error)throw new Error('Replay GL error '+error);
        if(isolated.externalDraws)throw new Error('Live renderer drew during frozen replay');
        return {label,depth,values,cpuValues,externalDraws:isolated.externalDraws};
    };

}