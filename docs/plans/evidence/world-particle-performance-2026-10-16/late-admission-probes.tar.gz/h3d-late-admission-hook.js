() => {
 const c=globalThis.__h3dLateClasses;
 if(!c?.RenderWorld||!c?.DynamicDepthPreparations||!c?.ParticleSystem||!c?.isEntityShadowCasterClass)throw new Error('Late-admission diagnostic build missing');
 const s=window.__h3dLateAdmission={early:false,counting:false,frames:0,owners:new Set(),rows:{},groundingNode:null,classes:new Map()};
 s.reset=()=>{s.frames=0;s.rows={};s.groundingNode=null;s.classes.clear();};
 const row=cls=>s.rows[cls]??=( {visibleContributions:0,withColorRanges:0,groundingAttempts:0,indoorDepthRequests:0,simpleOutdoorDepthRequests:0,prepareCalls:0,cacheHits:0,cacheMisses:0,nonemptyDepth:0,depthSpans:0,depthParts:0,depthTriangles:0,resolvedCasters:0,dominantVisits:0,dominantDepthRequests:0});
 s.visit=(id,cls,enabled,ranges)=>{s.groundingNode=null;s.classes.set(id,cls);const r=row(cls);r.visibleContributions++;if(s.owners.has(id))r.dominantVisits++;if(ranges>0){r.withColorRanges++;if(enabled)s.groundingNode=id;}};
 s.depth=(id,cls,indoor,simple,depth,caster)=>{const r=row(cls);r.groundingAttempts++;if(indoor)r.indoorDepthRequests++;if(simple)r.simpleOutdoorDepthRequests++;if((indoor||simple)&&s.owners.has(id))r.dominantDepthRequests++;if(caster!==null)r.resolvedCasters++;s.groundingNode=null;};
 const prepare=c.DynamicDepthPreparations.prototype.prepare,collect=c.ParticleSystem.prototype.collectDrawRanges;
 c.DynamicDepthPreparations.prototype.prepare=function(id){
  if(!s.counting||s.groundingNode!==id)return prepare.apply(this,arguments);
  const r=row(s.classes.get(id));r.prepareCalls++;if(this.__h3dHasShadow(id))r.cacheHits++;else r.cacheMisses++;
  const value=prepare.apply(this,arguments);if(value!==null){r.nonemptyDepth++;r.depthSpans+=value.ranges.length;r.depthParts+=value.selectedPartCount;r.depthTriangles+=value.selectedTriangleCount;}return value;
 };
 c.ParticleSystem.prototype.collectDrawRanges=function(){const ranges=collect.apply(this,arguments);if(s.counting){s.owners.clear();for(const r of ranges)if(r.hwGfxObjId==='0x01003fa7')s.owners.add(r.renderOwner);}return ranges;};
 s.stopCounting=()=>{s.counting=false;c.DynamicDepthPreparations.prototype.prepare=prepare;c.ParticleSystem.prototype.collectDrawRanges=collect;};
 s.restore=()=>{s.stopCounting();s.early=false;};
}
