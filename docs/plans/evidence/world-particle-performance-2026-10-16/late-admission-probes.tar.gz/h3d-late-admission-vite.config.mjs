import base from '/home/me/code/holtburger/apps/holtburger-3d/vite.config.ts';
const refs=new Map([
 ['/src/lib/game/renderer/render-world.ts','RenderWorld'],
 ['/src/lib/game/renderer/webgl2-renderer.ts','WebGL2Renderer'],
 ['/src/lib/game/renderer/dynamic-depth-preparation.ts','DynamicDepthPreparations'],
 ['/src/lib/game/renderer/entity-grounding.ts','resolveEntityShadowCaster'],
 ['/src/lib/game/renderer/entity-shadow-policy.ts','isEntityShadowCasterClass'],
 ['/src/lib/game/systems/particle-system.ts','ParticleSystem'],
 ['/src/lib/game/math/types.ts','Mat4'],
]);
function replaceOnce(code,needle,replacement){if(!code.includes(needle)||code.indexOf(needle)!==code.lastIndexOf(needle))throw new Error('Diagnostic source shape changed: '+needle);return code.replace(needle,replacement);}
export default {...base,plugins:[...base.plugins,{name:'h3d-late-admission-investigation',transform(code,id){
 if(id.endsWith('/src/lib/game/renderer/webgl2-renderer.ts')){
  code=replaceOnce(code,'if (entityShadowsEnabled && retainedDynamicContributionCount > 0) {',`if (globalThis.__h3dLateAdmission?.counting) globalThis.__h3dLateAdmission.visit(nodeId,contribution.entityClass,entityShadowsEnabled,retainedDynamicContributionCount);
    if (entityShadowsEnabled && retainedDynamicContributionCount > 0 && (!globalThis.__h3dLateAdmission?.early || globalThis.__h3dLateClasses.isEntityShadowCasterClass(contribution.entityClass))) {`);
  code=replaceOnce(code,'if (caster?.indoorGrounding) {',`if (globalThis.__h3dLateAdmission?.counting) globalThis.__h3dLateAdmission.depth(nodeId,contribution.entityClass,reachesIndoor,simpleOutdoorShadows && reachesOutdoors,depth,caster);
    if (caster?.indoorGrounding) {`);
  const marker='\t#resolveSceneContributions(';
  const start=code.indexOf(marker),body=code.indexOf('const resolutionStartedAt',start);if(start<0||body<0)throw new Error('Missing contribution method');
  code=code.slice(0,body)+`if(globalThis.__h3dLateAdmission?.counting)globalThis.__h3dLateAdmission.frames++;
    `+code.slice(body);
 }
 if(id.endsWith('/src/lib/game/renderer/dynamic-depth-preparation.ts')){
  code=replaceOnce(code,'class DynamicDepthPreparations {',`class DynamicDepthPreparations {
   __h3dHasShadow(nodeId){return this.#preparedShadow.has(nodeId);}`);
 }
 for(const [suffix,name] of refs)if(id.endsWith(suffix))return {code:code+`\nglobalThis.__h3dLateClasses ??= {};globalThis.__h3dLateClasses.${name}=${name};\n`,map:null};
 }}],build:{...base.build,outDir:'/tmp/h3d-late-admission-dist',emptyOutDir:true}};
