"""Validate retained late-admission investigation evidence from the repository root."""
from pathlib import Path
import gzip,hashlib,json,statistics,tarfile
root=Path.cwd();base=root/'docs/plans/evidence/world-particle-performance-2026-10-16'
manifest=json.loads((base/'manifest.json').read_text())
for item in manifest['files']:
 data=(base/item['path']).read_bytes()
 assert len(data)==item['bytes'],item['path']
 assert hashlib.sha256(data).hexdigest()==item['sha256'],item['path']
raw=json.loads(gzip.decompress((base/'late-admission-trials.json.gz').read_bytes()))
fixture=json.loads(gzip.decompress((base/'late-admission-fixture.json.gz').read_bytes()))
summary=json.loads((base/'late-admission-summary.json').read_text())
assert len(raw['audits'])==6 and len(raw['trials'])==30
assert raw['cleanup']=={'restoredShadowMode':raw['context']['savedGraphics']['entityShadowMode'],'hooksRestored':True}
assert 'OpenGL ES' in raw['context']['glRenderer']
for mode in ['simple','shadow-maps','none']:
 for early in [False,True]:
  ts=[t for t in raw['trials'] if t['shadowMode']==mode and t['early']==early]
  assert sorted(t['round'] for t in ts)==list(range(5))
  assert all(t['windowMs']>=4000 and t['snapshot']['sampledFrameCount']>0 for t in ts)
  values=[t['snapshot']['diagnostics']['renderer']['profile']['cpu']['mean']['sceneContributionResolutionMs'] for t in ts]
  assert statistics.median(values)==summary['timing'][mode]['early' if early else 'baseline']['sceneCpuMs']['median']
  audit=next(a for a in raw['audits'] if a['shadowMode']==mode and a['early']==early)
  assert audit['dominantOwners']==206
  assert audit['frames']==audit['snapshot']['sampledFrameCount']
  for cls,row in audit['rows'].items():
   assert row['prepareCalls']==row['cacheHits']+row['cacheMisses']
   if cls in ['other','portal']:
    assert row['resolvedCasters']==0
    if early:assert row['groundingAttempts']==row['prepareCalls']==0
    if mode!='simple':assert row['prepareCalls']==0
   if mode=='none':assert row['groundingAttempts']==0
baseline=next(a for a in raw['audits'] if a['shadowMode']=='simple' and not a['early'])
assert baseline['rows']['other']['prepareCalls']>0
assert baseline['rows']['other']['prepareCalls']==baseline['rows']['other']['cacheMisses']==baseline['rows']['other']['nonemptyDepth']
assert fixture['cases']==len(fixture['results'])==150
assert fixture['equal'] and fixture['nonCasterInputsUntouched'] and fixture['nonemptyIndoorCases']>0
for case in fixture['results']:
 assert case['equal']
 if case['entityClass'] in ['other','portal']:
  assert not case['nonemptyOutput']
  assert case['baseline']['depthRequests']==1 and case['early']['depthRequests']==0
 else:assert case['baseline']==case['early']
for source,digest in summary['productionSourceHashes'].items():
 data=(root/source).read_bytes()
 assert hashlib.sha256(data).hexdigest()==digest,source
 assert not any(x in data for x in [b'__h3dLateAdmission',b'__h3dLateClasses',b'__h3dHasShadow']),source
removed=set(manifest['sanitization']['removedKeys'])
def clean(value):
 if isinstance(value,list):
  for item in value:clean(item)
 if isinstance(value,dict):
  assert not removed.intersection(value)
  if 'consoleMessages' in value:assert all(set(item)<={'level','count'} for item in value['consoleMessages'])
  for item in value.values():clean(item)
for value in [raw,fixture,summary]:clean(value)
with tarfile.open(base/'late-admission-probes.tar.gz') as archive:
 for member in archive.getmembers():
  assert member.isfile() and member.name==Path(member.name).name
  assert archive.extractfile(member).read()
print(json.dumps({'ok':True,'artifacts':len(manifest['files']),'audits':6,'pairedWindows':30,'syntheticCases':150,'productionSourcesUnchanged':len(summary['productionSourceHashes'])}))
