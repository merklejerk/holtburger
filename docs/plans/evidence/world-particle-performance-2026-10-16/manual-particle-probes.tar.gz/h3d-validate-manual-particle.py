from pathlib import Path
import gzip,hashlib,json,tarfile
root=Path.cwd();base=root/'docs/plans/evidence/world-particle-performance-2026-10-16';m=json.loads((base/'manifest.json').read_text())
for f in m['files']:
 b=(base/f['path']).read_bytes();assert len(b)==f['bytes']and hashlib.sha256(b).hexdigest()==f['sha256'],f['path']
s=json.loads((base/'manual-particle-summary.json').read_text());r=json.loads(gzip.decompress((base/'manual-particle-verification.json.gz').read_bytes()));c=r['verification']['check']
assert s['enabled']and c['unrestrictedDraws']>0 and c['hooksRestored']and all(c[k]==0 for k in ['portalAwareDraws','depthInputDraws','depthDisabledDraws','depthWritingDraws'])
for path,digest in s['productionSourceHashes'].items():assert hashlib.sha256((root/path).read_bytes()).hexdigest()==digest,path
assert 'const BYPASS_PARTICLE_PORTAL_VISIBILITY_FOR_MANUAL_REVIEW = true;'in(root/'apps/holtburger-3d/src/lib/game/renderer/webgl2-renderer.ts').read_text()
with tarfile.open(base/'manual-particle-probes.tar.gz')as archive:
 for member in archive.getmembers():
  assert member.isfile()and '..'not in Path(member.name).parts and not Path(member.name).is_absolute()
  if member.name.startswith('original/'):assert hashlib.sha256(archive.extractfile(member).read()).hexdigest()==s['preExperimentSourceHashes'][Path(member.name).name]
print(json.dumps({'ok':True,'artifacts':len(m['files']),'bypassEnabled':True,'depthTestingPreserved':True,'hooksRestored':True,'manualAcceptance':s['manualAcceptance']}))
