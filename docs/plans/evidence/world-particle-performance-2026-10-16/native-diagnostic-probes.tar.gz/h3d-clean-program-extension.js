    const normalLink=p.linkProgram,normalGetLocation=p.getUniformLocation,spatialUse=p.useProgram;
    const pairs=new WeakMap(),locations=new WeakMap(),physical=new WeakMap();
    const methods=['uniform1f','uniform1i','uniform1ui','uniform2f','uniform2i','uniform2ui','uniform3f','uniform3i','uniform3ui','uniform4f','uniform4i','uniform4ui','uniform1fv','uniform2fv','uniform3fv','uniform4fv','uniform1iv','uniform2iv','uniform3iv','uniform4iv','uniform1uiv','uniform2uiv','uniform3uiv','uniform4uiv','uniformMatrix2fv','uniformMatrix3fv','uniformMatrix4fv','uniformMatrix2x3fv','uniformMatrix2x4fv','uniformMatrix3x2fv','uniformMatrix3x4fv','uniformMatrix4x2fv','uniformMatrix4x3fv'];
    const nativeUniform=Object.fromEntries(methods.map(n=>[n,p[n]]));state.programs=[];
    p.linkProgram=function(program){
        normalLink.call(this,program);
        const shaders=attached.get(program)||[],fragment=shaders.find(s=>(shaderTexts.get(s)||'').includes('bool portalDeferredFragmentVisible() {')&&(shaderTexts.get(s)||'').includes('in float vTranslucency;'));
        if(!fragment)return;
        const text=shaderTexts.get(fragment),vertex=shaders.find(s=>this.getShaderParameter(s,this.SHADER_TYPE)===this.VERTEX_SHADER);
        let region=text.replace('bool portalDeferredFragmentVisible() {',`bool portalOriginalFragmentVisible() {`);
        region=region.replace('vec4 sampleMaterial()',`bool portalDeferredFragmentVisible(){
            if(uPortalRenderDomain==0u){
                vec2 p=gl_FragCoord.xy;
                if(p.x<459.0||p.y<480.0||p.x>=1122.0||p.y>=588.0)return true;
            }
            return portalOriginalFragmentVisible();
        }
        vec4 sampleMaterial()`);
        const bypass=text.replace('if (!portalDeferredFragmentVisible()) discard;','').replace(/struct PortalArrivalMetadata[\s\S]*?in vec2 vTextureCoordinate;/,'in vec2 vTextureCoordinate;');
        const variants=new Map([['normal',program]]),variantLocations=new Map([['normal',new Map()]]);
        for(const [label,source] of [['region',region],['no-portal',bypass]]){
            if(source.includes('uDiagnostic'))throw new Error('Clean fragment still has diagnostic uniforms');
            const shader=this.createShader(this.FRAGMENT_SHADER);shaderSource.call(this,shader,source);this.compileShader(shader);if(!this.getShaderParameter(shader,this.COMPILE_STATUS))throw new Error(this.getShaderInfoLog(shader));
            const alt=this.createProgram();attachShader.call(this,alt,vertex);attachShader.call(this,alt,shader);normalLink.call(this,alt);this.deleteShader(shader);if(!this.getProgramParameter(alt,this.LINK_STATUS))throw new Error(this.getProgramInfoLog(alt));
            const block=this.getUniformBlockIndex(alt,'PortalScopeAtlasMetadata');if(block!==this.INVALID_INDEX)this.uniformBlockBinding(alt,block,0);
            variants.set(label,alt);variantLocations.set(label,new Map());state.programs.push({label,bytes:source.length,portalBlock:block!==this.INVALID_INDEX,diagnosticUniforms:false});
        }
        pairs.set(program,{variants,variantLocations,values:new Map(),last:null});
    };
    const targetLocation=(gl,pair,label,name)=>{const cache=pair.variantLocations.get(label);if(!cache.has(name))cache.set(name,normalGetLocation.call(gl,pair.variants.get(label),name));return cache.get(name);};
    p.getUniformLocation=function(program,name){const location=normalGetLocation.call(this,program,name),pair=pairs.get(program);if(location&&pair)locations.set(location,{pair,name});return location;};
    p.useProgram=function(program){
        spatialUse.call(this,program);const pair=pairs.get(program);if(!pair){physical.delete(this);return;}
        const label=state.mode,target=pair.variants.get(label);if(!target)throw new Error('Unsupported clean program mode '+label);
        if(target!==program)useProgram.call(this,target);physical.set(this,{pair,label});
        if(pair.last!==label){for(const [name,v] of pair.values)nativeUniform[v.method].call(this,targetLocation(this,pair,label,name),...v.args);pair.last=label;}
    };
    for(const method of methods)p[method]=function(location,...args){
        const info=location&&locations.get(location);if(!info)return nativeUniform[method].call(this,location,...args);
        info.pair.values.set(info.name,{method,args:args.map(v=>ArrayBuffer.isView(v)?Array.from(v):v)});
        const active=physical.get(this),label=active?.pair===info.pair?active.label:'normal';
        return nativeUniform[method].call(this,targetLocation(this,info.pair,label,info.name),...args);
    };
