() => {
    const p=WebGL2RenderingContext.prototype;
    const shaderSource=p.shaderSource, attachShader=p.attachShader, useProgram=p.useProgram;
    const bindBuffer=p.bindBuffer, bindBufferBase=p.bindBufferBase, bufferSubData=p.bufferSubData;
    const drawArrays=p.drawArrays, drawElements=p.drawElementsInstanced;
    const programs=new WeakMap(), attached=new WeakMap(), shaderTexts=new WeakMap(), facts=new WeakMap();
    const buffers=new WeakMap(), bindings=new Map();
    const state=window.__spatialAudit={mode:'normal',frames:0,counts:{draws:0,instances:0},bounds:null,firstDraw:null,proofs:[]};
    const inject=(text)=>text;
    p.shaderSource=function(shader,text){text=inject(text);shaderTexts.set(shader,text);return shaderSource.call(this,shader,text);};
    p.attachShader=function(program,shader){let list=attached.get(program);if(!list){list=[];attached.set(program,list);}list.push(shader);return attachShader.call(this,program,shader);};
    p.useProgram=function(program){
        programs.set(this,program);
        if(program && !facts.has(program)){
            const texts=(attached.get(program)||[]).map(s=>shaderTexts.get(s)||'');
            const root=texts.some(t=>t.includes('uint current = 1u;')&&t.includes('flat in uint vOutputArrival;'));
            const particle=this.getUniformLocation(program,'uParticleRecords')!==null;
            facts.set(program,{root,particle,mode:particle?this.getUniformLocation(program,'uDiagnosticSpatialMode'):null,affected:particle?this.getUniformLocation(program,'uDiagnosticAffected'):null,ordinal:particle?this.getUniformLocation(program,'uPortalRenderDomain'):null});
        }
        return useProgram.call(this,program);
    };
    p.bindBuffer=function(target,buffer){bindings.set(target,buffer);return bindBuffer.call(this,target,buffer);};
    let metadataBuffer=null;
    p.bindBufferBase=function(target,index,buffer){if(target===this.UNIFORM_BUFFER&&index===0)metadataBuffer=buffer;return bindBufferBase.call(this,target,index,buffer);};
    p.bufferSubData=function(target,dst,src,srcOffset=0,length){
        if(dst===0 && ArrayBuffer.isView(src) && src.BYTES_PER_ELEMENT===1 && (target===this.ARRAY_BUFFER || target===this.UNIFORM_BUFFER)){
            const bytes=length===undefined?src.byteLength-srcOffset:length;
            buffers.set(bindings.get(target),new Uint8Array(src.buffer,src.byteOffset+srcOffset,bytes).slice());
        }
        return bufferSubData.apply(this,arguments);
    };
    p.drawArrays=function(mode,first,count){
        const f=facts.get(programs.get(this));
        if(f?.root){
            const metadata=buffers.get(metadataBuffer);if(!metadata || metadata.byteLength!==16384)throw new Error('Missing mirrored portal metadata');
            const buffer=this.getVertexAttrib(0,this.VERTEX_ATTRIB_ARRAY_BUFFER_BINDING),triangles=buffers.get(buffer);
            if(!triangles || first!==0 || count%3!==0 || triangles.byteLength!==count*24)throw new Error('Crossing stream layout differs');
            const matrix=new Float32Array(metadata.buffer,metadata.byteOffset,16),verts=new DataView(triangles.buffer,triangles.byteOffset,triangles.byteLength);
            const width=this.drawingBufferWidth,height=this.drawingBufferHeight;
            let left=width,bottom=height,right=0,top=0,rootTriangles=0,eyePlaneFallback=false;
            const routes=new Set();
            for(let i=0;i<count;i+=3){
                const offset=i*24;if(verts.getUint32(offset+16,true)!==0)continue;
                rootTriangles++;routes.add(verts.getUint32(offset+12,true));
                for(let v=0;v<3;v++){
                    const o=offset+v*24,x=verts.getFloat32(o,true),y=verts.getFloat32(o+4,true),z=verts.getFloat32(o+8,true);
                    const w=matrix[3]*x+matrix[7]*y+matrix[11]*z+matrix[15];
                    if(w<=0.00001){eyePlaneFallback=true;continue;}
                    const px=((matrix[0]*x+matrix[4]*y+matrix[8]*z+matrix[12])/w+1)*width/2;
                    const py=((matrix[1]*x+matrix[5]*y+matrix[9]*z+matrix[13])/w+1)*height/2;
                    left=Math.min(left,px);right=Math.max(right,px);bottom=Math.min(bottom,py);top=Math.max(top,py);
                }
            }
            const rect=eyePlaneFallback?[0,0,width,height]:rootTriangles?[Math.max(0,Math.floor(left)-3),Math.max(0,Math.floor(bottom)-3),Math.min(width,Math.ceil(right)+3),Math.min(height,Math.ceil(top)+3)]:[0,0,0,0];
            const slots=new Uint32Array(metadata.buffer,metadata.byteOffset+8224,8);
            if(slots[0]!==0||slots[1]!==0||slots[2]!==0||slots[3]!==0||slots[4]!==width||slots[5]!==height)throw new Error('Root mapping is not full viewport');
            state.bounds={rect,rootTriangles,rootCrossings:routes.size,eyePlaneFallback,width,height,area:Math.max(0,rect[2]-rect[0])*Math.max(0,rect[3]-rect[1])};state.frames++;
        }
        return drawArrays.apply(this,arguments);
    };
    p.drawElementsInstanced=function(mode,count,type,offset,instances){
        const f=facts.get(programs.get(this));if(f?.particle&&count===330){state.gl=this;state.counts.draws++;state.counts.instances+=instances;}
        return drawElements.apply(this,arguments);
    };
    state.inspectEnvelope=()=>{
        const gl=state.gl;if(!gl || !state.bounds)throw new Error('Missing spatial draw state');
        const rect=[...state.bounds.rect];
        if(!gl.getExtension('EXT_color_buffer_float'))throw new Error('Float color target unavailable');
        const saved={program:gl.getParameter(gl.CURRENT_PROGRAM),vao:gl.getParameter(gl.VERTEX_ARRAY_BINDING),draw:gl.getParameter(gl.DRAW_FRAMEBUFFER_BINDING),read:gl.getParameter(gl.READ_FRAMEBUFFER_BINDING),viewport:Array.from(gl.getParameter(gl.VIEWPORT)),texture:gl.getParameter(gl.TEXTURE_BINDING_2D)};
        const capabilities=[gl.BLEND,gl.DEPTH_TEST,gl.SCISSOR_TEST,gl.CULL_FACE,gl.STENCIL_TEST].map(cap=>[cap,gl.isEnabled(cap)]);
        const compile=(kind,source)=>{const shader=gl.createShader(kind);shaderSource.call(gl,shader,source);gl.compileShader(shader);if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(shader));return shader;};
        const vs=compile(gl.VERTEX_SHADER,'#version 300 es\nvoid main(){vec2 p=gl_VertexID==0?vec2(-1.,-1.):gl_VertexID==1?vec2(3.,-1.):vec2(-1.,3.);gl_Position=vec4(p,0.,1.);}');
        const fs=compile(gl.FRAGMENT_SHADER,'#version 300 es\nprecision highp float;uniform sampler2D envelope;out vec4 color;void main(){float d=texelFetch(envelope,ivec2(gl_FragCoord.xy),0).r;color=vec4(d,d,d,1.);}');
        const program=gl.createProgram();attachShader.call(gl,program,vs);attachShader.call(gl,program,fs);gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(program));
        const width=gl.drawingBufferWidth,height=gl.drawingBufferHeight;
        const color=gl.createTexture(),framebuffer=gl.createFramebuffer();gl.bindTexture(gl.TEXTURE_2D,color);gl.texStorage2D(gl.TEXTURE_2D,1,gl.RGBA32F,width,height);gl.bindTexture(gl.TEXTURE_2D,saved.texture);
        gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,framebuffer);gl.framebufferTexture2D(gl.DRAW_FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,color,0);if(gl.checkFramebufferStatus(gl.DRAW_FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw new Error('Envelope proof framebuffer incomplete');
        for(const [cap] of capabilities)gl.disable(cap);
        gl.viewport(0,0,width,height);useProgram.call(gl,program);gl.uniform1i(gl.getUniformLocation(program,'envelope'),5);gl.bindVertexArray(null);drawArrays.call(gl,gl.TRIANGLES,0,3);
        gl.bindFramebuffer(gl.READ_FRAMEBUFFER,framebuffer);gl.readBuffer(gl.COLOR_ATTACHMENT0);const pixels=new Float32Array(width*height*4);gl.readPixels(0,0,width,height,gl.RGBA,gl.FLOAT,pixels);const error=gl.getError();
        useProgram.call(gl,saved.program);gl.bindVertexArray(saved.vao);gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,saved.draw);gl.bindFramebuffer(gl.READ_FRAMEBUFFER,saved.read);gl.viewport(...saved.viewport);
        for(const [cap,on] of capabilities)(on?gl.enable:gl.disable).call(gl,cap);
        gl.deleteFramebuffer(framebuffer);gl.deleteTexture(color);gl.deleteProgram(program);gl.deleteShader(vs);gl.deleteShader(fs);
        if(error!==gl.NO_ERROR)throw new Error('Envelope proof GL error '+error);
        let skippedPixels=0,unsafePixels=0,unbounded=0,finite=0,uncovered=0;
        for(let y=0;y<height;y++)for(let x=0;x<width;x++){
            const d=pixels[(y*width+x)*4],outside=x+0.5<rect[0]||y+0.5<rect[1]||x+0.5>=rect[2]||y+0.5>=rect[3];
            if(d===1)unbounded++;else if(d===0)uncovered++;else finite++;
            if(outside){skippedPixels++;if(d!==1)unsafePixels++;}
        }
        const result={bounds:state.bounds,skippedPixels,unsafePixels,unbounded,finite,uncovered};state.proofs.push(result);return result;
    };
    const normalLink=p.linkProgram,normalGetLocation=p.getUniformLocation,spatialUse=p.useProgram;
    const pairs=new WeakMap(),locations=new WeakMap(),physical=new WeakMap();
    const methods=['uniform1f','uniform1i','uniform1ui','uniform2f','uniform2i','uniform2ui','uniform3f','uniform3i','uniform3ui','uniform4f','uniform4i','uniform4ui','uniform1fv','uniform2fv','uniform3fv','uniform4fv','uniform1iv','uniform2iv','uniform3iv','uniform4iv','uniform1uiv','uniform2uiv','uniform3uiv','uniform4uiv','uniformMatrix2fv','uniformMatrix3fv','uniformMatrix4fv','uniformMatrix2x3fv','uniformMatrix2x4fv','uniformMatrix3x2fv','uniformMatrix3x4fv','uniformMatrix4x2fv','uniformMatrix4x3fv'];
    const nativeUniform=Object.fromEntries(methods.map(n=>[n,p[n]]));state.programs=[];
    p.linkProgram=function(program){
        normalLink.call(this,program);
        const shaders=attached.get(program)||[],fragment=shaders.find(s=>(shaderTexts.get(s)||'').includes('bool portalDeferredFragmentVisible() {')&&(shaderTexts.get(s)||'').includes('in float vTranslucency;'));
        if(!fragment)return;
        const text=shaderTexts.get(fragment),vertex=shaders.find(s=>this.getShaderParameter(s,this.SHADER_TYPE)===this.VERTEX_SHADER);
        let region=text.replace('bool portalDeferredFragmentVisible() {',`bool portalOriginalFragmentVisible() {`);
        region=region.replace('vec4 sampleMaterial()',`bool portalDeferredFragmentVisible(){
            if(uPortalRenderDomain==0u){
                vec2 p=gl_FragCoord.xy;
                if(p.x<459.0||p.y<480.0||p.x>=1122.0||p.y>=588.0)return true;
            }
            return portalOriginalFragmentVisible();
        }
        vec4 sampleMaterial()`);
        const bypass=text.replace('if (!portalDeferredFragmentVisible()) discard;','').replace(/struct PortalArrivalMetadata[\s\S]*?in vec2 vTextureCoordinate;/,'in vec2 vTextureCoordinate;');
        const variants=new Map([['normal',program]]),variantLocations=new Map([['normal',new Map()]]);
        for(const [label,source] of [['region',region],['no-portal',bypass]]){
            if(source.includes('uDiagnostic'))throw new Error('Clean fragment still has diagnostic uniforms');
            const shader=this.createShader(this.FRAGMENT_SHADER);shaderSource.call(this,shader,source);this.compileShader(shader);if(!this.getShaderParameter(shader,this.COMPILE_STATUS))throw new Error(this.getShaderInfoLog(shader));
            const alt=this.createProgram();attachShader.call(this,alt,vertex);attachShader.call(this,alt,shader);normalLink.call(this,alt);this.deleteShader(shader);if(!this.getProgramParameter(alt,this.LINK_STATUS))throw new Error(this.getProgramInfoLog(alt));
            const block=this.getUniformBlockIndex(alt,'PortalScopeAtlasMetadata');if(block!==this.INVALID_INDEX)this.uniformBlockBinding(alt,block,0);
            variants.set(label,alt);variantLocations.set(label,new Map());state.programs.push({label,bytes:source.length,portalBlock:block!==this.INVALID_INDEX,diagnosticUniforms:false});
        }
        pairs.set(program,{variants,variantLocations,values:new Map(),last:null});
    };
    const targetLocation=(gl,pair,label,name)=>{const cache=pair.variantLocations.get(label);if(!cache.has(name))cache.set(name,normalGetLocation.call(gl,pair.variants.get(label),name));return cache.get(name);};
    p.getUniformLocation=function(program,name){const location=normalGetLocation.call(this,program,name),pair=pairs.get(program);if(location&&pair)locations.set(location,{pair,name});return location;};
    p.useProgram=function(program){
        spatialUse.call(this,program);const pair=pairs.get(program);if(!pair){physical.delete(this);return;}
        const label=state.mode,target=pair.variants.get(label);if(!target)throw new Error('Unsupported clean program mode '+label);
        if(target!==program)useProgram.call(this,target);physical.set(this,{pair,label});
        if(pair.last!==label){for(const [name,v] of pair.values)nativeUniform[v.method].call(this,targetLocation(this,pair,label,name),...v.args);pair.last=label;}
    };
    for(const method of methods)p[method]=function(location,...args){
        const info=location&&locations.get(location);if(!info)return nativeUniform[method].call(this,location,...args);
        info.pair.values.set(info.name,{method,args:args.map(v=>ArrayBuffer.isView(v)?Array.from(v):v)});
        const active=physical.get(this),label=active?.pair===info.pair?active.label:'normal';
        return nativeUniform[method].call(this,targetLocation(this,info.pair,label,info.name),...args);
    };

}