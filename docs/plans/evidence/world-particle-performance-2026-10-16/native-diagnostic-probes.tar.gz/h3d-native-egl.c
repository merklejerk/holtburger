#define GL_GLEXT_PROTOTYPES
#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GL/gl.h>
#include <GL/glext.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void fail(const char *message){fprintf(stderr,"%s (EGL 0x%x)\n",message,eglGetError());exit(1);}
int main(void){
 EGLDisplay display=eglGetPlatformDisplay(EGL_PLATFORM_SURFACELESS_MESA,EGL_DEFAULT_DISPLAY,NULL);
 if(display==EGL_NO_DISPLAY||!eglInitialize(display,NULL,NULL))fail("Initialize EGL");
 if(!eglBindAPI(EGL_OPENGL_API))fail("Bind OpenGL");
 EGLint attrs[]={EGL_SURFACE_TYPE,EGL_PBUFFER_BIT,EGL_RENDERABLE_TYPE,EGL_OPENGL_BIT,EGL_RED_SIZE,8,EGL_GREEN_SIZE,8,EGL_BLUE_SIZE,8,EGL_NONE},count;
 EGLConfig config;if(!eglChooseConfig(display,attrs,&config,1,&count)||count!=1)fail("Choose EGL configuration");
 EGLint contextAttrs[]={EGL_CONTEXT_MAJOR_VERSION,4,EGL_CONTEXT_MINOR_VERSION,5,EGL_NONE};
 EGLContext context=eglCreateContext(display,config,EGL_NO_CONTEXT,contextAttrs);if(context==EGL_NO_CONTEXT)fail("Create context");
 EGLint surfaceAttrs[]={EGL_WIDTH,32,EGL_HEIGHT,32,EGL_NONE};EGLSurface surface=eglCreatePbufferSurface(display,config,surfaceAttrs);if(surface==EGL_NO_SURFACE)fail("Create pbuffer");
 if(!eglMakeCurrent(display,surface,surface,context))fail("Make current");
 printf("renderer=%s\nversion=%s\n",glGetString(GL_RENDERER),glGetString(GL_VERSION));
 GLint extensions;glGetIntegerv(GL_NUM_EXTENSIONS,&extensions);
 for(GLint i=0;i<extensions;i++){const char *name=(const char*)glGetStringi(GL_EXTENSIONS,i);if(strstr(name,"query")||strstr(name,"performance")||strstr(name,"debug"))printf("extension=%s\n",name);}
 glClearColor(0,0,0,1);glClear(GL_COLOR_BUFFER_BIT);glFinish();eglSwapBuffers(display,surface);
 eglMakeCurrent(display,EGL_NO_SURFACE,EGL_NO_SURFACE,EGL_NO_CONTEXT);eglDestroySurface(display,surface);eglDestroyContext(display,context);eglTerminate(display);return 0;
}
