#define _GNU_SOURCE
#include <dlfcn.h>
#include <GL/gl.h>
#include <GL/glext.h>
#include <EGL/egl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
static void *(*real_lookup)(void *,const char *);
static void *(*raw_proc)(const char *);
static __thread int active;
static __thread GLuint queries[3],target_draws,all_draws,captured_program;
static __thread long long last_token;
static void *lookup(const char *name){
 if(!real_lookup)real_lookup=dlvsym(RTLD_NEXT,"dlsym","GLIBC_2.2.5");
 return raw_proc?raw_proc(name):real_lookup(RTLD_NEXT,name);
}
static PFNGLGENQUERIESPROC gen_queries;
static PFNGLBEGINQUERYPROC begin_query;
static PFNGLENDQUERYPROC end_query;
static PFNGLGETQUERYOBJECTUI64VPROC get_result;
static PFNGLDELETEQUERIESPROC delete_queries;
static PFNGLGETUNIFORMLOCATIONPROC uniform_location;
static PFNGLGETUNIFORMIVPROC uniform_value;
static void (*get_integer)(GLenum,GLint*);
static GLenum (*get_error)(void);
static void initialize(void){
 if(gen_queries)return;
 gen_queries=lookup("glGenQueries");begin_query=lookup("glBeginQuery");end_query=lookup("glEndQuery");get_result=lookup("glGetQueryObjectui64v");delete_queries=lookup("glDeleteQueries");uniform_location=lookup("glGetUniformLocation");uniform_value=lookup("glGetUniformiv");get_integer=lookup("glGetIntegerv");get_error=lookup("glGetError");
 if(!gen_queries||!begin_query||!end_query||!get_result||!delete_queries||!uniform_location||!uniform_value||!get_integer||!get_error){fprintf(stderr,"H3D_QUERY_MISSING_ENTRYPOINT\n");abort();}
}
static void finish(const char *reason){
 if(!active)return;
 active=0;
 end_query(GL_FRAGMENT_SHADER_INVOCATIONS_ARB);end_query(GL_VERTEX_SHADER_INVOCATIONS_ARB);end_query(GL_SAMPLES_PASSED);
 GLuint64 values[3];for(int i=0;i<3;i++)get_result(queries[i],GL_QUERY_RESULT,&values[i]);delete_queries(3,queries);
 GLenum error=get_error();const char *path=getenv("H3D_NATIVE_QUERY_LOG");if(!path)path="/tmp/h3d-native-query-results.jsonl";
 FILE *out=fopen(path,"a");if(!out)abort();
 fprintf(out,"{\"token\":%lld,\"pid\":%d,\"program\":%u,\"dominantDraws\":%u,\"allDraws\":%u,\"fragmentInvocations\":%llu,\"vertexInvocations\":%llu,\"samplesPassed\":%llu,\"glError\":%u,\"reason\":\"%s\"}\n",last_token,getpid(),captured_program,target_draws,all_draws,(unsigned long long)values[0],(unsigned long long)values[1],(unsigned long long)values[2],error,reason);fclose(out);
}
static void enter(GLsizei count){
 if(active){all_draws++;if(count==330)target_draws++;return;}
 if(count!=330)return;
 // Poll only eligible geometry. The trigger is written once per requested counter capture.
 const char *path=getenv("H3D_NATIVE_QUERY_TRIGGER");if(!path)path="/tmp/h3d-native-query-trigger";
 FILE *trigger=fopen(path,"r");if(!trigger)return;long long token=0;int read=fscanf(trigger,"%lld",&token);fclose(trigger);if(read!=1||token==last_token)return;
 initialize();GLint program=0;get_integer(GL_CURRENT_PROGRAM,&program);
 if(program==0||uniform_location((GLuint)program,"_uuParticleRecords")<0)return;
 GLenum before=get_error();if(before!=GL_NO_ERROR){fprintf(stderr,"H3D_QUERY_PREEXISTING_GL_ERROR %u\n",before);abort();}
 last_token=token;captured_program=(GLuint)program;target_draws=1;all_draws=1;
 gen_queries(3,queries);begin_query(GL_FRAGMENT_SHADER_INVOCATIONS_ARB,queries[0]);begin_query(GL_VERTEX_SHADER_INVOCATIONS_ARB,queries[1]);begin_query(GL_SAMPLES_PASSED,queries[2]);active=1;
}
static void probe_elements(GLenum mode,GLsizei count,GLenum type,const void *indices){
 static void(*real)(GLenum,GLsizei,GLenum,const void*);if(!real)real=lookup("glDrawElements");enter(count);real(mode,count,type,indices);
}
static void probe_instanced(GLenum mode,GLsizei count,GLenum type,const void *indices,GLsizei instances){
 static void(*real)(GLenum,GLsizei,GLenum,const void*,GLsizei);if(!real)real=lookup("glDrawElementsInstanced");enter(count);real(mode,count,type,indices,instances);
}
static void probe_base(GLenum mode,GLsizei count,GLenum type,const void *indices,GLint base){
 static void(*real)(GLenum,GLsizei,GLenum,const void*,GLint);if(!real)real=lookup("glDrawElementsBaseVertex");enter(count);real(mode,count,type,indices,base);
}
static void probe_instanced_base(GLenum mode,GLsizei count,GLenum type,const void *indices,GLsizei instances,GLint base){
 static void(*real)(GLenum,GLsizei,GLenum,const void*,GLsizei,GLint);if(!real)real=lookup("glDrawElementsInstancedBaseVertex");enter(count);real(mode,count,type,indices,instances,base);
}
static void probe_use(GLuint program){
 static void(*real)(GLuint);if(!real)real=lookup("glUseProgram");if(active&&program!=captured_program)finish("program-switch");real(program);
}
static void *substitute(const char *name,void *address){
 if(!address)return address;
 if(!strcmp(name,"glDrawElements"))return probe_elements;
 if(!strcmp(name,"glDrawElementsInstanced"))return probe_instanced;
 if(!strcmp(name,"glDrawElementsBaseVertex"))return probe_base;
 if(!strcmp(name,"glDrawElementsInstancedBaseVertex"))return probe_instanced_base;
 if(!strcmp(name,"glUseProgram"))return probe_use;
 // eglMakeCurrent is deliberately not interposed: ANGLE may load a private EGL library.
 return address;
}
static void *probe_proc(const char *name){return substitute(name,raw_proc(name));}
void *dlsym(void *handle,const char *name){
 if(!real_lookup)real_lookup=dlvsym(RTLD_NEXT,"dlsym","GLIBC_2.2.5");
 void *address=real_lookup(handle,name);
 Dl_info origin;
 if(address && dladdr(address,&origin) && origin.dli_fname && strstr(origin.dli_fname,"node_modules/electron"))return address;
 if(address&&(!strcmp(name,"eglGetProcAddress")||!strcmp(name,"glXGetProcAddress")||!strcmp(name,"glXGetProcAddressARB"))){raw_proc=(void *(*)(const char*))address;return probe_proc;}
 return substitute(name,address);
}
