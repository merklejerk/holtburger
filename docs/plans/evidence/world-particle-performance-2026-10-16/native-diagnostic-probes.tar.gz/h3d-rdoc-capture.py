import json
import os
import time
import traceback
from pathlib import Path
import renderdoc as rd
mode=os.environ['H3D_CAPTURE_MODE']
expected_pid=int(os.environ['H3D_CAPTURE_PID'])
report={'mode':mode,'targets':[]}
try:
    ident=0
    chosen=None
    while True:
        ident=rd.EnumerateRemoteTargets('localhost',ident)
        if ident==0:break
        control=rd.CreateTargetControl('localhost',ident,'H3D investigation',False)
        if control is None:continue
        info={'ident':ident,'pid':control.GetPID(),'target':control.GetTarget(),'api':control.GetAPI()}
        report['targets'].append(info)
        if info['pid']==expected_pid:
            chosen=control
            break
        control.Shutdown()
    if chosen is None:raise RuntimeError('No OpenGL capture target')
    report['selectedPid']=chosen.GetPID()
    capture_started=time.time()
    chosen.TriggerCapture(1)
    deadline=time.time()+25
    report['messages']=[]
    while time.time()<deadline:
        msg=chosen.ReceiveMessage(None)
        if msg.type!=rd.TargetControlMessageType.Noop:report['messages'].append(str(msg.type))
        if msg.type==rd.TargetControlMessageType.NewCapture:
            cap=msg.newCapture
            if cap.timestamp<int(capture_started):continue
            report['capture']={'path':cap.path,'frame':cap.frameNumber,'bytes':cap.byteSize,'api':cap.api,'local':cap.local}
            break
        if msg.type==rd.TargetControlMessageType.Disconnected:raise RuntimeError('Capture target disconnected')
    chosen.Shutdown()
    if 'capture' not in report:raise RuntimeError('No frame capture before deadline')
    report['ok']=True
except BaseException:
    report['ok']=False
    report['error']=traceback.format_exc()
finally:
    Path('/tmp/h3d-rdoc-'+mode+'-capture.json').write_text(json.dumps(report,indent=2))
    os._exit(0)
