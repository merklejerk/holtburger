import hashlib
import json
import os
import traceback
from pathlib import Path
import renderdoc as rd
mode=os.environ['H3D_CAPTURE_MODE']
report={'mode':mode,'backend':'X11 / in-process GPU / Mesa desktop OpenGL 4.6; capture replay, not original GLES timing'}
cap=None
controller=None
try:
    metadata=json.loads(Path('/tmp/h3d-rdoc-'+mode+'-capture.json').read_text())
    filename=os.environ.get('H3D_CAPTURE_FILE',metadata['capture']['path']);report['captureFile']=Path(filename).name;cap=rd.OpenCaptureFile();result=cap.OpenFile(filename,'',None)
    if not result.OK():raise RuntimeError(str(result))
    result,controller=cap.OpenCapture(rd.ReplayOptions(),None)
    if not result.OK():raise RuntimeError(str(result))
    available=list(controller.EnumerateCounters())
    wanted=[rd.GPUCounter.EventGPUDuration,rd.GPUCounter.PSInvocations,rd.GPUCounter.VSInvocations,rd.GPUCounter.SamplesPassed]
    report['counters']=[{'id':int(c),'name':controller.DescribeCounter(c).name,'description':controller.DescribeCounter(c).description} for c in available]
    if any(c not in available for c in wanted):raise RuntimeError('Required pipeline counters unavailable')
    results={}
    for value in controller.FetchCounters(wanted):
        name=controller.DescribeCounter(value.counter).name
        results.setdefault(value.eventId,{})[name]=value.value.d if value.counter==rd.GPUCounter.EventGPUDuration else value.value.u64
    def flatten(actions):
        for action in actions:
            yield action
            yield from flatten(action.children)
    all_actions=list(flatten(controller.GetRootActions()));rows=[];candidates=[]
    for action in all_actions:
        if action.numIndices!=330:continue
        controller.SetFrameEvent(action.eventId,False)
        pipeline=controller.GetPipelineState();vertex=pipeline.GetShaderReflection(rd.ShaderStage.Vertex)
        if vertex is None:continue
        source='\n'.join(f.contents for f in vertex.debugInfo.files)
        resources=[r.name for r in vertex.readOnlyResources]
        particle='ParticleRecords' in source or any('ParticleRecords' in r for r in resources)
        candidates.append({'eventId':action.eventId,'instances':action.numInstances,'particle':particle,'vertexResources':resources})
        if not particle:continue
        fragment=pipeline.GetShaderReflection(rd.ShaderStage.Fragment)
        fs='\n'.join(f.contents for f in fragment.debugInfo.files) if fragment else ''
        rows.append({'eventId':action.eventId,'numIndices':action.numIndices,'instances':action.numInstances,'counters':results.get(action.eventId,{}),'fragmentSourceSha256':hashlib.sha256(fs.encode()).hexdigest(),'fragmentHasPortal':('PortalEnvelope' in fs),'fragmentHasFixedRectangle':('459.0' in fs)})
    report['actionCount']=len(all_actions);report['candidate330Draws']=candidates;report['dominantDraws']=rows
    report['totals']={name:sum(row['counters'].get(name,0) for row in rows) for name in rows[0]['counters']} if rows else {}
    if len(rows)!=206:raise RuntimeError('Capture does not contain exactly 206 dominant particle draws: '+str(len(rows)))
    report['ok']=True
except BaseException:
    report['ok']=False;report['error']=traceback.format_exc()
finally:
    Path('/tmp/h3d-rdoc-'+mode+'-counters.json').write_text(json.dumps(report,indent=2))
    if controller:controller.Shutdown()
    if cap:cap.Shutdown()
    os._exit(0)
