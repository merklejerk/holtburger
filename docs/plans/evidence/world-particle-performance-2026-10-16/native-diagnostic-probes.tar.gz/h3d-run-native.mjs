import { readFileSync } from 'node:fs';
import { parseEnv } from 'node:util';
import { spawn } from 'node:child_process';
const secrets=parseEnv(readFileSync('/home/me/code/holtburger/apps/holtburger-3d/.dev.env','utf8'));
const label=process.argv[2];
const child=spawn(process.execPath,[process.env.H3D_PROBE_SCRIPT ?? '/tmp/h3d-profile-probe.mjs'],{env:{...process.env,HOLTBURGER_PROBE_ACCOUNT:secrets.ACCOUNT,HOLTBURGER_PROBE_PASSWORD:secrets.PASSWORD,HOLTBURGER_PROBE_MODE:'profile',HOLTBURGER_PROBE_PROFILE_INSTRUMENTATION:process.argv[3]??'1',HOLTBURGER_PROBE_REPORT:`/tmp/h3d-${label}.json`,HOLTBURGER_PROBE_CPU_PROFILE:`/tmp/h3d-${label}.cpuprofile`,HOLTBURGER_PROBE_TIMEOUT_MS:'180000'},stdio:'inherit'});
child.on('exit',code=>process.exit(code??1));
