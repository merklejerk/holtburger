from pathlib import Path
import difflib,gzip,hashlib,io,json,statistics,tarfile
root=Path('/home/me/code/holtburger');base=root/'docs/plans/evidence/world-particle-performance-2026-10-16'
m=json.loads((base/'manifest.json').read_text());removed=set(m['sanitization']['removedKeys'])
def packed(v):return(json.dumps(v,indent=2)+'\n').encode()
def digest(v):return hashlib.sha256(v).hexdigest()
def clean(v):
 if isinstance(v,list):return[clean(x)for x in v]
 if isinstance(v,dict):
  out={k:clean(x)for k,x in v.items()if k not in removed}
  if 'consoleMessages'in out:out['consoleMessages']=[{'level':x['level'],'count':x.get('count',1)}for x in v['consoleMessages']]
  return out
 return v
def stats(v):return{'median':statistics.median(v),'min':min(v),'max':max(v)}
def add(name,data,kind,sources):
 (base/name).write_bytes(data);m['files']=[f for f in m['files']if f['path']!=name]+[{'path':name,'bytes':len(data),'sha256':digest(data),'kind':kind,'sources':sources}]
original=Path('/tmp/h3d-particle-cutover-original');baseline=json.loads((original/'baseline.json').read_text());paths=baseline['files']
patch=''.join(''.join(difflib.unified_diff((original/p).read_text().splitlines(keepends=True),(root/p).read_text().splitlines(keepends=True),fromfile='a/'+p,tofile='b/'+p))for p in paths)
Path('/tmp/h3d-particle-cutover-change.patch').write_text(patch)
r=clean(json.loads(Path('/tmp/h3d-particle-cutover-native.json').read_text()));assert len(r['trials'])==5
log=[json.loads(line)for line in Path('/tmp/h3d-particle-cutover-native.log').read_text().splitlines()if line.startswith('{')]
assert any(x.get('ok')is True and x.get('windows')==5 for x in log)and log[-1]=={'cleanup':'disconnected'}
r['cleanup']={'profilingDisabled':True,'clientDisconnected':True};r['verificationExitCode']=0
fixtures={}
for name,field in [('portal','portalScopeAtlasExecutor'),('selection','entitySelection')]:
 raw=json.loads(Path('/tmp/h3d-particle-cutover-'+name+'-report.json').read_text());f=raw['initialState'][field]
 fixtures[name]={'fixture':raw['fixture'],'command':'npm run harness:browser -- --fixture '+raw['fixture']+' --gpu --full-report','exitCode':0,'ready':raw['ready'],'glRenderer':raw['glRenderer'],'error':raw['initialState']['error'],'result':{k:v for k,v in f.items()if k!='appearancePreview'},'consoleMessages':[{'level':x['level'],'count':x.get('count',1)}for x in raw['consoleMessages']]}
sourcePaths=set(paths)|set(json.loads((base/'position-ab-summary.json').read_text())['productionSourceHashes'])
sourceHashes={p:digest((root/p).read_bytes())for p in sorted(sourcePaths)}
lineChanges={}
for p in paths:
 diff=list(difflib.ndiff((original/p).read_text().splitlines(),(root/p).read_text().splitlines()));a=sum(x.startswith('+ ')for x in diff);d=sum(x.startswith('- ')for x in diff);lineChanges[p]={'added':a,'deleted':d,'net':a-d}
getters={'frameWorkMs':lambda t:t['snapshot']['meanFrameWorkMs'],'particleGpuMs':lambda t:t['snapshot']['diagnostics']['renderer']['profile']['gpu']['mean']['particleMs'],'gpuMs':lambda t:t['snapshot']['diagnostics']['renderer']['profile']['gpu']['mean']['totalMs'],'observedFps':lambda t:t['snapshot']['sampledFrameCount']*1000/t['windowMs']}
timings={k:stats([fn(t)for t in r['trials']])for k,fn in getters.items()}
checks=[('Focused TypeScript tests: 10 files, 92 tests','h3d-particle-cutover-tests.log'),('npm run check','h3d-particle-cutover-check.log'),('npm run lint:ts','h3d-particle-cutover-lint.log'),('npm run lint:dead','h3d-particle-cutover-dead.log'),('npm run build','h3d-particle-cutover-build.log')]
s={'date':'2026-10-16','status':'User-authorized permanent ordinary-particle shader cutover implemented; uncommitted. Temporary bypass and portal-particle variant removed.','baselineHead':baseline['head'],'baseline':'Exact pre-cutover working-tree snapshots include prior CPU improvements and concurrent user commits. Incremental patch excludes those earlier changes.','policy':{'ownerAdmission':'Existing CPU source/scope admission retained.','drawing':'Existing scope-group order, sky schedule, mesh/motion/material/alpha/blend rules, one record sync and ordinary opaque depth retained.','removed':'Particle portal shader, boolean shader factory, routing uniforms/keys, temporary bypass switch and mode guards. Other geometry retains its portal checks.','concession':'Admitted large particles can extend across scope boundaries where opaque depth does not hide them. User reported earlier manual view looked fine and explicitly chose adoption. No universal output-equivalence or retail-bug claim.','referenceModels':'Finite-screen CPU models retain fully clipped particle semantics as strict reference/cost models; they do not define this production concession.'},'productionSourceHashes':sourceHashes,'preCutoverSourceHashes':{p:digest((original/p).read_bytes())for p in paths},'ordinaryFragmentTemplateProof':json.loads(Path('/tmp/h3d-particle-cutover-template-proof.json').read_text()),'incrementalLineChanges':lineChanges,'verification':[{'command':command,'exitCode':0,'logSha256':digest((Path('/tmp')/filename).read_bytes())}for command,filename in checks],'native':{'context':r['context'],'windows':5,'timing':timings,'cleanup':r['cleanup'],'method':'Normal production frontend and release native host. Startup-only GL shader/draw/depth observer restored before five four-second renderer-profile windows after ten-second settling. No movement, V8 sampling, pixel readback, builds or heavy analysis during timing. Graphics preferences unchanged.','limits':'Functional smoke and current-session context, not a matched before/after comparison. Earlier paired shader-selection evidence supplies the measured 0.744 ms particle GPU saving; live scene drift and refresh cap still apply.'},'gpuFixtures':{k:{'fixture':v['fixture'],'exitCode':v['exitCode'],'glRenderer':v['glRenderer']}for k,v in fixtures.items()},'qualityReview':{'boundary':'Final particle cutover diff against exact pre-cutover snapshots; prior CPU implementations retained.','seams':['ParticleRenderBatcher CPU owner admission through renderer drawWorld and pass flattening','Sky/world schedule and shared record-store upload lifetime','Program creation/material uniforms, device-state handoff, destroy/recreate','Production fragment shader through independent GPU depth/blend oracle and canonical harness','CPU reference models and durable/investigation docs'],'result':'No blocking correctness/design finding. Keep scope grouping because source-order flattening could reorder alpha layers. Retain strict CPU oracle models for their separate purpose. No replacement abstraction or new stateful policy.'},'limits':['No new agent visual acceptance. User owns visual observation across additional locations.','No claim of guaranteed FPS improvement or unchanged particle portal visibility.','Historical artifacts and source/build hashes remain unchanged; historical validators require their own matching source state.']}
add('particle-cutover-native.json.gz',gzip.compress(packed(r),mtime=0),'sanitized five-window native ordinary-production smoke and startup shader/depth verification',['h3d-particle-cutover-native.json'])
add('particle-cutover-gpu-fixtures.json.gz',gzip.compress(packed(fixtures),mtime=0),'numeric canonical portal and selection hardware GPU results; no preview images',['h3d-particle-cutover-portal.log','h3d-particle-cutover-selection.log'])
add('particle-cutover-change.patch',patch.encode(),'incremental clean cutover relative to exact temporary-bypass state',paths)
add('particle-cutover-summary.json',packed(s),'permanent cutover policy, proof, verification, smoke context and code-quality review',['particle-cutover-native.json.gz','particle-cutover-gpu-fixtures.json.gz','particle-cutover-change.patch'])
files=['h3d-particle-cutover-native-probe.mjs','h3d-preserve-particle-cutover.py','h3d-validate-particle-cutover.py','h3d-particle-cutover-template-proof.json']+[filename for command,filename in checks]
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w')as archive:
 entries=[(name,(Path('/tmp')/name).read_bytes())for name in files]+[('original/baseline.json',(original/'baseline.json').read_bytes())]+[('original/'+p,(original/p).read_bytes())for p in paths]
 for name,data in entries:
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
add('particle-cutover-probes.tar.gz',gzip.compress(buf.getvalue(),mtime=0),'native smoke source, evidence tools/check logs and exact pre-cutover snapshots under original/',files+paths)
m['scope']='GPU/CPU investigation, three CPU improvements and user-authorized permanent ordinary-particle shader cutover. Historical shader/source/build evidence remains unchanged.'
m['particleCutover']={'summary':'particle-cutover-summary.json','baselineHead':baseline['head'],'nativeWindows':5,'gpuFixtures':['portal-scope-atlas','entity-selection'],'permanent':True,'historicalBypassSuperseded':True}
(base/'manifest.json').write_bytes(packed(m));print(json.dumps({'artifacts':len(m['files']),'bytes':sum(f['bytes']for f in m['files']),'nativeTimings':timings,'shaderCheck':r['context']['shaderCheck']}))
