from pathlib import Path,PurePosixPath
import difflib,gzip,hashlib,json,statistics,tarfile
root=Path.cwd();base=root/'docs/plans/evidence/world-particle-performance-2026-10-16';m=json.loads((base/'manifest.json').read_text())
def digest(data):return hashlib.sha256(data).hexdigest()
assert len({f['path']for f in m['files']})==len(m['files'])
for f in m['files']:
 data=(base/f['path']).read_bytes();assert len(data)==f['bytes']and digest(data)==f['sha256'],f['path']
s=json.loads((base/'particle-cutover-summary.json').read_text());r=json.loads(gzip.decompress((base/'particle-cutover-native.json.gz').read_bytes()));g=json.loads(gzip.decompress((base/'particle-cutover-gpu-fixtures.json.gz').read_bytes()))
for path,expected in s['productionSourceHashes'].items():assert digest((root/path).read_bytes())==expected,path
c=r['context']['shaderCheck'];assert c['hooksRestored']and c['unrestrictedDraws']>0 and all(c[k]==0 for k in['portalAwareDraws','depthInputDraws','depthDisabledDraws','depthWritingDraws'])
assert not r['context']['diagnosticGlobalsPresent']and r['verificationExitCode']==0 and r['cleanup']=={'profilingDisabled':True,'clientDisconnected':True}
assert len(r['trials'])==5 and sorted(t['round']for t in r['trials'])==list(range(5))
for t in r['trials']:assert t['windowMs']>=4000 and t['snapshot']['sampledFrameCount']>0
for key,read in [('frameWorkMs',lambda t:t['snapshot']['meanFrameWorkMs']),('particleGpuMs',lambda t:t['snapshot']['diagnostics']['renderer']['profile']['gpu']['mean']['particleMs']),('gpuMs',lambda t:t['snapshot']['diagnostics']['renderer']['profile']['gpu']['mean']['totalMs'])]:assert statistics.median([read(t)for t in r['trials']])==s['native']['timing'][key]['median']
assert all(x['level']not in['error','exception']for x in r['consoleMessages'])
for name,f in g.items():
 assert f['ready']and f['error']is None and f['exitCode']==0
 assert 'SwiftShader'not in f['glRenderer']and'Radeon 780M'in f['glRenderer']
 assert all(value for value in f['result'].values()if isinstance(value,bool))
 assert all(x['level']not in['error','exception']for x in f['consoleMessages'])
assert g['portal']['result']['particleDepthCompositionMatchesOracle']and g['portal']['result']['deferredCompositionMatchesOracle']
actual=g['portal']['result']['particlePixels'];expected=g['portal']['result']['expectedParticlePixels'];assert len(actual)==len(expected)>0 and all(abs(a-b)<=2 for i,(a,b)in enumerate(zip(actual,expected))if i%4!=3)
removed=set(m['sanitization']['removedKeys'])
def sanitized(v):
 if isinstance(v,list):
  for x in v:sanitized(x)
 if isinstance(v,dict):
  assert not removed.intersection(v)
  if 'consoleMessages'in v:assert all(set(x)<={'level','count'}for x in v['consoleMessages'])
  assert 'appearancePreview'not in v
  for x in v.values():sanitized(x)
for value in[s,r,g]:sanitized(value)
with tarfile.open(base/'particle-cutover-probes.tar.gz')as archive:
 for entry in archive.getmembers():
  p=PurePosixPath(entry.name);assert entry.isfile()and not p.is_absolute()and'..'not in p.parts
  assert len(p.parts)==1 or p.parts[0]=='original'
 original={p:archive.extractfile('original/'+p).read()for p in s['preCutoverSourceHashes']}
 for p,data in original.items():assert digest(data)==s['preCutoverSourceHashes'][p],p
 baseline=json.loads(archive.extractfile('original/baseline.json').read());assert baseline['head']==s['baselineHead']and set(baseline['files'])==set(original)
 # JSON sorting does not impose the baseline patch order: recreate its explicit path order.
 patch=''.join(''.join(difflib.unified_diff(original[p].decode().splitlines(keepends=True),(root/p).read_text().splitlines(keepends=True),fromfile='a/'+p,tofile='b/'+p))for p in baseline['files'])
 assert patch==(base/'particle-cutover-change.patch').read_text()
 program='apps/holtburger-3d/src/lib/game/renderer/webgl2-particle-program.ts';before=original[program].decode();after=(root/program).read_text()
 fragment=before.split('return `#version 300 es',1)[1].split('`;',1)[0];fragment='#version 300 es'+fragment
 fragment=fragment.replace('${portalDeclarations}','').replace('${portalApplication}','')
 current=after.split('export const PARTICLE_FRAGMENT_SHADER = `',1)[1].split('`;',1)[0]
 normalize=lambda text:''.join(text.split())
 assert normalize(fragment)==normalize(current)
 assert digest(normalize(current).encode())==s['ordinaryFragmentTemplateProof']['normalizedTemplateSha256']
 for entry in archive.getmembers():
  if entry.name.endswith('.py'):compile(archive.extractfile(entry).read(),entry.name,'exec')
for path in['webgl2-particle-pass.ts','webgl2-particle-program.ts','webgl2-renderer.ts']:
 text=(root/'apps/holtburger-3d/src/lib/game/renderer'/path).read_text()
 for token in['BYPASS_PARTICLE_PORTAL_VISIBILITY_FOR_MANUAL_REVIEW','ParticlePortalScopeRouting','createParticleFragmentShader','#drawScopedParticles','#scopedRenderScopeKeys']:assert token not in text,(path,token)
assert all(check['exitCode']==0 for check in s['verification'])
print(json.dumps({'ok':True,'artifacts':len(m['files']),'nativeWindows':5,'gpuFixtures':len(g),'observedOrdinaryParticleDraws':c['unrestrictedDraws'],'templateEqual':True,'historicalArtifactHashesIntact':True}))
