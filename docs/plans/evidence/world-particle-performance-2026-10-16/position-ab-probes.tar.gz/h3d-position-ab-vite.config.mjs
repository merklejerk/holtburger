import base from '/home/me/code/holtburger/apps/holtburger-3d/vite.config.ts';
export default {...base,build:{...base.build,outDir:'/tmp/h3d-position-ab-dist',emptyOutDir:true},plugins:[{name:'h3d-diagnostic-particle-portal-switch',enforce:'pre',transform(code,id){
 if(!id.endsWith('/src/lib/game/renderer/webgl2-renderer.ts'))return;
 const needle='BYPASS_PARTICLE_PORTAL_VISIBILITY_FOR_MANUAL_REVIEW\n\t\t\t\t\t? null';
 if(code.split(needle).length!==2)throw Error('Unexpected manual particle switch');
 return {code:code.replace(needle,'globalThis.__h3dParticlePortalBypass\n\t\t\t\t\t? null'),map:null};
}},...base.plugins]};
