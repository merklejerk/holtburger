from pathlib import Path
import gzip,hashlib,io,json,statistics,tarfile
root=Path('/home/me/code/holtburger');base=root/'docs/plans/evidence/world-particle-performance-2026-10-16';m=json.loads((base/'manifest.json').read_text());removed=set(m['sanitization']['removedKeys'])
def clean(v):
 if isinstance(v,list):return[clean(x)for x in v]
 if isinstance(v,dict):
  out={k:clean(x)for k,x in v.items()if k not in removed}
  if 'consoleMessages'in out:out['consoleMessages']=[{'level':x['level'],'count':x.get('count',1)}for x in v['consoleMessages']]
  return out
 return v
def packed(v):return(json.dumps(v,indent=2)+'\n').encode()
def digest(v):return hashlib.sha256(v).hexdigest()
def stats(v):return{'median':statistics.median(v),'min':min(v),'max':max(v)}
def add(name,data,kind,sources):
 (base/name).write_bytes(data);m['files']=[f for f in m['files']if f['path']!=name]+[{'path':name,'bytes':len(data),'sha256':digest(data),'kind':kind,'sources':sources}]
r=clean(json.loads(Path('/tmp/h3d-position-ab.json').read_text()));assert len(r['trials'])==10 and r['context']['locationObserverRestored']and all(r['cleanup'].values())
sel=lambda t:t['snapshot']['diagnostics']['renderer']['selectionMetrics']
getters={'frameWorkMs':lambda t:t['snapshot']['meanFrameWorkMs'],'rendererCpuMs':lambda t:t['snapshot']['diagnostics']['renderer']['profile']['cpu']['mean']['totalMs'],'particleSubmissionCpuMs':lambda t:t['snapshot']['diagnostics']['renderer']['profile']['cpu']['mean']['particleSubmissionMs'],'particleGpuMs':lambda t:t['snapshot']['diagnostics']['renderer']['profile']['gpu']['mean']['particleMs'],'gpuMs':lambda t:t['snapshot']['diagnostics']['renderer']['profile']['gpu']['mean']['totalMs'],'observedFps':lambda t:t['snapshot']['sampledFrameCount']*1000/t['windowMs'],'visibleDynamicEntities':lambda t:sel(t)['visibleDynamicEntityCount'],'particleBatches':lambda t:sel(t)['submittedParticleBatchCount'],'particleInstances':lambda t:sel(t)['submittedParticleInstanceCount'],'selectedCrossings':lambda t:sel(t)['portalSelectedCrossingCount'],'selectedScopes':lambda t:sel(t)['portalSelectedScopeCount']}
timing={('bypass'if bypass else'portal'):{k:stats([fn(t)for t in r['trials']if t['bypass']==bypass])for k,fn in getters.items()}for bypass in[False,True]};paired={}
for k,fn in getters.items():
 values=[fn(next(t for t in r['trials']if t['round']==i and not t['bypass']))-fn(next(t for t in r['trials']if t['round']==i and t['bypass']))for i in range(5)];paired[k]={**stats(values),'positiveRounds':sum(v>0 for v in values)}
sourcePaths=set(json.loads((base/'followup-summary.json').read_text())['productionSourceHashes'])|{'apps/holtburger-3d/src/lib/game/renderer/webgl2-particle-pass.ts'}
sourceHashes={p:digest((root/p).read_bytes())for p in sorted(sourcePaths)}
assets={p.name:digest(p.read_bytes())for p in Path('/tmp/h3d-position-ab-dist/assets').glob('*.js')}
s={'date':'2026-10-16','status':'Five paired current-position shader-selection trials completed. User-authorized temporary production bypass remains enabled; no further production edit.','context':r['context'],'productionSourceHashes':sourceHashes,'diagnosticJsAssets':assets,'method':{'build':'Ordinary production Vite config plus a disposable pre-transform replacing only the manual particle switch use with a per-frame diagnostic global. Output/launcher isolated under /tmp. Baseline supplies normal routing; bypass supplies null and selects the existing ordinary particle program. Both preserve earlier CPU fixes and the same current source.','sampling':'Five matched pairs; portal then bypass on even rounds, reverse on odd rounds. Each variant settles 1.5s then measures 4s. Both shader programs are warmed before timing.','camera':'Capture both particle programs and view/projection locations during warmup. Remove the uniform-location observer before timing. Query current mode matrices after each window, requiring exact equality to warmup view/projection. Host camera-path position also retained per window. Uniform queries are outside measurement windows.','overhead':'Only common diagnostic shader-selection global plus renderer phase profiling during measurement. No prototype draw/uniform forwarding hooks, V8 sampling, pixel readback, build or heavy analysis overlaps timing. GPU fields remain rolling phase snapshots, not full-window hardware utilization.','scene':'Same camera and quality, live server. Other actors and particle counts can change; full population ranges and within-pair differences retained.','cleanup':r['cleanup']},'warmup':r['warmup'],'timing':timing,'pairedPortalMinusBypass':paired,'limits':['Output equivalence is intentionally not asserted: global particle portal clipping is disabled at user request. Prior user report found no apparent issue in their earlier manual view, not every possible location.','Position and orientation differ from earlier captures; compare causal timing within this run only.','Near-refresh-cap FPS and overlapping CPU/GPU work limit interpretation; do not sum phase savings or promise equivalent gains in other scenes.','No agent visual acceptance or new permanent visibility policy implemented.']}
add('position-ab-trials.json.gz',gzip.compress(packed(r),mtime=0),'sanitized five paired current-position portal-on/bypass windows and matrices',['h3d-position-ab.json'])
add('position-ab-summary.json',packed(s),'paired shader-selection timing, fixed-camera proof, workload ranges and build provenance',['position-ab-trials.json.gz'])
files=['h3d-position-ab-vite.config.mjs','h3d-position-ab-launch.mjs','h3d-position-ab-probe.mjs','h3d-preserve-position-ab.py','h3d-validate-position-ab.py'];buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w')as archive:
 for name in files:
  data=(Path('/tmp')/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
add('position-ab-probes.tar.gz',gzip.compress(buf.getvalue(),mtime=0),'disposable current-position paired build transform, launcher, probe and evidence tools',files)
m['positionPairedBypass']={'summary':'position-ab-summary.json','pairedRounds':5,'windows':10,'cameraMatricesEqual':True,'productionSourceModified':False}
(base/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'artifacts':len(m['files']),'bytes':sum(f['bytes']for f in m['files']),'timing':timing,'paired':paired}))
