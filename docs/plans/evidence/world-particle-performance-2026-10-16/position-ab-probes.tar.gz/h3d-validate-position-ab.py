from pathlib import Path
import gzip,hashlib,json,statistics,tarfile
root=Path.cwd();base=root/'docs/plans/evidence/world-particle-performance-2026-10-16';m=json.loads((base/'manifest.json').read_text())
for f in m['files']:
 b=(base/f['path']).read_bytes();assert len(b)==f['bytes']and hashlib.sha256(b).hexdigest()==f['sha256'],f['path']
r=json.loads(gzip.decompress((base/'position-ab-trials.json.gz').read_bytes()));s=json.loads((base/'position-ab-summary.json').read_text())
assert len(r['trials'])==10 and r['context']['locationObserverRestored']and r['cleanup']=={'bypassRestored':True,'observerRestored':True,'profilingDisabled':True}
a,b=r['warmup']['bypassCamera'],r['warmup']['portalCamera'];assert a['view']==b['view']and a['projection']==b['projection']and len(a['view'])==len(a['projection'])==16
for mode in[False,True]:
 ts=[t for t in r['trials']if t['bypass']==mode];assert sorted(t['round']for t in ts)==list(range(5))
 for t in ts:
  assert t['windowMs']>=4000 and t['snapshot']['sampledFrameCount']>0
  assert t['matrices']['portal']==(not mode)and t['matrices']['view']==a['view']and t['matrices']['projection']==a['projection']
  assert t['camera']['position']==r['context']['camera']['position']
 key='bypass'if mode else'portal'
 assert statistics.median([t['snapshot']['diagnostics']['renderer']['profile']['gpu']['mean']['particleMs']for t in ts])==s['timing'][key]['particleGpuMs']['median']
for path,digest in s['productionSourceHashes'].items():assert hashlib.sha256((root/path).read_bytes()).hexdigest()==digest,path
removed=set(m['sanitization']['removedKeys'])
def clean(v):
 if isinstance(v,list):
  for x in v:clean(x)
 if isinstance(v,dict):
  assert not removed.intersection(v)
  if 'consoleMessages'in v:assert all(set(x)<={'level','count'}for x in v['consoleMessages'])
  for x in v.values():clean(x)
clean(r);clean(s)
with tarfile.open(base/'position-ab-probes.tar.gz')as archive:
 for member in archive.getmembers():assert member.isfile()and member.name==Path(member.name).name
print(json.dumps({'ok':True,'artifacts':len(m['files']),'pairedRounds':5,'windows':10,'cameraMatricesEqual':True,'bypassRestored':True}))
