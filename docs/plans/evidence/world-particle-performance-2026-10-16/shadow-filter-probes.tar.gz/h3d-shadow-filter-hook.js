() => {
 if(!globalThis.__h3dShadowBaselineLoop)throw new Error('Original-loop diagnostic build missing');
 const c=globalThis.__h3dShadowClasses;
 if(!c?.RenderWorld||!c?.SceneGraph||!c?.WebGL2OutdoorPssmPass||!c?.ParticleSystem||!c?.Mat4||!c?.isEntityShadowCasterClass)throw new Error('Diagnostic production class references missing');
 const state=window.__shadowFilterAudit={mode:'candidate',shadow:false,counting:false,counts:null,proofRemaining:0,proofs:[],owners:new Set(),collectOwners:true};
 state.reset=()=>state.counts={preparations:0,queries:0,returnedRoots:0,returnedDominantOwners:0,descriptors:0,nonCasterDescriptors:0,dominantDescriptors:0,shadowMatrixClones:0};state.reset();
 const query=c.SceneGraph.prototype.queryScopesFrustum,descriptor=c.RenderWorld.prototype.getRenderContributionDescriptor,prepare=c.WebGL2OutdoorPssmPass.prototype.prepare;
 const collect=c.ParticleSystem.prototype.collectDrawRanges,clone=c.Mat4.prototype.clone;
 c.ParticleSystem.prototype.collectDrawRanges=function(){const ranges=collect.apply(this,arguments);if(state.collectOwners){state.owners.clear();for(const r of ranges)if(r.hwGfxObjId==='0x01003fa7')state.owners.add(r.renderOwner);}return ranges;};
 c.Mat4.prototype.clone=function(){if(state.counting&&state.shadow)state.counts.shadowMatrixClones++;return clone.apply(this,arguments);};
 c.SceneGraph.prototype.queryScopesFrustum=function(frustum,anchor,scopes,groupFilter,nodeFilter){
  const result=query.call(this,frustum,anchor,scopes,groupFilter,state.shadow&&state.mode==='baseline'?null:nodeFilter);
  if(state.counting&&state.shadow){state.counts.queries++;state.counts.returnedRoots+=result.entries.length;for(const id of result.entries)if(state.owners.has(id))state.counts.returnedDominantOwners++;}
  return result;
 };
 c.RenderWorld.prototype.getRenderContributionDescriptor=function(id){
  const result=descriptor.apply(this,arguments);
  if(state.counting&&state.shadow){state.counts.descriptors++;if(state.owners.has(id))state.counts.dominantDescriptors++;if(result?.kind==='dynamic'&&!c.isEntityShadowCasterClass(result.entityClass))state.counts.nonCasterDescriptors++;}
  // Recreate the original post-descriptor rejection only in the disposable baseline mode.
  return state.shadow&&state.mode==='baseline'&&result?.kind==='dynamic'&&!c.isEntityShadowCasterClass(result.entityClass)?null:result;
 };
 function signature(result,input){
  if(result===null)return null;
  return {
   cascades:result.storage.cascades,
   casters:result.storage.batches.map(b=>b.casters.map(d=>({nodeId:d.nodeId,landblockId:d.landblockId,geometry:d.geometry,renderScopes:d.renderScopes,ranges:d.ranges,parts:d.parts,selectedPartCount:d.selectedPartCount,selectedTriangleCount:d.selectedTriangleCount}))),
   analytic:result.storage.analyticCasters,
   candidates:result.storage.casterSelectionScratch.candidates,
   selected:[...input.selectedDynamicNodeIds],
  };
 }
 const hash=s=>{let n=2166136261;for(let i=0;i<s.length;i++)n=Math.imul(n^s.charCodeAt(i),16777619);return (n>>>0).toString(16).padStart(8,'0');};
 c.WebGL2OutdoorPssmPass.prototype.prepare=function(input,metrics){
  const previous=state.shadow;state.shadow=true;
  try{
   if(state.proofRemaining===0){if(state.counting)state.counts.preparations++;return prepare.apply(this,arguments);}
   const mode=state.mode,selected=[...input.selectedDynamicNodeIds];
   state.mode='baseline';const a=prepare.call(this,input,null);const first=JSON.stringify(signature(a,input));
   input.selectedDynamicNodeIds.clear();for(const id of selected)input.selectedDynamicNodeIds.add(id);
   state.mode='candidate';const b=prepare.call(this,input,metrics);const second=JSON.stringify(signature(b,input));
   state.mode=mode;if(first!==second)throw new Error('Same-frame shadow input/selection mismatch');
   state.proofs.push({equal:true,signatureHash:hash(first),signatureCharacters:first.length,candidates:b?.storage.casterSelectionScratch.candidates.length??0,mappedRoots:b?.storage.batches.map(x=>x.casters.length)??[],analyticRoots:b?.storage.analyticCasters.length??0,dominantOwners:state.owners.size});state.proofRemaining--;return b;
  }finally{state.shadow=previous;}
 };
 state.finishCounters=()=>{state.counting=false;state.collectOwners=false;c.ParticleSystem.prototype.collectDrawRanges=collect;c.Mat4.prototype.clone=clone;};
 state.restore=()=>{c.SceneGraph.prototype.queryScopesFrustum=query;c.RenderWorld.prototype.getRenderContributionDescriptor=descriptor;c.WebGL2OutdoorPssmPass.prototype.prepare=prepare;c.ParticleSystem.prototype.collectDrawRanges=collect;c.Mat4.prototype.clone=clone;};
}
