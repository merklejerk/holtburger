import {createRequire} from 'node:module';
const ts=createRequire('/home/me/code/holtburger/apps/holtburger-3d/package.json')('typescript');
import base from '/home/me/code/holtburger/apps/holtburger-3d/vite.config.ts';
// Diagnostic build only: retain class references for paired prototype interception over CDP.
const baselineSelectionTs = "\t#selectEntriesBaseline(\n\t\tfrustum: Frustum,\n\t\tanchorLandblockId: ScenePlacement[\"landblockId\"],\n\t\tcullingGroupFilter: SceneCullingGroupFilter,\n\t): void {\n\t\tthis.#visibleEntries.length = 0;\n\t\tthis.#visibleEntryIds.clear();\n\t\tfor (const scope of this.#selectedScopeKeys) {\n\t\t\tconst landblockGroups = this.#cullingGroups.get(scope);\n\t\t\tif (!landblockGroups) continue;\n\t\t\tfor (const groups of landblockGroups.values()) {\n\t\t\t\tfor (const [cullingGroup, group] of groups) {\n\t\t\t\t\tif (!cullingGroupFilter(cullingGroup)) continue;\n\t\t\t\t\tconst bounds = this.#resolveCullingGroupBounds(group);\n\t\t\t\t\tif (\n\t\t\t\t\t\t!bounds ||\n\t\t\t\t\t\t!this.#frustumIntersectsLandblockBounds(\n\t\t\t\t\t\t\tfrustum,\n\t\t\t\t\t\t\tanchorLandblockId,\n\t\t\t\t\t\t\tgroup.landblockId,\n\t\t\t\t\t\t\tbounds,\n\t\t\t\t\t\t)\n\t\t\t\t\t)\n\t\t\t\t\t\tcontinue;\n\t\t\t\t\tfor (const nodeId of group.entries) {\n\t\t\t\t\t\tconst entry = this.#spatialEntries.get(nodeId);\n\t\t\t\t\t\tif (\n\t\t\t\t\t\t\tentry &&\n\t\t\t\t\t\t\t!this.#visibleEntryIds.has(nodeId) &&\n\t\t\t\t\t\t\tthis.#frustumIntersectsEntry(frustum, anchorLandblockId, entry)\n\t\t\t\t\t\t) {\n\t\t\t\t\t\t\tthis.#visibleEntryIds.add(nodeId);\n\t\t\t\t\t\t\tthis.#visibleEntries.push(nodeId);\n\t\t\t\t\t\t}\n\t\t\t\t\t}\n\t\t\t\t}\n\t\t\t}\n\t\t}\n\t}\n";
const baselineWrapper=ts.transpileModule('class Baseline {\n'+baselineSelectionTs+'\n}',{compilerOptions:{target:ts.ScriptTarget.ESNext}}).outputText;
const baselineSelection=baselineWrapper.slice(baselineWrapper.indexOf('{')+1,baselineWrapper.lastIndexOf('}'));
const references = new Map([
 ['/src/lib/game/scene/scene-graph.ts','SceneGraph'],
 ['/src/lib/game/renderer/render-world.ts','RenderWorld'],
 ['/src/lib/game/renderer/webgl2-outdoor-pssm-pass.ts','WebGL2OutdoorPssmPass'],
 ['/src/lib/game/systems/particle-system.ts','ParticleSystem'],
 ['/src/lib/game/math/types.ts','Mat4'],
 ['/src/lib/game/renderer/entity-shadow-policy.ts','isEntityShadowCasterClass'],
]);
export default {
 ...base,
 plugins:[...base.plugins,{name:'h3d-shadow-filter-profiling',transform(code,id){
  if(id.endsWith('/src/lib/game/scene/scene-graph.ts')){
   const start=code.indexOf('\t#selectEntries('),end=code.indexOf('\n\t/**',start);if(start<0||end<0)throw new Error('Scene query shape changed');
   const current=code.slice(start,end);const marker=/\)\s*\{/;if(!marker.test(current))throw new Error('Missing selection body');
   const diagnostic=current.replace(marker,(opening)=>opening+`\n if(globalThis.__shadowFilterAudit?.mode==='baseline' && nodeFilter===null)return this.#selectEntriesBaseline(frustum,anchorLandblockId,cullingGroupFilter);`);
   code=code.slice(0,start)+baselineSelection+'\n'+diagnostic+code.slice(end)+'\nglobalThis.__h3dShadowBaselineLoop=true;\n';
  }
  for(const [suffix,name] of references)if(id.endsWith(suffix))return {code:code+`\nglobalThis.__h3dShadowClasses ??= {};globalThis.__h3dShadowClasses.${name}=${name};\n`,map:null};
 }}],
 build:{...base.build,outDir:'/tmp/h3d-shadow-filter-dist',emptyOutDir:true},
};
