"""Validate retained shadow-filter evidence from the repository root; no live server needed."""
from pathlib import Path
import gzip
import hashlib
import json
import statistics
import tarfile

root = Path.cwd()
base = root / 'docs/plans/evidence/world-particle-performance-2026-10-16'
manifest = json.loads((base / 'manifest.json').read_text())
for entry in manifest['files']:
    data = (base / entry['path']).read_bytes()
    assert len(data) == entry['bytes'], entry['path']
    assert hashlib.sha256(data).hexdigest() == entry['sha256'], entry['path']

def read(label):
    return json.loads(gzip.decompress((base / f'shadow-filter-{label}.json.gz').read_bytes()))

paired = read('paired')
assert len(paired['proofs']) == 30
assert all(p['equal'] and p['dominantOwners'] == 206 for p in paired['proofs'])
assert len(paired['trials']) == 20
assert paired['context']['savedShadowMode'] == 'shadow-maps'
for setting in ['shadow-maps', 'none']:
    for mode in ['baseline', 'candidate']:
        trials = [t for t in paired['trials'] if t['shadowMode'] == setting and t['mode'] == mode]
        assert sorted(t['round'] for t in trials) == list(range(5))
        assert all(t['windowMs'] >= 5000 and t['snapshot']['sampledFrameCount'] > 0 for t in trials)
        if setting == 'none':
            assert all(t['snapshot']['diagnostics']['renderer']['profile']['cpu']['mean']['outdoorShadowMapMs'] == 0 for t in trials)
baseline, candidate = paired['audits']
assert baseline['mode'] == 'baseline' and candidate['mode'] == 'candidate'
for audit in [baseline, candidate]:
    assert audit['dominantOwners'] == 206
    assert audit['counts']['queries'] == 2 * audit['counts']['preparations']
assert baseline['counts']['returnedDominantOwners'] == 412 * baseline['counts']['preparations']
assert baseline['counts']['dominantDescriptors'] == 206 * baseline['counts']['preparations']
for key in ['returnedDominantOwners', 'dominantDescriptors', 'nonCasterDescriptors']:
    assert candidate['counts'][key] == 0, key
assert baseline['counts']['shadowMatrixClones'] == baseline['counts']['descriptors']
assert candidate['counts']['shadowMatrixClones'] == candidate['counts']['descriptors']
summary = json.loads((base / 'shadow-filter-summary.json').read_text())
for source, digest in summary['productionFiles'].items():
    data = (root / source).read_bytes()
    assert hashlib.sha256(data).hexdigest() == digest, source
    assert not any(marker in data for marker in [b'__h3dShadow', b'__shadowFilterAudit', b'selectEntriesBaseline', b'queryScopesScene']), source
for setting in ['shadow-maps', 'none']:
    for mode in ['baseline', 'candidate']:
        measured = [t['snapshot']['diagnostics']['renderer']['profile']['cpu']['mean']['outdoorShadowMapMs'] for t in paired['trials'] if t['shadowMode'] == setting and t['mode'] == mode]
        assert summary['timing'][setting][mode]['shadowCpuMs']['median'] == statistics.median(measured)
production = read('production')
assert len(production['trials']) == 5
assert production['context']['diagnosticGlobalsPresent'] is False
assert production['context']['graphics']['entityShadowMode'] == 'shadow-maps'
assert 'OpenGL' in production['context']['renderer']
fixture = read('gpu-fixture')
assert fixture['exitCode'] == 0
assert 'Vulkan' in fixture['glRenderer']
gpu = fixture['outdoorPssm']
for field in ['casterProgramLinked', 'groundingProgramsLinked', 'receiverProgramsLinked', 'initialLayersComplete', 'initialResourcesValid', 'resizedLayersComplete', 'resizedResourcesValid', 'resizedTargetReplaced', 'sameConfigurationReused']:
    assert gpu[field] is True, field
assert gpu['posedDepthPixels'] == {'before': 0, 'vacated': 255, 'moved': 0}
assert gpu['initialDiagnostics']['activeBytes'] == 262144
assert gpu['resizedDiagnostics']['activeBytes'] == 2097152
assert gpu['disposedDiagnostics']['activeBytes'] == 0
assert gpu['disposedDiagnostics']['allocatedGenerationCount'] == gpu['disposedDiagnostics']['disposedGenerationCount'] == 2

removed = set(manifest['sanitization']['removedKeys'])
def sanitized(value):
    if isinstance(value, list):
        for item in value: sanitized(item)
    if isinstance(value, dict):
        assert not removed.intersection(value), removed.intersection(value)
        if 'consoleMessages' in value:
            assert all(set(row) <= {'level', 'count'} for row in value['consoleMessages'])
        for item in value.values(): sanitized(item)
for value in [paired, production, fixture, read('pilot'), summary]:
    sanitized(value)
with tarfile.open(base / 'shadow-filter-probes.tar.gz') as archive:
    sources = {}
    for member in archive.getmembers():
        assert member.name == Path(member.name).name
        assert member.isfile()
        sources[member.name] = archive.extractfile(member).read()
        assert sources[member.name]
    original = sources['h3d-shadow-filter-original-scene-graph.ts']
    assert hashlib.sha256(original).hexdigest() == summary['baselineSceneSourceSha256']
    original = original.decode()
    start = original.index('\t#selectEntries(')
    end = original.index('\n\t/**', start)
    expected = original[start:end].replace('#selectEntries(', '#selectEntriesBaseline(', 1)
    config = sources['h3d-shadow-filter-vite.config.mjs'].decode()
    embedded = json.JSONDecoder().raw_decode(config.split('const baselineSelectionTs = ', 1)[1])[0]
    assert embedded == expected, 'Diagnostic baseline must contain the original selection loop'
print(json.dumps({'ok': True, 'hashedArtifacts': len(manifest['files']), 'sameFrameProofs': 30, 'pairedWindows': 20, 'productionWindows': 5, 'productionSourceFiles': len(summary['productionFiles'])}))
