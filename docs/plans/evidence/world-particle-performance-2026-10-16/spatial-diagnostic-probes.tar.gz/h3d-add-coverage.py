from pathlib import Path
import json
hook=Path('/tmp/h3d-spatial-hook.js').read_text()
# Add a numeric counter to the actual world-particle shader, inactive during timing.
hook=hook.replace('uniform vec4 uDiagnosticAffected;', 'uniform vec4 uDiagnosticAffected;\\nuniform int uDiagnosticLayerCounter;')
old="return text.replace('if (!portalDeferredFragmentVisible()) discard;','if (!portalDiagnosticFragmentVisible()) discard;');"
new="""text=text.replace('void main() {',`void main() {
            if(uDiagnosticLayerCounter==1){
                bool original=portalOriginalFragmentVisible();
                vec2 pixel=gl_FragCoord.xy;
                bool outside=pixel.x<uDiagnosticAffected.x||pixel.y<uDiagnosticAffected.y||pixel.x>=uDiagnosticAffected.z||pixel.y>=uDiagnosticAffected.w;
                outColor=vec4(original?1.0:0.0,outside?1.0:0.0,1.0,(outside||original)!=original?1.0:0.0);return;
            }
        `);
        return text.replace('if (!portalDeferredFragmentVisible()) discard;','if (!portalDiagnosticFragmentVisible()) discard;');"""
assert old in hook;hook=hook.replace(old,new)
hook=hook.replace("ordinal:particle?this.getUniformLocation(program,'uPortalRenderDomain'):null", "ordinal:particle?this.getUniformLocation(program,'uPortalRenderDomain'):null,counter:particle?this.getUniformLocation(program,'uDiagnosticLayerCounter'):null")
old="return drawElements.apply(this,arguments);\n    };\n    state.inspectEnvelope"
new="""if(count===330 && f.counter && state.counterCapture){
            const gl=this,cap=state.counterCapture;
            if(!cap.framebuffer){
                if(!gl.getExtension('EXT_color_buffer_float')||!gl.getExtension('EXT_float_blend'))throw new Error('Float overlap counter unavailable');
                const savedTexture=gl.getParameter(gl.TEXTURE_BINDING_2D),savedFbo=gl.getParameter(gl.DRAW_FRAMEBUFFER_BINDING);
                const color=gl.createTexture(),framebuffer=gl.createFramebuffer(),width=gl.drawingBufferWidth,height=gl.drawingBufferHeight;
                const type=gl.getFramebufferAttachmentParameter(gl.DRAW_FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE),depth=gl.getFramebufferAttachmentParameter(gl.DRAW_FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.FRAMEBUFFER_ATTACHMENT_OBJECT_NAME);
                gl.bindTexture(gl.TEXTURE_2D,color);gl.texStorage2D(gl.TEXTURE_2D,1,gl.RGBA32F,width,height);gl.bindTexture(gl.TEXTURE_2D,savedTexture);
                gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,framebuffer);gl.framebufferTexture2D(gl.DRAW_FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,color,0);
                if(type===gl.TEXTURE)gl.framebufferTexture2D(gl.DRAW_FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.TEXTURE_2D,depth,0);
                else if(type===gl.RENDERBUFFER)gl.framebufferRenderbuffer(gl.DRAW_FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.RENDERBUFFER,depth);
                else throw new Error('Missing shared opaque depth');
                if(gl.checkFramebufferStatus(gl.DRAW_FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw new Error('Counter target incomplete');
                const clipped=gl.isEnabled(gl.SCISSOR_TEST);gl.disable(gl.SCISSOR_TEST);gl.clearBufferfv(gl.COLOR,0,new Float32Array(4));if(clipped)gl.enable(gl.SCISSOR_TEST);
                gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,savedFbo);Object.assign(cap,{framebuffer,color,width,height,draws:0});
            }
            const saved={fbo:gl.getParameter(gl.DRAW_FRAMEBUFFER_BINDING),blend:gl.isEnabled(gl.BLEND),src:gl.getParameter(gl.BLEND_SRC_RGB),dst:gl.getParameter(gl.BLEND_DST_RGB),srcA:gl.getParameter(gl.BLEND_SRC_ALPHA),dstA:gl.getParameter(gl.BLEND_DST_ALPHA),eq:gl.getParameter(gl.BLEND_EQUATION_RGB),eqA:gl.getParameter(gl.BLEND_EQUATION_ALPHA)};
            gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,cap.framebuffer);gl.enable(gl.BLEND);gl.blendEquation(gl.FUNC_ADD);gl.blendFunc(gl.ONE,gl.ONE);gl.uniform1i(f.counter,1);
            drawElements.apply(this,arguments);cap.draws++;
            gl.uniform1i(f.counter,0);gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,saved.fbo);gl.blendEquationSeparate(saved.eq,saved.eqA);gl.blendFuncSeparate(saved.src,saved.dst,saved.srcA,saved.dstA);if(!saved.blend)gl.disable(gl.BLEND);
            return;
        }
        return drawElements.apply(this,arguments);
    };
    state.finishLayers=()=>{
        const gl=state.gl,cap=state.counterCapture;state.counterCapture=null;if(!cap?.framebuffer)throw new Error('No overlap frame');
        const read=gl.getParameter(gl.READ_FRAMEBUFFER_BINDING);gl.bindFramebuffer(gl.READ_FRAMEBUFFER,cap.framebuffer);gl.readBuffer(gl.COLOR_ATTACHMENT0);const pixels=new Float32Array(cap.width*cap.height*4);gl.readPixels(0,0,cap.width,cap.height,gl.RGBA,gl.FLOAT,pixels);const error=gl.getError();gl.bindFramebuffer(gl.READ_FRAMEBUFFER,read);gl.deleteFramebuffer(cap.framebuffer);gl.deleteTexture(cap.color);if(error!==gl.NO_ERROR)throw new Error('Overlap GL error '+error);
        const sums=[0,0,0,0];for(let i=0;i<pixels.length;i++)sums[i%4]+=pixels[i];return {draws:cap.draws,bounds:state.bounds,visibleLayers:sums[0],outsideLayers:sums[1],totalLayers:sums[2],visibilityMismatches:sums[3]};
    };
    state.inspectEnvelope"""
assert old in hook;hook=hook.replace(old,new)
hook=hook.rstrip()[:-1]+Path('/tmp/h3d-split-hook-extension.js').read_text()+'\n}'
Path('/tmp/h3d-split-hook.js').write_text(hook)
source=Path('/tmp/h3d-spatial-probe.mjs').read_text();start=source.index(' await evaluate(client, "() => {');end=source.index('\n\tawait waitFor(',start)
source=source[:start]+' await evaluate(client, '+json.dumps(hook)+');'+source[end:]
source=source.replace("['no-portal','region','normal']:['normal','region','no-portal']", "['no-portal','split','region','normal']:['normal','region','split','no-portal']")
source=source.replace("window.__spatialAudit.counts={draws:0,instances:0};", "window.__spatialAudit.counts={draws:0,instances:0};window.__spatialAudit.physicalDraws=0;")
source=source.replace('firstDraw:window.__spatialAudit.firstDraw})','firstDraw:window.__spatialAudit.firstDraw,physicalDraws:window.__spatialAudit.physicalDraws,splitPrograms:window.__spatialAudit.splitPrograms})')
source=source.replace('/tmp/h3d-spatial-costs.json','/tmp/h3d-split-costs.json')
needle="        printReport({ok:true,reportPath:'/tmp/h3d-split-costs.json'});"
replacement="""        const layers=[];
        for(let trial=0;trial<3;trial++){
            const counts=await evaluate(client, `async () => {const state=window.__spatialAudit;state.mode='normal';state.counterCapture={};await new Promise(resolve=>requestAnimationFrame(resolve));return state.finishLayers();}`);
            if(counts.visibilityMismatches!==0)throw new Error('Actual particle visibility mismatch');layers.push(counts);printReport({counter:counts});
        }
        await writeFile('/tmp/h3d-split-costs.json',stringifyRedactedProbeReport({trials,proofs,layers,consoleMessages:[...consoleMessages.values()]},{account,password}));
        printReport({ok:true,reportPath:'/tmp/h3d-split-costs.json'});"""
assert needle in source;source=source.replace(needle,replacement)
Path('/tmp/h3d-split-probe.mjs').write_text(source)
