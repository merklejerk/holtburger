#!/usr/bin/env node

import { spawn } from "node:child_process";
import { writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { resolve } from "node:path";

import { runClientStreamingProbe } from "file:///home/me/code/holtburger/apps/holtburger-3d/scripts/client-streaming-probe.mjs";
import { createCdpClient } from "file:///home/me/code/holtburger/apps/holtburger-3d/scripts/cdp-client.mjs";
import { stringifyRedactedProbeReport } from "file:///home/me/code/holtburger/apps/holtburger-3d/scripts/live-client-probe-report.mjs";

const PASSIVE_CAMERA_SETTLE_MS = 5_000;
const PASSIVE_CAMERA_INPUT_COUNT = 40;
const PASSIVE_CAMERA_INPUT_INTERVAL_MS = 25;
const PRECISE_JUMP_SWEEP_INPUT_COUNT = 120;
const PRECISE_JUMP_SWEEP_INPUT_INTERVAL_MS = 5;
const PROFILE_SETTLE_MS = 10_000;
const PROFILE_WINDOW_MS = 10_000;
const WORLD_READY_NOTICE = "World ready";

const appRoot = '/home/me/code/holtburger/apps/holtburger-3d';
const account = requiredEnvironment("HOLTBURGER_PROBE_ACCOUNT");
const password = requiredEnvironment("HOLTBURGER_PROBE_PASSWORD");
const mode = probeMode(process.env.HOLTBURGER_PROBE_MODE);
const performanceInstrumentationEnabled =
	process.env.HOLTBURGER_PROBE_PROFILE_INSTRUMENTATION !== "0";
if (
	mode !== "teleport" &&
	process.env.HOLTBURGER_PROBE_TELEPORT_SEQUENCE !== undefined
) {
	throw new Error(`${mode} mode rejects HOLTBURGER_PROBE_TELEPORT_SEQUENCE.`);
}
let commands =
	mode === "teleport" && process.env.HOLTBURGER_PROBE_TELEPORT_SEQUENCE
		? parseCommands(process.env.HOLTBURGER_PROBE_TELEPORT_SEQUENCE)
		: null;
const timeoutMs = Number(process.env.HOLTBURGER_PROBE_TIMEOUT_MS ?? "45000");

if (!Number.isSafeInteger(timeoutMs) || timeoutMs <= 0) {
	throw new Error("HOLTBURGER_PROBE_TIMEOUT_MS must be a positive integer.");
}
// Resolve streaming configuration before launching or moving a live character.
const streamingOptions =
	mode === "streaming"
		? {
				startCommand:
					process.env.HOLTBURGER_STREAMING_START ?? "@tele 33.17s 72.85e",
				startLandblock:
					process.env.HOLTBURGER_STREAMING_START_LANDBLOCK ?? "0xda55ffff",
				destination:
					process.env.HOLTBURGER_STREAMING_DESTINATION ?? "0xda56ffff",
				trials: Number(process.env.HOLTBURGER_STREAMING_TRIALS ?? "1"),
				settleMs: 10000,
				moveMs: 2000,
				drainMs: 4000,
				timeoutMs,
				profile: performanceInstrumentationEnabled,
				outputPrefix: requiredEnvironment("HOLTBURGER_STREAMING_OUTPUT"),
				reportPath: requiredEnvironment("HOLTBURGER_PROBE_REPORT"),
			}
		: null;
if (
	streamingOptions !== null &&
	(!Number.isSafeInteger(streamingOptions.trials) ||
		streamingOptions.trials < 1)
) {
	throw new Error(
		"HOLTBURGER_STREAMING_TRIALS must be a positive safe integer.",
	);
}
const child = spawn(process.execPath, ["/tmp/h3d-production-launch.mjs", "client", "--release", "--vite-port", "0", "--account", account, "--password", password, `--debug=${performanceInstrumentationEnabled}`], { cwd: appRoot, env: {...process.env, HOLTBURGER_ELECTRON_REMOTE_DEBUGGING_PORT: "0"}, stdio: ["ignore", "pipe", "pipe"] });

let output = "";
for (const stream of [child.stdout, child.stderr]) {
	stream.on("data", (chunk) => {
		output += chunk.toString("utf8");
	});
}

let client;
const consoleMessages = new Map();
const hops = [];
try {
	const browserWebSocketUrl = await waitForDevToolsUrl(child, () => output);
	printReport({ stage: "devtools-endpoint" });
 const browserClient = await createCdpClient(browserWebSocketUrl);
 const gpuInfo = await browserClient.send("SystemInfo.getInfo");
 await writeFile("/tmp/h3d-gpu-info.json", JSON.stringify(gpuInfo));
 browserClient.close();
	const pageWebSocketUrl = await waitForPageWebSocketUrl(browserWebSocketUrl);
	printReport({ stage: "client-page-endpoint" });
	client = await createCdpClient(pageWebSocketUrl);
	client.on("Runtime.consoleAPICalled", (message) => {
		recordConsoleMessage({
			level: message.type,
			text: message.args
				.map((argument) => argument.value ?? argument.description ?? "")
				.join(" "),
		});
	});
	client.on("Runtime.exceptionThrown", (message) => {
		recordConsoleMessage({
			level: "exception",
			text:
				message.exceptionDetails.exception?.description ??
				message.exceptionDetails.text,
		});
	});
	await client.send("Runtime.enable");
	await installEvidenceCollector(client);
 await evaluate(client, "() => {\n    const p=WebGL2RenderingContext.prototype;\n    const shaderSource=p.shaderSource, attachShader=p.attachShader, useProgram=p.useProgram;\n    const bindBuffer=p.bindBuffer, bindBufferBase=p.bindBufferBase, bufferSubData=p.bufferSubData;\n    const drawArrays=p.drawArrays, drawElements=p.drawElementsInstanced;\n    const programs=new WeakMap(), attached=new WeakMap(), shaderTexts=new WeakMap(), facts=new WeakMap();\n    const buffers=new WeakMap(), bindings=new Map();\n    const state=window.__spatialAudit={mode:'normal',frames:0,counts:{draws:0,instances:0},bounds:null,firstDraw:null,proofs:[]};\n    const inject=(text)=>{\n        if(!text.includes('in float vTranslucency;') || !text.includes('bool portalDeferredFragmentVisible() {'))return text;\n        text=text.replace('precision highp int;','precision highp int;\\nuniform int uDiagnosticSpatialMode;\\nuniform vec4 uDiagnosticAffected;\\nuniform int uDiagnosticLayerCounter;');\n        text=text.replace('bool portalDeferredFragmentVisible() {','bool portalOriginalFragmentVisible() {');\n        const helper=`\n        bool portalDiagnosticFragmentVisible() {\n            if (uDiagnosticSpatialMode == 2) return true;\n            if (uDiagnosticSpatialMode == 1) {\n                if(uPortalRenderDomain != 0u)return portalOriginalFragmentVisible();\n                vec2 pixel = gl_FragCoord.xy;\n                if (pixel.x < uDiagnosticAffected.x || pixel.y < uDiagnosticAffected.y\n                    || pixel.x >= uDiagnosticAffected.z || pixel.y >= uDiagnosticAffected.w) return true;\n            }\n            return portalOriginalFragmentVisible();\n        }\n        `;\n        text=text.replace('vec4 sampleMaterial()',helper+'\\nvec4 sampleMaterial()');\n        text=text.replace('void main() {',`void main() {\n            if(uDiagnosticLayerCounter==1){\n                bool original=portalOriginalFragmentVisible();\n                vec2 pixel=gl_FragCoord.xy;\n                bool outside=pixel.x<uDiagnosticAffected.x||pixel.y<uDiagnosticAffected.y||pixel.x>=uDiagnosticAffected.z||pixel.y>=uDiagnosticAffected.w;\n                outColor=vec4(original?1.0:0.0,outside?1.0:0.0,1.0,(outside||original)!=original?1.0:0.0);return;\n            }\n        `);\n        return text.replace('if (!portalDeferredFragmentVisible()) discard;','if (!portalDiagnosticFragmentVisible()) discard;');\n    };\n    p.shaderSource=function(shader,text){text=inject(text);shaderTexts.set(shader,text);return shaderSource.call(this,shader,text);};\n    p.attachShader=function(program,shader){let list=attached.get(program);if(!list){list=[];attached.set(program,list);}list.push(shader);return attachShader.call(this,program,shader);};\n    p.useProgram=function(program){\n        programs.set(this,program);\n        if(program && !facts.has(program)){\n            const texts=(attached.get(program)||[]).map(s=>shaderTexts.get(s)||'');\n            const root=texts.some(t=>t.includes('uint current = 1u;')&&t.includes('flat in uint vOutputArrival;'));\n            const particle=this.getUniformLocation(program,'uParticleRecords')!==null;\n            facts.set(program,{root,particle,mode:particle?this.getUniformLocation(program,'uDiagnosticSpatialMode'):null,affected:particle?this.getUniformLocation(program,'uDiagnosticAffected'):null,ordinal:particle?this.getUniformLocation(program,'uPortalRenderDomain'):null,counter:particle?this.getUniformLocation(program,'uDiagnosticLayerCounter'):null});\n        }\n        return useProgram.call(this,program);\n    };\n    p.bindBuffer=function(target,buffer){bindings.set(target,buffer);return bindBuffer.call(this,target,buffer);};\n    let metadataBuffer=null;\n    p.bindBufferBase=function(target,index,buffer){if(target===this.UNIFORM_BUFFER&&index===0)metadataBuffer=buffer;return bindBufferBase.call(this,target,index,buffer);};\n    p.bufferSubData=function(target,dst,src,srcOffset=0,length){\n        if(dst===0 && ArrayBuffer.isView(src) && src.BYTES_PER_ELEMENT===1 && (target===this.ARRAY_BUFFER || target===this.UNIFORM_BUFFER)){\n            const bytes=length===undefined?src.byteLength-srcOffset:length;\n            buffers.set(bindings.get(target),new Uint8Array(src.buffer,src.byteOffset+srcOffset,bytes).slice());\n        }\n        return bufferSubData.apply(this,arguments);\n    };\n    p.drawArrays=function(mode,first,count){\n        const f=facts.get(programs.get(this));\n        if(f?.root){\n            const metadata=buffers.get(metadataBuffer);if(!metadata || metadata.byteLength!==16384)throw new Error('Missing mirrored portal metadata');\n            const buffer=this.getVertexAttrib(0,this.VERTEX_ATTRIB_ARRAY_BUFFER_BINDING),triangles=buffers.get(buffer);\n            if(!triangles || first!==0 || count%3!==0 || triangles.byteLength!==count*24)throw new Error('Crossing stream layout differs');\n            const matrix=new Float32Array(metadata.buffer,metadata.byteOffset,16),verts=new DataView(triangles.buffer,triangles.byteOffset,triangles.byteLength);\n            const width=this.drawingBufferWidth,height=this.drawingBufferHeight;\n            let left=width,bottom=height,right=0,top=0,rootTriangles=0,eyePlaneFallback=false;\n            const routes=new Set();\n            for(let i=0;i<count;i+=3){\n                const offset=i*24;if(verts.getUint32(offset+16,true)!==0)continue;\n                rootTriangles++;routes.add(verts.getUint32(offset+12,true));\n                for(let v=0;v<3;v++){\n                    const o=offset+v*24,x=verts.getFloat32(o,true),y=verts.getFloat32(o+4,true),z=verts.getFloat32(o+8,true);\n                    const w=matrix[3]*x+matrix[7]*y+matrix[11]*z+matrix[15];\n                    if(w<=0.00001){eyePlaneFallback=true;continue;}\n                    const px=((matrix[0]*x+matrix[4]*y+matrix[8]*z+matrix[12])/w+1)*width/2;\n                    const py=((matrix[1]*x+matrix[5]*y+matrix[9]*z+matrix[13])/w+1)*height/2;\n                    left=Math.min(left,px);right=Math.max(right,px);bottom=Math.min(bottom,py);top=Math.max(top,py);\n                }\n            }\n            const rect=eyePlaneFallback?[0,0,width,height]:rootTriangles?[Math.max(0,Math.floor(left)-3),Math.max(0,Math.floor(bottom)-3),Math.min(width,Math.ceil(right)+3),Math.min(height,Math.ceil(top)+3)]:[0,0,0,0];\n            const slots=new Uint32Array(metadata.buffer,metadata.byteOffset+8224,8);\n            if(slots[0]!==0||slots[1]!==0||slots[2]!==0||slots[3]!==0||slots[4]!==width||slots[5]!==height)throw new Error('Root mapping is not full viewport');\n            state.bounds={rect,rootTriangles,rootCrossings:routes.size,eyePlaneFallback,width,height,area:Math.max(0,rect[2]-rect[0])*Math.max(0,rect[3]-rect[1])};state.frames++;\n        }\n        return drawArrays.apply(this,arguments);\n    };\n    p.drawElementsInstanced=function(mode,count,type,offset,instances){\n        const f=facts.get(programs.get(this));if(!f?.particle)return drawElements.apply(this,arguments);\n        if(f.mode){\n            const dominant=count===330;\n            const value=dominant?(state.mode==='region'?1:state.mode==='no-portal'?2:0):0;\n            this.uniform1i(f.mode,value);\n            if(dominant){\n                if(!state.bounds)throw new Error('No root crossing bounds');\n                if(state.firstDraw===null){const ordinal=this.getUniform(programs.get(this),f.ordinal);if(ordinal!==0)throw new Error('Dominant mesh is not root-owned');state.firstDraw={ordinal,indexCount:count,instances};}\n                this.uniform4f(f.affected,...state.bounds.rect);state.counts.draws++;state.counts.instances+=instances;state.gl=this;\n            }\n        }\n        if(count===330 && f.counter && state.counterCapture){\n            const gl=this,cap=state.counterCapture;\n            if(!cap.framebuffer){\n                if(!gl.getExtension('EXT_color_buffer_float')||!gl.getExtension('EXT_float_blend'))throw new Error('Float overlap counter unavailable');\n                const savedTexture=gl.getParameter(gl.TEXTURE_BINDING_2D),savedFbo=gl.getParameter(gl.DRAW_FRAMEBUFFER_BINDING);\n                const color=gl.createTexture(),framebuffer=gl.createFramebuffer(),width=gl.drawingBufferWidth,height=gl.drawingBufferHeight;\n                const type=gl.getFramebufferAttachmentParameter(gl.DRAW_FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE),depth=gl.getFramebufferAttachmentParameter(gl.DRAW_FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.FRAMEBUFFER_ATTACHMENT_OBJECT_NAME);\n                gl.bindTexture(gl.TEXTURE_2D,color);gl.texStorage2D(gl.TEXTURE_2D,1,gl.RGBA32F,width,height);gl.bindTexture(gl.TEXTURE_2D,savedTexture);\n                gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,framebuffer);gl.framebufferTexture2D(gl.DRAW_FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,color,0);\n                if(type===gl.TEXTURE)gl.framebufferTexture2D(gl.DRAW_FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.TEXTURE_2D,depth,0);\n                else if(type===gl.RENDERBUFFER)gl.framebufferRenderbuffer(gl.DRAW_FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.RENDERBUFFER,depth);\n                else throw new Error('Missing shared opaque depth');\n                if(gl.checkFramebufferStatus(gl.DRAW_FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw new Error('Counter target incomplete');\n                const clipped=gl.isEnabled(gl.SCISSOR_TEST);gl.disable(gl.SCISSOR_TEST);gl.clearBufferfv(gl.COLOR,0,new Float32Array(4));if(clipped)gl.enable(gl.SCISSOR_TEST);\n                gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,savedFbo);Object.assign(cap,{framebuffer,color,width,height,draws:0});\n            }\n            const saved={fbo:gl.getParameter(gl.DRAW_FRAMEBUFFER_BINDING),blend:gl.isEnabled(gl.BLEND),src:gl.getParameter(gl.BLEND_SRC_RGB),dst:gl.getParameter(gl.BLEND_DST_RGB),srcA:gl.getParameter(gl.BLEND_SRC_ALPHA),dstA:gl.getParameter(gl.BLEND_DST_ALPHA),eq:gl.getParameter(gl.BLEND_EQUATION_RGB),eqA:gl.getParameter(gl.BLEND_EQUATION_ALPHA)};\n            gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,cap.framebuffer);gl.enable(gl.BLEND);gl.blendEquation(gl.FUNC_ADD);gl.blendFunc(gl.ONE,gl.ONE);gl.uniform1i(f.counter,1);\n            drawElements.apply(this,arguments);cap.draws++;\n            gl.uniform1i(f.counter,0);gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,saved.fbo);gl.blendEquationSeparate(saved.eq,saved.eqA);gl.blendFuncSeparate(saved.src,saved.dst,saved.srcA,saved.dstA);if(!saved.blend)gl.disable(gl.BLEND);\n            return;\n        }\n        return drawElements.apply(this,arguments);\n    };\n    state.finishLayers=()=>{\n        const gl=state.gl,cap=state.counterCapture;state.counterCapture=null;if(!cap?.framebuffer)throw new Error('No overlap frame');\n        const read=gl.getParameter(gl.READ_FRAMEBUFFER_BINDING);gl.bindFramebuffer(gl.READ_FRAMEBUFFER,cap.framebuffer);gl.readBuffer(gl.COLOR_ATTACHMENT0);const pixels=new Float32Array(cap.width*cap.height*4);gl.readPixels(0,0,cap.width,cap.height,gl.RGBA,gl.FLOAT,pixels);const error=gl.getError();gl.bindFramebuffer(gl.READ_FRAMEBUFFER,read);gl.deleteFramebuffer(cap.framebuffer);gl.deleteTexture(cap.color);if(error!==gl.NO_ERROR)throw new Error('Overlap GL error '+error);\n        const sums=[0,0,0,0];for(let i=0;i<pixels.length;i++)sums[i%4]+=pixels[i];return {draws:cap.draws,bounds:state.bounds,visibleLayers:sums[0],outsideLayers:sums[1],totalLayers:sums[2],visibilityMismatches:sums[3]};\n    };\n    state.inspectEnvelope=()=>{\n        const gl=state.gl;if(!gl || !state.bounds)throw new Error('Missing spatial draw state');\n        const rect=[...state.bounds.rect];\n        if(!gl.getExtension('EXT_color_buffer_float'))throw new Error('Float color target unavailable');\n        const saved={program:gl.getParameter(gl.CURRENT_PROGRAM),vao:gl.getParameter(gl.VERTEX_ARRAY_BINDING),draw:gl.getParameter(gl.DRAW_FRAMEBUFFER_BINDING),read:gl.getParameter(gl.READ_FRAMEBUFFER_BINDING),viewport:Array.from(gl.getParameter(gl.VIEWPORT)),texture:gl.getParameter(gl.TEXTURE_BINDING_2D)};\n        const capabilities=[gl.BLEND,gl.DEPTH_TEST,gl.SCISSOR_TEST,gl.CULL_FACE,gl.STENCIL_TEST].map(cap=>[cap,gl.isEnabled(cap)]);\n        const compile=(kind,source)=>{const shader=gl.createShader(kind);shaderSource.call(gl,shader,source);gl.compileShader(shader);if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(shader));return shader;};\n        const vs=compile(gl.VERTEX_SHADER,'#version 300 es\\nvoid main(){vec2 p=gl_VertexID==0?vec2(-1.,-1.):gl_VertexID==1?vec2(3.,-1.):vec2(-1.,3.);gl_Position=vec4(p,0.,1.);}');\n        const fs=compile(gl.FRAGMENT_SHADER,'#version 300 es\\nprecision highp float;uniform sampler2D envelope;out vec4 color;void main(){float d=texelFetch(envelope,ivec2(gl_FragCoord.xy),0).r;color=vec4(d,d,d,1.);}');\n        const program=gl.createProgram();attachShader.call(gl,program,vs);attachShader.call(gl,program,fs);gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(program));\n        const width=gl.drawingBufferWidth,height=gl.drawingBufferHeight;\n        const color=gl.createTexture(),framebuffer=gl.createFramebuffer();gl.bindTexture(gl.TEXTURE_2D,color);gl.texStorage2D(gl.TEXTURE_2D,1,gl.RGBA32F,width,height);gl.bindTexture(gl.TEXTURE_2D,saved.texture);\n        gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,framebuffer);gl.framebufferTexture2D(gl.DRAW_FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,color,0);if(gl.checkFramebufferStatus(gl.DRAW_FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw new Error('Envelope proof framebuffer incomplete');\n        for(const [cap] of capabilities)gl.disable(cap);\n        gl.viewport(0,0,width,height);useProgram.call(gl,program);gl.uniform1i(gl.getUniformLocation(program,'envelope'),5);gl.bindVertexArray(null);drawArrays.call(gl,gl.TRIANGLES,0,3);\n        gl.bindFramebuffer(gl.READ_FRAMEBUFFER,framebuffer);gl.readBuffer(gl.COLOR_ATTACHMENT0);const pixels=new Float32Array(width*height*4);gl.readPixels(0,0,width,height,gl.RGBA,gl.FLOAT,pixels);const error=gl.getError();\n        useProgram.call(gl,saved.program);gl.bindVertexArray(saved.vao);gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,saved.draw);gl.bindFramebuffer(gl.READ_FRAMEBUFFER,saved.read);gl.viewport(...saved.viewport);\n        for(const [cap,on] of capabilities)(on?gl.enable:gl.disable).call(gl,cap);\n        gl.deleteFramebuffer(framebuffer);gl.deleteTexture(color);gl.deleteProgram(program);gl.deleteShader(vs);gl.deleteShader(fs);\n        if(error!==gl.NO_ERROR)throw new Error('Envelope proof GL error '+error);\n        let skippedPixels=0,unsafePixels=0,unbounded=0,finite=0,uncovered=0;\n        for(let y=0;y<height;y++)for(let x=0;x<width;x++){\n            const d=pixels[(y*width+x)*4],outside=x+0.5<rect[0]||y+0.5<rect[1]||x+0.5>=rect[2]||y+0.5>=rect[3];\n            if(d===1)unbounded++;else if(d===0)uncovered++;else finite++;\n            if(outside){skippedPixels++;if(d!==1)unsafePixels++;}\n        }\n        const result={bounds:state.bounds,skippedPixels,unsafePixels,unbounded,finite,uncovered};state.proofs.push(result);return result;\n    };\n    // Clone the particle fragment program without the portal predicate. Replay each logical\n    // dominant draw into disjoint scissor rectangles, preserving order within every pixel.\n    const normalLink=p.linkProgram, normalGetLocation=p.getUniformLocation;\n    const spatialUse=p.useProgram, spatialDraw=p.drawElementsInstanced;\n    const nativeScissor=p.scissor, nativeEnable=p.enable, nativeDisable=p.disable;\n    const pairs=new WeakMap(), locationInfo=new WeakMap();\n    const uniformNames=['uniform1f','uniform1i','uniform1ui','uniform2f','uniform2i','uniform2ui','uniform3f','uniform3i','uniform3ui','uniform4f','uniform4i','uniform4ui','uniform1fv','uniform2fv','uniform3fv','uniform4fv','uniform1iv','uniform2iv','uniform3iv','uniform4iv','uniform1uiv','uniform2uiv','uniform3uiv','uniform4uiv','uniformMatrix2fv','uniformMatrix3fv','uniformMatrix4fv','uniformMatrix2x3fv','uniformMatrix2x4fv','uniformMatrix3x2fv','uniformMatrix3x4fv','uniformMatrix4x2fv','uniformMatrix4x3fv'];\n    const nativeUniform=Object.fromEntries(uniformNames.map(n=>[n,p[n]]));\n    state.splitPrograms=[];state.physicalDraws=0;\n    p.linkProgram=function(program){\n        normalLink.call(this,program);\n        const shaders=attached.get(program)||[],fs=shaders.find(s=>(shaderTexts.get(s)||'').includes('uniform int uDiagnosticSpatialMode;'));\n        if(!fs)return;\n        const text=shaderTexts.get(fs),alternative=text.replace('if (!portalDiagnosticFragmentVisible()) discard;','').replace(/if\\(uDiagnosticLayerCounter==1\\)\\{[\\s\\S]*?return;\\s*\\}/,'').replace(/struct PortalArrivalMetadata[\\s\\S]*?in vec2 vTextureCoordinate;/,'in vec2 vTextureCoordinate;').replace(/bool portalDiagnosticFragmentVisible\\(\\)[\\s\\S]*?vec4 sampleMaterial\\(\\)/,'vec4 sampleMaterial()');\n        if(alternative===text || alternative.includes('uPortalEnvelopeDepth') || alternative.includes('portalOriginalFragmentVisible'))throw new Error('Portal declaration removal failed');\n        const shader=this.createShader(this.FRAGMENT_SHADER);shaderSource.call(this,shader,alternative);this.compileShader(shader);if(!this.getShaderParameter(shader,this.COMPILE_STATUS))throw new Error(this.getShaderInfoLog(shader));\n        const alt=this.createProgram(),vertex=shaders.find(s=>this.getShaderParameter(s,this.SHADER_TYPE)===this.VERTEX_SHADER);\n        attachShader.call(this,alt,vertex);attachShader.call(this,alt,shader);normalLink.call(this,alt);this.deleteShader(shader);\n        if(!this.getProgramParameter(alt,this.LINK_STATUS))throw new Error(this.getProgramInfoLog(alt));\n        const block=this.getUniformBlockIndex(alt,'PortalScopeAtlasMetadata');if(block!==this.INVALID_INDEX)this.uniformBlockBinding(alt,block,0);\n        const pair={alt,values:new Map(),locations:new Map(),altValues:new Map()};pairs.set(program,pair);\n        state.splitPrograms.push({originalBytes:text.length,alternateBytes:alternative.length,portalBlockRetained:block!==this.INVALID_INDEX});\n    };\n    p.getUniformLocation=function(program,name){const location=normalGetLocation.call(this,program,name),pair=pairs.get(program);if(location&&pair)locationInfo.set(location,{pair,name});return location;};\n    for(const method of uniformNames)p[method]=function(location,...args){\n        const info=location&&locationInfo.get(location);if(info)info.pair.values.set(info.name,{method,args:args.map(v=>ArrayBuffer.isView(v)?Array.from(v):v)});\n        return nativeUniform[method].call(this,location,...args);\n    };\n    let clipEnabled=false,clipBox=null;\n    p.scissor=function(x,y,width,height){clipBox=[x,y,width,height];return nativeScissor.apply(this,arguments);};\n    p.enable=function(cap){if(cap===this.SCISSOR_TEST)clipEnabled=true;return nativeEnable.call(this,cap);};\n    p.disable=function(cap){if(cap===this.SCISSOR_TEST)clipEnabled=false;return nativeDisable.call(this,cap);};\n    p.drawElementsInstanced=function(mode,count,type,offset,instances){\n        const program=programs.get(this),pair=pairs.get(program);\n        if(!pair||count!==330||state.mode!=='split')return spatialDraw.apply(this,arguments);\n        if(!state.bounds)throw new Error('Missing split bounds');\n        if(pair.values.get('uPortalRenderDomain')?.args[0]!==0)throw new Error('Split draw is not in root domain');\n        const [left,bottom,right,top]=state.bounds.rect,width=this.drawingBufferWidth,height=this.drawingBufferHeight;\n        const savedEnabled=clipEnabled,savedBox=clipBox?[...clipBox]:[0,0,width,height];\n        const admitted=(x,y,r,t)=>{\n            if(savedEnabled){x=Math.max(x,savedBox[0]);y=Math.max(y,savedBox[1]);r=Math.min(r,savedBox[0]+savedBox[2]);t=Math.min(t,savedBox[1]+savedBox[3]);}\n            if(r<=x||t<=y)return false;nativeScissor.call(this,x,y,r-x,t-y);return true;\n        };\n        nativeEnable.call(this,this.SCISSOR_TEST);\n        // Keep original visibility and material shading in the affected rectangle.\n        if(admitted(left,bottom,right,top)){spatialDraw.apply(this,arguments);state.physicalDraws++;}\n        else {state.counts.draws++;state.counts.instances+=instances;}\n        useProgram.call(this,pair.alt);\n        for(const [name,value] of pair.values){\n            if(pair.altValues.get(name)===value)continue;\n            if(!pair.locations.has(name))pair.locations.set(name,normalGetLocation.call(this,pair.alt,name));\n            const location=pair.locations.get(name);\n            if(location!==null)nativeUniform[value.method].call(this,location,...value.args);\n            pair.altValues.set(name,value);\n        }\n        for(const rect of [[0,0,width,bottom],[0,top,width,height],[0,bottom,left,top],[right,bottom,width,top]]){\n            if(admitted(...rect)){drawElements.apply(this,arguments);state.physicalDraws++;}\n        }\n        useProgram.call(this,program);nativeScissor.call(this,...savedBox);if(!savedEnabled)nativeDisable.call(this,this.SCISSOR_TEST);\n    };\n\n}");
	await waitFor(
		client,
		`() => document.body?.innerText.includes("Choose a character")`,
		timeoutMs,
		"character selection",
	);
	const selectedCharacter = await evaluate(
		client,
		`() => {
			const character = document.querySelector(".client-character");
			if (!character) throw new Error("No character is available for the probe.");
			const label = character.textContent.trim();
			character.click();
			return label;
		}`,
	);
	printReport({ stage: "character-selected" });
	await evaluate(
		client,
		`() => [...document.querySelectorAll("button")].find((button) => button.textContent?.includes("Enter World"))?.click()`,
	);
	const initial = await waitForReady(
		client,
		timeoutMs,
		"initial world entry",
		true,
	);
	if (!initial.ready) {
		throw new Error("Initial world entry did not produce a destination frame.");
	}

	if (streamingOptions !== null) {
		const result = await runClientStreamingProbe(
			client,
			{ evaluate, submitChat, waitForReady, pageState },
			streamingOptions,
		);
		await writeFile(
			streamingOptions.reportPath,
			stringifyRedactedProbeReport(
				{
					...result,
					selectedCharacter,
					consoleMessages: [...consoleMessages.values()],
					page: await pageState(client),
					hostOutput: redact(output).slice(-30000),
				},
				{ account, password },
			),
		);
		printReport({ ok: result.ok, trials: result.trials.length });
		process.exitCode = result.ok ? 0 : 1;
	} else if (mode === "inventory") {
		await evaluate(
			client,
			`() => document.querySelector('button[aria-label="Inventory"]').click()`,
		);
		await waitFor(
			client,
			`() => {
            const panel = document.querySelector('.client-inventory');
            const images = [...document.querySelectorAll('.client-inventory img.ui-icon')];
            return panel?.getAttribute('aria-busy') === 'false' && images.length > 0 &&
                images.every(image => image.complete && image.naturalWidth === 32);
        }`,
			timeoutMs,
			"decoded inventory artwork",
		);
		const inventoryState = `() => ({
            images: [...document.querySelectorAll('.client-inventory img.ui-icon')].map(image => ({
                guid: image.closest('[data-item-guid]').getAttribute('data-item-guid'),
                url: image.src, width: image.naturalWidth, height: image.naturalHeight,
                count: image.closest("[data-item-guid]").querySelector(".item-count-overlay")?.textContent ?? null,
            })),
            fallbacks: document.querySelectorAll('.client-inventory .ui-icon-fallback').length,
            containers: [...document.querySelectorAll('.client-inventory section')].map(section => section.getAttribute('aria-label')),
        })`;
		const before = await evaluate(client, inventoryState);
		await evaluate(
			client,
			`() => document.querySelector('button[aria-label="Close Inventory"]').click()`,
		);
		await delay(1000);
		await evaluate(
			client,
			`() => document.querySelector('button[aria-label="Inventory"]').click()`,
		);
		await waitFor(
			client,
			`() => document.querySelector('.client-inventory img.ui-icon') !== null`,
			timeoutMs,
			"reopened inventory",
		);
		const after = await evaluate(client, inventoryState);
		const retained =
			JSON.stringify(before.images) === JSON.stringify(after.images);
		const screenshotPath = await captureScreenshot(client);
		printReport({
			ok: retained,
			mode,
			before,
			after,
			retained,
			screenshotPath,
			consoleMessages: [...consoleMessages.values()],
			page: await pageState(client),
		});
		process.exitCode = retained ? 0 : 1;
	} else if (mode === "profile") {


        await delay(PROFILE_SETTLE_MS);
        if([...consoleMessages.values()].some(m=>m.level==='exception'||m.level==='error'))throw new Error('Browser error before measurement');
        const trials=[],proofs=[];
        for(let round=0;round<5;round++) {
            const order=round%2?['split','normal']:['normal','split'];
            for(const mode of order) {
                await evaluate(client, `() => {window.__spatialAudit.mode=${JSON.stringify(mode)};window.__holtburgerClientPerformance.setRendererProfilingEnabled(true);}`);
                await delay(1500);
                await evaluate(client, `() => {window.__spatialAudit.counts={draws:0,instances:0};window.__spatialAudit.physicalDraws=0;window.__holtburgerClientPerformance.reset();}`);
                const start=Date.now();await delay(4000);
                const result=await evaluate(client, `() => ({snapshot:window.__holtburgerClientPerformance.snapshot(),counts:window.__spatialAudit.counts,bounds:window.__spatialAudit.bounds,firstDraw:window.__spatialAudit.firstDraw,physicalDraws:window.__spatialAudit.physicalDraws,splitPrograms:window.__spatialAudit.splitPrograms})`);
                const gpu=result.snapshot.diagnostics.renderer.profile?.gpu?.mean;
                if(!gpu||result.snapshot.sampledFrameCount===0)throw new Error('No valid GPU profile');
                trials.push({round,mode,windowMs:Date.now()-start,...result});
                await evaluate(client, `() => window.__holtburgerClientPerformance.setRendererProfilingEnabled(false)`);
                const proof=await evaluate(client, `() => window.__spatialAudit.inspectEnvelope()`);
                proofs.push({round,mode,...proof});
                if(proof.unsafePixels!==0)throw new Error('Conservative region proof failed');
                await writeFile('/tmp/h3d-split-clean-costs.json',stringifyRedactedProbeReport({trials,proofs,consoleMessages:[...consoleMessages.values()]},{account,password}));
                printReport({round,mode,particleGpuMs:gpu.particleMs,totalGpuMs:gpu.totalMs,counts:result.counts,frames:result.snapshot.sampledFrameCount,bounds:result.bounds,proof});
            }
        }
        if([...consoleMessages.values()].some(m=>m.level==='exception'||m.level==='error'))throw new Error('Browser error during measurement');
        const layers=[];
        for(let trial=0;trial<3;trial++){
            const counts=await evaluate(client, `async () => {const state=window.__spatialAudit;state.mode='normal';state.counterCapture={};await new Promise(resolve=>requestAnimationFrame(resolve));return state.finishLayers();}`);
            if(counts.visibilityMismatches!==0)throw new Error('Actual particle visibility mismatch');layers.push(counts);printReport({counter:counts});
        }
        await writeFile('/tmp/h3d-split-clean-costs.json',stringifyRedactedProbeReport({trials,proofs,layers,consoleMessages:[...consoleMessages.values()]},{account,password}));
        printReport({ok:true,reportPath:'/tmp/h3d-split-clean-costs.json'});

	} else if (mode === "passive-camera") {
		await delay(PASSIVE_CAMERA_SETTLE_MS);
		const cameraEvidence = await capturePassiveCameraGesture(client);
		const cameraSummary = summarizeCameraEvidence(cameraEvidence);
		const screenshotPath = await captureScreenshot(client);
		const captureComplete =
			cameraSummary.inputEventCount === PASSIVE_CAMERA_INPUT_COUNT &&
			cameraSummary.cameraEventCount > 0 &&
			cameraSummary.animationFrameCount > 0;
		printReport({
			ok: captureComplete,
			mode,
			commands: [],
			teleports: [],
			cameraEvidence: cameraSummary,
			screenshotPath,
			consoleMessages: [...consoleMessages.values()],
			page: await pageState(client),
			hostOutput: redact(output).slice(-30_000),
		});
		process.exitCode = captureComplete ? 0 : 1;
	} else if (mode === "precise-jump") {
		const preciseJump = await capturePreciseJumpEntry(client, timeoutMs);
		const responsive =
			preciseJump.sweep.evaluationCount > 1 &&
			Number.isFinite(preciseJump.sweep.postStopLatencyMs);
		printReport({
			ok:
				responsive &&
				preciseJump.page.error === null &&
				!preciseJump.webgl.contextLost,
			mode,
			commands: [],
			teleports: [],
			preciseJump,
			consoleMessages: [...consoleMessages.values()],
			page: preciseJump.page,
			hostOutput: redact(output).slice(-30_000),
		});
		process.exitCode =
			responsive &&
			preciseJump.page.error === null &&
			!preciseJump.webgl.contextLost
				? 0
				: 1;
	} else {
		commands ??= defaultTeleportSequence(initial.lastState.bodyText);

		for (const command of commands) {
			const before = await pageState(client);
			await submitChat(client, command);
			const outcome = await waitForReady(
				client,
				timeoutMs,
				command,
				true,
				before.camera?.cameraGeneration ?? null,
			);
			const generation = outcome.lastState.camera?.cameraGeneration;
			const cameraGeneration = outcome.lastState.cameraGenerations.find(
				(evidence) => evidence.cameraGeneration === generation,
			);
			const provenInitialReseed =
				cameraGeneration?.first.kind === "reseeded" &&
				cameraGeneration.first.reason === "initial-placement" &&
				cameraGeneration.first.clearance !== null;
			const lastState = {
				notice: outcome.lastState.notice,
				error: outcome.lastState.error,
				camera: outcome.lastState.camera,
				bodyText: outcome.lastState.bodyText,
			};
			hops.push({
				command,
				ready: outcome.ready,
				elapsedMs: outcome.elapsedMs,
				lastState,
				cameraGeneration,
				provenInitialReseed,
			});
			if (!outcome.ready) break;
		}

		printReport({
			ok:
				hops.length === commands.length &&
				hops.every((hop) => hop.ready && hop.provenInitialReseed),
			hops,
			consoleMessages: [...consoleMessages.values()],
			page: await pageState(client),
			hostOutput: redact(output).slice(-30_000),
		});
	}
} catch (error) {
	printReport({
		ok: false,
		error: safeError(error),
		hops,
		consoleMessages: [...consoleMessages.values()],
		page:
			client === undefined ? null : await pageState(client).catch(() => null),
		hostOutput: redact(output).slice(-12_000),
	});
	process.exitCode = 1;
} finally {
	if (client !== undefined) {
		try {
			await evaluate(
				client,
				`async () => window.holtburgerHost.invoke("disconnect_client")`,
			);
			printReport({ cleanup: "disconnected" });
		} catch (error) {
			printReport({ cleanupError: safeError(error) });
			process.exitCode = 1;
		}
	}
	client?.close();
	if (child.exitCode === null && child.signalCode === null)
		child.kill("SIGTERM");
}

// Both camera and profiling probes can retain the rendered frame they measured.
async function captureScreenshot(client_) {
	const path = process.env.HOLTBURGER_PROBE_SCREENSHOT;
	if (path === undefined) return null;
	await client_.send("Page.enable");
	const screenshot = await client_.send("Page.captureScreenshot", {
		format: "png",
	});
	await writeFile(path, screenshot.data, "base64");
	return path;
}

function requiredEnvironment(name) {
	const value = process.env[name];
	if (value === undefined || value.length === 0)
		throw new Error(`${name} must be set.`);
	return value;
}

function probeMode(value) {
	if (value === undefined) {
		throw new Error(
			"HOLTBURGER_PROBE_MODE must be explicitly set to teleport, passive-camera, precise-jump, profile, inventory, or streaming.",
		);
	}
	const mode = value;
	if (
		mode !== "teleport" &&
		mode !== "passive-camera" &&
		mode !== "precise-jump" &&
		mode !== "profile" &&
		mode !== "inventory" &&
		mode !== "streaming"
	) {
		throw new Error(
			"HOLTBURGER_PROBE_MODE must be teleport, passive-camera, precise-jump, profile, inventory, or streaming.",
		);
	}
	return mode;
}

function parseCommands(value) {
	const parsed = value
		.split("|")
		.map((command) => command.trim())
		.filter((command) => command.length > 0);
	if (
		parsed.length === 0 ||
		parsed.some((command) => !command.startsWith("@"))
	) {
		throw new Error(
			"Teleport sequence must contain pipe-separated chat commands.",
		);
	}
	return parsed;
}

function defaultTeleportSequence(bodyText) {
	if (bodyText.includes("22.0S, 2.0W")) {
		return parseCommands(
			"@teledungeon 0288|@tele 22s 2w|@teledungeon 0288|@tele 22s 2w",
		);
	}
	return parseCommands(
		"@tele 22s 2w|@teledungeon 0288|@tele 22s 2w|@teledungeon 0288",
	);
}

function redact(value) {
	return value
		.replaceAll(account, "<account>")
		.replaceAll(password, "<password>");
}

function safeError(error) {
	return redact(error instanceof Error ? error.message : String(error));
}

function printReport(report) {
	console.log(
		stringifyRedactedProbeReport(report, {
			account,
			password,
		}),
	);
}

function recordConsoleMessage(message) {
	const key = `${message.level}\u0000${message.text}`;
	const previous = consoleMessages.get(key);
	consoleMessages.set(key, {
		...message,
		count: (previous?.count ?? 0) + 1,
	});
}

function delay(milliseconds) {
	return new Promise((resolvePromise) =>
		setTimeout(resolvePromise, milliseconds),
	);
}

function summarizePerformanceSnapshot(snapshot) {
	const profile = snapshot.diagnostics.renderer?.profile;
	return {
		frameRates: snapshot.frameRates,
		meanFrameWorkMs: snapshot.meanFrameWorkMs,
		renderedFrames: snapshot.sampledFrameCount,
		rendererCpuMean: profile?.cpu.mean ?? null,
		rendererGpuMean:
			profile?.gpu.kind === "available" ? profile.gpu.mean : null,
		runtimeTickMean: snapshot.diagnostics.tickProfile?.mean ?? null,
		selectionMetrics: snapshot.diagnostics.renderer?.selectionMetrics ?? null,
		dynamicResources: snapshot.diagnostics.renderer?.dynamicResources ?? null,
		viewport: snapshot.diagnostics.viewport,
		playerResidency: snapshot.diagnostics.playerResidency,
		cameraResidency: snapshot.diagnostics.cameraResidency,
	};
}

async function waitForDevToolsUrl(process_, readOutput) {
	const startedAt = Date.now();
	for (;;) {
		const match = readOutput().match(/DevTools listening on (ws:\/\/[^\s]+)/);
		if (match?.[1]) return match[1];
		if (process_.exitCode !== null || process_.signalCode !== null) {
			throw new Error("Electron exited before opening its DevTools endpoint.");
		}
		if (Date.now() - startedAt >= 60_000) {
			throw new Error("Timed out waiting for Electron DevTools endpoint.");
		}
		await delay(100);
	}
}

async function waitForPageWebSocketUrl(browserWebSocketUrl) {
	const { port } = new URL(browserWebSocketUrl);
	const startedAt = Date.now();
	for (;;) {
		const targets = await fetch(`http://127.0.0.1:${port}/json/list`, {
			signal: AbortSignal.timeout(10_000),
		}).then((response) => response.json());
		const page = targets.find(
			(target) => target.type === "page" && target.url.includes("/client/"),
		);
		if (page?.webSocketDebuggerUrl) return page.webSocketDebuggerUrl;
		if (Date.now() - startedAt >= 60_000) {
			throw new Error("Timed out waiting for the Electron client page.");
		}
		await delay(100);
	}
}

async function evaluate(client_, expression) {
	const result = await client_.send("Runtime.evaluate", {
		expression: `(${expression})()`,
		awaitPromise: true,
		returnByValue: true,
	});
	if (result.exceptionDetails) throw new Error(result.exceptionDetails.text);
	return result.result.value;
}

async function waitFor(client_, predicate, milliseconds, description) {
	const startedAt = Date.now();
	for (;;) {
		if (await evaluate(client_, predicate)) return;
		if (Date.now() - startedAt >= milliseconds) {
			throw new Error(`Timed out waiting for ${description}.`);
		}
		await delay(100);
	}
}

async function installEvidenceCollector(client_) {
	await evaluate(
		client_,
		`async () => {
			const bridge = window.holtburgerHost;
			if (bridge === undefined) throw new Error("Electron host bridge is unavailable.");
			const evidence = {
				camera: null,
				cameraGenerations: [],
				lifecycle: null,
				lifecycles: [],
				collecting: false,
				cameraEvents: [],
				animationFrames: [],
				inputEvents: [],
				preciseJumpEvaluations: [],
				preciseJumpEvaluationTimes: [],
			};
			Object.defineProperty(window, "__holtburgerProbeEvidence", {
				configurable: true,
				value: evidence,
			});
			await bridge.listen("client-camera", (tick) => {
				if (evidence.collecting) evidence.cameraEvents.push(performance.now());
				const pathEnd = tick.path.legs.at(-1)?.end.position ?? tick.path.initial.position;
				const summary = {
					cameraGeneration: tick.cameraGeneration,
					sequence: tick.sequence,
					kind: tick.kind,
					reason: tick.reason ?? null,
					clearance: tick.clearance ?? null,
					initialLandblockId: tick.path.initial.position.landblockId,
					finalLandblockId: pathEnd.landblockId,
					position: pathEnd,
				};
				evidence.camera = summary;
				const generation = evidence.cameraGenerations.find(
					(candidate) => candidate.cameraGeneration === tick.cameraGeneration,
				);
				if (generation === undefined) {
					evidence.cameraGenerations.push({
						cameraGeneration: tick.cameraGeneration,
						first: summary,
						latest: summary,
					});
				} else {
					generation.latest = summary;
				}
			});
			await bridge.listen("client-lifecycle-changed", (lifecycle) => {
				evidence.lifecycle = lifecycle;
				evidence.lifecycles.push(lifecycle);
			});
			await bridge.listen("client-precise-jump-evaluation", (evaluation) => {
				evidence.preciseJumpEvaluations.push(evaluation);
				evidence.preciseJumpEvaluationTimes.push(performance.now());
			});
			const collectAnimationFrame = (timestamp) => {
				if (evidence.collecting) evidence.animationFrames.push(timestamp);
				requestAnimationFrame(collectAnimationFrame);
			};
			requestAnimationFrame(collectAnimationFrame);
		}`,
	);
}

async function capturePreciseJumpEntry(client_, milliseconds) {
	// World-ready notices precede gameplay input admission during portal-space activation.
	await waitFor(
		client_,
		"() => window.__holtburgerProbeEvidence.lifecycle?.kind === 'in-world'",
		milliseconds,
		"in-world precise-jump input",
	);
	const bounds = await evaluate(
		client_,
		`() => {
			const canvas = document.querySelector(".client-canvas");
			if (!(canvas instanceof HTMLCanvasElement)) {
				throw new Error("Client canvas is unavailable.");
			}
			canvas.focus();
			const rect = canvas.getBoundingClientRect();
			window.__holtburgerProbeEvidence.preciseJumpEvaluations = [];
			window.__holtburgerProbeEvidence.preciseJumpEvaluationTimes = [];
			return { x: rect.x, y: rect.y, width: rect.width, height: rect.height };
		}`,
	);
	const x = bounds.x + bounds.width * 0.5;
	const y = bounds.y + bounds.height * 0.6;
	await client_.send("Input.dispatchMouseEvent", {
		type: "mouseMoved",
		x,
		y,
		button: "none",
		buttons: 0,
	});
	await evaluate(
		client_,
		`() => {
			const dispatch = (type, key, shiftKey) =>
				window.dispatchEvent(
					new KeyboardEvent(type, { bubbles: true, key, shiftKey }),
				);
			dispatch("keydown", "J", true);
			dispatch("keyup", "J", false);
		}`,
	);
	const startedAt = Date.now();
	for (;;) {
		const state = await evaluate(
			client_,
			`() => ({
				evaluations: window.__holtburgerProbeEvidence.preciseJumpEvaluations,
				error: document.querySelector('[role="alert"]')?.textContent?.trim() ?? null,
			})`,
		);
		if (
			state.evaluations.some(
				(evaluation) => evaluation.phase === "completed",
			) ||
			state.error !== null
		)
			break;
		if (Date.now() - startedAt >= milliseconds) {
			throw new Error("Timed out waiting for precise-jump evaluation.");
		}
		await delay(100);
	}
	const sweepStartedAt = await evaluate(client_, "() => performance.now()");
	for (let index = 0; index < PRECISE_JUMP_SWEEP_INPUT_COUNT; index += 1) {
		const fraction = index / (PRECISE_JUMP_SWEEP_INPUT_COUNT - 1);
		await client_.send("Input.dispatchMouseEvent", {
			type: "mouseMoved",
			x: bounds.x + bounds.width * (0.35 + fraction * 0.3),
			y: bounds.y + bounds.height * 0.6,
			button: "none",
			buttons: 0,
		});
		await delay(PRECISE_JUMP_SWEEP_INPUT_INTERVAL_MS);
	}
	const stoppedAt = await evaluate(client_, "() => performance.now()");
	await waitFor(
		client_,
		`() => window.__holtburgerProbeEvidence.preciseJumpEvaluations.some(
            (evaluation, index) => evaluation.phase === "completed" && window.__holtburgerProbeEvidence.preciseJumpEvaluationTimes[index] >= ${stoppedAt},
		)`,
		milliseconds,
		"post-sweep precise-jump evaluation",
	);
	await delay(100);
	const result = await evaluate(
		client_,
		`() => {
			const canvas = document.querySelector(".client-canvas");
			const gl = canvas instanceof HTMLCanvasElement ? canvas.getContext("webgl2") : null;
			return {
				evaluations: window.__holtburgerProbeEvidence.preciseJumpEvaluations,
				evaluationTimes: window.__holtburgerProbeEvidence.preciseJumpEvaluationTimes,
				page: {
					notice: document.querySelector(".client-toast")?.textContent?.trim() ?? null,
					error: document.querySelector('[role="alert"]')?.textContent?.trim() ?? null,
				},
				webgl: {
					contextLost: gl?.isContextLost() ?? true,
					renderer: gl?.getParameter(gl.RENDERER) ?? null,
					vendor: gl?.getParameter(gl.VENDOR) ?? null,
				},
			};
		}`,
	);
	const sweepEvaluationTimes = result.evaluationTimes.filter(
		(time) => time >= sweepStartedAt,
	);
	return {
		...result,
		sweep: {
			inputCount: PRECISE_JUMP_SWEEP_INPUT_COUNT,
			durationMs: stoppedAt - sweepStartedAt,
			evaluationCount: sweepEvaluationTimes.length,
			maximumEvaluationGapMs: maximumAdjacentGap(sweepEvaluationTimes),
			postStopLatencyMs:
				sweepEvaluationTimes.find((time) => time >= stoppedAt) - stoppedAt,
		},
	};
}

function maximumAdjacentGap(values) {
	let maximum = 0;
	for (let index = 1; index < values.length; index += 1) {
		maximum = Math.max(maximum, values[index] - values[index - 1]);
	}
	return maximum;
}

async function capturePassiveCameraGesture(client_) {
	const bounds = await evaluate(
		client_,
		`() => {
			const canvas = document.querySelector(".client-canvas");
			if (!(canvas instanceof HTMLCanvasElement)) {
				throw new Error("Client canvas is unavailable.");
			}
			const rect = canvas.getBoundingClientRect();
			const evidence = window.__holtburgerProbeEvidence;
			evidence.cameraEvents = [];
			evidence.animationFrames = [];
			evidence.inputEvents = [];
			evidence.collecting = true;
			return { x: rect.x, y: rect.y, width: rect.width, height: rect.height };
		}`,
	);
	const startX = bounds.x + bounds.width * 0.45;
	const startY = bounds.y + bounds.height * 0.5;
	await client_.send("Input.dispatchMouseEvent", {
		type: "mousePressed",
		x: startX,
		y: startY,
		button: "left",
		buttons: 1,
		clickCount: 1,
	});
	for (let step = 1; step <= PASSIVE_CAMERA_INPUT_COUNT; step += 1) {
		await evaluate(
			client_,
			"() => window.__holtburgerProbeEvidence.inputEvents.push(performance.now())",
		);
		await client_.send("Input.dispatchMouseEvent", {
			type: "mouseMoved",
			x: startX + step * 2,
			y: startY + Math.sin(step / 6) * 12,
			button: "left",
			buttons: 1,
		});
		await delay(PASSIVE_CAMERA_INPUT_INTERVAL_MS);
	}
	await client_.send("Input.dispatchMouseEvent", {
		type: "mouseReleased",
		x: startX + 80,
		y: startY,
		button: "left",
		buttons: 0,
		clickCount: 1,
	});
	await delay(2_000);
	return evaluate(
		client_,
		`() => {
			const evidence = window.__holtburgerProbeEvidence;
			evidence.collecting = false;
			return {
				cameraEvents: evidence.cameraEvents,
				animationFrames: evidence.animationFrames,
				inputEvents: evidence.inputEvents,
			};
		}`,
	);
}

function summarizeCameraEvidence(evidence) {
	const cameraIntervals = intervals(evidence.cameraEvents);
	const animationFrameIntervals = intervals(evidence.animationFrames);
	const inputLatencies = evidence.inputEvents.flatMap((input) => {
		const camera = evidence.cameraEvents.find((event) => event >= input);
		return camera === undefined ? [] : [camera - input];
	});
	return {
		cameraEventCount: evidence.cameraEvents.length,
		animationFrameCount: evidence.animationFrames.length,
		inputEventCount: evidence.inputEvents.length,
		cameraIntervalMs: distribution(cameraIntervals),
		animationFrameIntervalMs: distribution(animationFrameIntervals),
		// This measures the next publication, not a causal acknowledgement of orbit input.
		inputToNextCameraEventMs: distribution(inputLatencies),
	};
}

function intervals(values) {
	return values.slice(1).map((value, index) => value - values[index]);
}

function distribution(values) {
	if (values.length === 0) return null;
	const sorted = [...values].sort((left, right) => left - right);
	const percentile = (fraction) =>
		sorted[
			Math.min(
				sorted.length - 1,
				Math.max(0, Math.ceil(sorted.length * fraction) - 1),
			)
		];
	return {
		count: sorted.length,
		mean: sorted.reduce((total, value) => total + value, 0) / sorted.length,
		p50: percentile(0.5),
		p95: percentile(0.95),
		max: sorted.at(-1),
	};
}

async function submitChat(client_, message) {
	await evaluate(
		client_,
		`() => {
			const input = document.querySelector('input[aria-label="Chat message"]');
			if (!(input instanceof HTMLInputElement)) throw new Error("Chat input is unavailable.");
			const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
			setter?.call(input, ${JSON.stringify(message)});
			input.dispatchEvent(new Event("input", { bubbles: true }));
			input.form?.requestSubmit();
		}`,
	);
}

async function waitForReady(
	client_,
	milliseconds,
	description,
	requireLoading,
	previousCameraGeneration = null,
) {
	const startedAt = Date.now();
	let sawLoading = false;
	for (;;) {
		const state = await pageState(client_);
		if (state.notice !== null && state.notice !== WORLD_READY_NOTICE) {
			sawLoading = true;
		}
		const hasCurrentCamera =
			state.camera !== null &&
			(previousCameraGeneration === null ||
				state.camera.cameraGeneration !== previousCameraGeneration);
		if (
			state.notice === WORLD_READY_NOTICE &&
			hasCurrentCamera &&
			(!requireLoading || sawLoading)
		) {
			return {
				ready: true,
				elapsedMs: Date.now() - startedAt,
				lastState: state,
			};
		}
		if (Date.now() - startedAt >= milliseconds) {
			return {
				ready: false,
				elapsedMs: Date.now() - startedAt,
				lastState: state,
			};
		}
		await delay(100);
	}
}

function pageState(client_) {
	return evaluate(
		client_,
		`() => ({
			notice: document.querySelector(".client-toast")?.textContent?.trim() ?? null,
			error: document.querySelector('[role="alert"]')?.textContent?.trim() ?? null,
			camera: window.__holtburgerProbeEvidence?.camera ?? null,
			cameraGenerations: window.__holtburgerProbeEvidence?.cameraGenerations ?? [],
			lifecycle: window.__holtburgerProbeEvidence?.lifecycle ?? null,
			lifecycles: window.__holtburgerProbeEvidence?.lifecycles ?? [],
			bodyText: document.body?.innerText.slice(0, 4000) ?? "",
		})`,
	);
}
