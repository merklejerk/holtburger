    // Clone the particle fragment program without the portal predicate. Replay each logical
    // dominant draw into disjoint scissor rectangles, preserving order within every pixel.
    const normalLink=p.linkProgram, normalGetLocation=p.getUniformLocation;
    const spatialUse=p.useProgram, spatialDraw=p.drawElementsInstanced;
    const nativeScissor=p.scissor, nativeEnable=p.enable, nativeDisable=p.disable;
    const pairs=new WeakMap(), locationInfo=new WeakMap();
    const uniformNames=['uniform1f','uniform1i','uniform1ui','uniform2f','uniform2i','uniform2ui','uniform3f','uniform3i','uniform3ui','uniform4f','uniform4i','uniform4ui','uniform1fv','uniform2fv','uniform3fv','uniform4fv','uniform1iv','uniform2iv','uniform3iv','uniform4iv','uniform1uiv','uniform2uiv','uniform3uiv','uniform4uiv','uniformMatrix2fv','uniformMatrix3fv','uniformMatrix4fv','uniformMatrix2x3fv','uniformMatrix2x4fv','uniformMatrix3x2fv','uniformMatrix3x4fv','uniformMatrix4x2fv','uniformMatrix4x3fv'];
    const nativeUniform=Object.fromEntries(uniformNames.map(n=>[n,p[n]]));
    state.splitPrograms=[];state.physicalDraws=0;
    p.linkProgram=function(program){
        normalLink.call(this,program);
        const shaders=attached.get(program)||[],fs=shaders.find(s=>(shaderTexts.get(s)||'').includes('uniform int uDiagnosticSpatialMode;'));
        if(!fs)return;
        const text=shaderTexts.get(fs),alternative=text.replace('if (!portalDiagnosticFragmentVisible()) discard;','').replace(/if\(uDiagnosticLayerCounter==1\)\{[\s\S]*?return;\s*\}/,'');
        if(alternative===text)throw new Error('Portal predicate removal failed');
        const shader=this.createShader(this.FRAGMENT_SHADER);shaderSource.call(this,shader,alternative);this.compileShader(shader);if(!this.getShaderParameter(shader,this.COMPILE_STATUS))throw new Error(this.getShaderInfoLog(shader));
        const alt=this.createProgram(),vertex=shaders.find(s=>this.getShaderParameter(s,this.SHADER_TYPE)===this.VERTEX_SHADER);
        attachShader.call(this,alt,vertex);attachShader.call(this,alt,shader);normalLink.call(this,alt);this.deleteShader(shader);
        if(!this.getProgramParameter(alt,this.LINK_STATUS))throw new Error(this.getProgramInfoLog(alt));
        const block=this.getUniformBlockIndex(alt,'PortalScopeAtlasMetadata');if(block!==this.INVALID_INDEX)this.uniformBlockBinding(alt,block,0);
        const pair={alt,values:new Map(),locations:new Map()};pairs.set(program,pair);
        state.splitPrograms.push({originalBytes:text.length,alternateBytes:alternative.length,portalBlockRetained:block!==this.INVALID_INDEX});
    };
    p.getUniformLocation=function(program,name){const location=normalGetLocation.call(this,program,name),pair=pairs.get(program);if(location&&pair)locationInfo.set(location,{pair,name});return location;};
    for(const method of uniformNames)p[method]=function(location,...args){
        const info=location&&locationInfo.get(location);if(info)info.pair.values.set(info.name,{method,args:args.map(v=>ArrayBuffer.isView(v)?Array.from(v):v)});
        return nativeUniform[method].call(this,location,...args);
    };
    let clipEnabled=false,clipBox=null;
    p.scissor=function(x,y,width,height){clipBox=[x,y,width,height];return nativeScissor.apply(this,arguments);};
    p.enable=function(cap){if(cap===this.SCISSOR_TEST)clipEnabled=true;return nativeEnable.call(this,cap);};
    p.disable=function(cap){if(cap===this.SCISSOR_TEST)clipEnabled=false;return nativeDisable.call(this,cap);};
    p.drawElementsInstanced=function(mode,count,type,offset,instances){
        const program=programs.get(this),pair=pairs.get(program);
        if(!pair||count!==330||state.mode!=='split')return spatialDraw.apply(this,arguments);
        if(!state.bounds)throw new Error('Missing split bounds');
        const [left,bottom,right,top]=state.bounds.rect,width=this.drawingBufferWidth,height=this.drawingBufferHeight;
        const savedEnabled=clipEnabled,savedBox=clipBox?[...clipBox]:[0,0,width,height];
        const admitted=(x,y,r,t)=>{
            if(savedEnabled){x=Math.max(x,savedBox[0]);y=Math.max(y,savedBox[1]);r=Math.min(r,savedBox[0]+savedBox[2]);t=Math.min(t,savedBox[1]+savedBox[3]);}
            if(r<=x||t<=y)return false;nativeScissor.call(this,x,y,r-x,t-y);return true;
        };
        nativeEnable.call(this,this.SCISSOR_TEST);
        // Keep original visibility and material shading in the affected rectangle.
        if(admitted(left,bottom,right,top)){spatialDraw.apply(this,arguments);state.physicalDraws++;}
        else {state.counts.draws++;state.counts.instances+=instances;}
        useProgram.call(this,pair.alt);
        for(const [name,value] of pair.values){
            if(!pair.locations.has(name))pair.locations.set(name,normalGetLocation.call(this,pair.alt,name));
            nativeUniform[value.method].call(this,pair.locations.get(name),...value.args);
        }
        for(const rect of [[0,0,width,bottom],[0,top,width,height],[0,bottom,left,top],[right,bottom,width,top]]){
            if(admitted(...rect)){drawElements.apply(this,arguments);state.physicalDraws++;}
        }
        useProgram.call(this,program);nativeScissor.call(this,...savedBox);if(!savedEnabled)nativeDisable.call(this,this.SCISSOR_TEST);
    };
