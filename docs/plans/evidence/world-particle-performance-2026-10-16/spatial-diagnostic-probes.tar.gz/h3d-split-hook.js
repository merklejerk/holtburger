() => {
    const p=WebGL2RenderingContext.prototype;
    const shaderSource=p.shaderSource, attachShader=p.attachShader, useProgram=p.useProgram;
    const bindBuffer=p.bindBuffer, bindBufferBase=p.bindBufferBase, bufferSubData=p.bufferSubData;
    const drawArrays=p.drawArrays, drawElements=p.drawElementsInstanced;
    const programs=new WeakMap(), attached=new WeakMap(), shaderTexts=new WeakMap(), facts=new WeakMap();
    const buffers=new WeakMap(), bindings=new Map();
    const state=window.__spatialAudit={mode:'normal',frames:0,counts:{draws:0,instances:0},bounds:null,firstDraw:null,proofs:[]};
    const inject=(text)=>{
        if(!text.includes('in float vTranslucency;') || !text.includes('bool portalDeferredFragmentVisible() {'))return text;
        text=text.replace('precision highp int;','precision highp int;\nuniform int uDiagnosticSpatialMode;\nuniform vec4 uDiagnosticAffected;\nuniform int uDiagnosticLayerCounter;');
        text=text.replace('bool portalDeferredFragmentVisible() {','bool portalOriginalFragmentVisible() {');
        const helper=`
        bool portalDiagnosticFragmentVisible() {
            if (uDiagnosticSpatialMode == 2) return true;
            if (uDiagnosticSpatialMode == 1) {
                vec2 pixel = gl_FragCoord.xy;
                if (pixel.x < uDiagnosticAffected.x || pixel.y < uDiagnosticAffected.y
                    || pixel.x >= uDiagnosticAffected.z || pixel.y >= uDiagnosticAffected.w) return true;
            }
            return portalOriginalFragmentVisible();
        }
        `;
        text=text.replace('vec4 sampleMaterial()',helper+'\nvec4 sampleMaterial()');
        text=text.replace('void main() {',`void main() {
            if(uDiagnosticLayerCounter==1){
                bool original=portalOriginalFragmentVisible();
                vec2 pixel=gl_FragCoord.xy;
                bool outside=pixel.x<uDiagnosticAffected.x||pixel.y<uDiagnosticAffected.y||pixel.x>=uDiagnosticAffected.z||pixel.y>=uDiagnosticAffected.w;
                outColor=vec4(original?1.0:0.0,outside?1.0:0.0,1.0,(outside||original)!=original?1.0:0.0);return;
            }
        `);
        return text.replace('if (!portalDeferredFragmentVisible()) discard;','if (!portalDiagnosticFragmentVisible()) discard;');
    };
    p.shaderSource=function(shader,text){text=inject(text);shaderTexts.set(shader,text);return shaderSource.call(this,shader,text);};
    p.attachShader=function(program,shader){let list=attached.get(program);if(!list){list=[];attached.set(program,list);}list.push(shader);return attachShader.call(this,program,shader);};
    p.useProgram=function(program){
        programs.set(this,program);
        if(program && !facts.has(program)){
            const texts=(attached.get(program)||[]).map(s=>shaderTexts.get(s)||'');
            const root=texts.some(t=>t.includes('uint current = 1u;')&&t.includes('flat in uint vOutputArrival;'));
            const particle=this.getUniformLocation(program,'uParticleRecords')!==null;
            facts.set(program,{root,particle,mode:particle?this.getUniformLocation(program,'uDiagnosticSpatialMode'):null,affected:particle?this.getUniformLocation(program,'uDiagnosticAffected'):null,ordinal:particle?this.getUniformLocation(program,'uPortalRenderDomain'):null,counter:particle?this.getUniformLocation(program,'uDiagnosticLayerCounter'):null});
        }
        return useProgram.call(this,program);
    };
    p.bindBuffer=function(target,buffer){bindings.set(target,buffer);return bindBuffer.call(this,target,buffer);};
    let metadataBuffer=null;
    p.bindBufferBase=function(target,index,buffer){if(target===this.UNIFORM_BUFFER&&index===0)metadataBuffer=buffer;return bindBufferBase.call(this,target,index,buffer);};
    p.bufferSubData=function(target,dst,src,srcOffset=0,length){
        if(dst===0 && ArrayBuffer.isView(src) && src.BYTES_PER_ELEMENT===1 && (target===this.ARRAY_BUFFER || target===this.UNIFORM_BUFFER)){
            const bytes=length===undefined?src.byteLength-srcOffset:length;
            buffers.set(bindings.get(target),new Uint8Array(src.buffer,src.byteOffset+srcOffset,bytes).slice());
        }
        return bufferSubData.apply(this,arguments);
    };
    p.drawArrays=function(mode,first,count){
        const f=facts.get(programs.get(this));
        if(f?.root){
            const metadata=buffers.get(metadataBuffer);if(!metadata || metadata.byteLength!==16384)throw new Error('Missing mirrored portal metadata');
            const buffer=this.getVertexAttrib(0,this.VERTEX_ATTRIB_ARRAY_BUFFER_BINDING),triangles=buffers.get(buffer);
            if(!triangles || first!==0 || count%3!==0 || triangles.byteLength!==count*24)throw new Error('Crossing stream layout differs');
            const matrix=new Float32Array(metadata.buffer,metadata.byteOffset,16),verts=new DataView(triangles.buffer,triangles.byteOffset,triangles.byteLength);
            const width=this.drawingBufferWidth,height=this.drawingBufferHeight;
            let left=width,bottom=height,right=0,top=0,rootTriangles=0,eyePlaneFallback=false;
            const routes=new Set();
            for(let i=0;i<count;i+=3){
                const offset=i*24;if(verts.getUint32(offset+16,true)!==0)continue;
                rootTriangles++;routes.add(verts.getUint32(offset+12,true));
                for(let v=0;v<3;v++){
                    const o=offset+v*24,x=verts.getFloat32(o,true),y=verts.getFloat32(o+4,true),z=verts.getFloat32(o+8,true);
                    const w=matrix[3]*x+matrix[7]*y+matrix[11]*z+matrix[15];
                    if(w<=0.00001){eyePlaneFallback=true;continue;}
                    const px=((matrix[0]*x+matrix[4]*y+matrix[8]*z+matrix[12])/w+1)*width/2;
                    const py=((matrix[1]*x+matrix[5]*y+matrix[9]*z+matrix[13])/w+1)*height/2;
                    left=Math.min(left,px);right=Math.max(right,px);bottom=Math.min(bottom,py);top=Math.max(top,py);
                }
            }
            const rect=eyePlaneFallback?[0,0,width,height]:rootTriangles?[Math.max(0,Math.floor(left)-3),Math.max(0,Math.floor(bottom)-3),Math.min(width,Math.ceil(right)+3),Math.min(height,Math.ceil(top)+3)]:[0,0,0,0];
            const slots=new Uint32Array(metadata.buffer,metadata.byteOffset+8224,8);
            if(slots[0]!==0||slots[1]!==0||slots[2]!==0||slots[3]!==0||slots[4]!==width||slots[5]!==height)throw new Error('Root mapping is not full viewport');
            state.bounds={rect,rootTriangles,rootCrossings:routes.size,eyePlaneFallback,width,height,area:Math.max(0,rect[2]-rect[0])*Math.max(0,rect[3]-rect[1])};state.frames++;
        }
        return drawArrays.apply(this,arguments);
    };
    p.drawElementsInstanced=function(mode,count,type,offset,instances){
        const f=facts.get(programs.get(this));if(!f?.particle)return drawElements.apply(this,arguments);
        if(f.mode){
            const dominant=count===330;
            const value=dominant?(state.mode==='region'?1:state.mode==='no-portal'?2:0):0;
            this.uniform1i(f.mode,value);
            if(dominant){
                if(!state.bounds)throw new Error('No root crossing bounds');
                if(state.firstDraw===null){const ordinal=this.getUniform(programs.get(this),f.ordinal);if(ordinal!==0)throw new Error('Dominant mesh is not root-owned');state.firstDraw={ordinal,indexCount:count,instances};}
                this.uniform4f(f.affected,...state.bounds.rect);state.counts.draws++;state.counts.instances+=instances;state.gl=this;
            }
        }
        if(count===330 && f.counter && state.counterCapture){
            const gl=this,cap=state.counterCapture;
            if(!cap.framebuffer){
                if(!gl.getExtension('EXT_color_buffer_float')||!gl.getExtension('EXT_float_blend'))throw new Error('Float overlap counter unavailable');
                const savedTexture=gl.getParameter(gl.TEXTURE_BINDING_2D),savedFbo=gl.getParameter(gl.DRAW_FRAMEBUFFER_BINDING);
                const color=gl.createTexture(),framebuffer=gl.createFramebuffer(),width=gl.drawingBufferWidth,height=gl.drawingBufferHeight;
                const type=gl.getFramebufferAttachmentParameter(gl.DRAW_FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE),depth=gl.getFramebufferAttachmentParameter(gl.DRAW_FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.FRAMEBUFFER_ATTACHMENT_OBJECT_NAME);
                gl.bindTexture(gl.TEXTURE_2D,color);gl.texStorage2D(gl.TEXTURE_2D,1,gl.RGBA32F,width,height);gl.bindTexture(gl.TEXTURE_2D,savedTexture);
                gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,framebuffer);gl.framebufferTexture2D(gl.DRAW_FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,color,0);
                if(type===gl.TEXTURE)gl.framebufferTexture2D(gl.DRAW_FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.TEXTURE_2D,depth,0);
                else if(type===gl.RENDERBUFFER)gl.framebufferRenderbuffer(gl.DRAW_FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.RENDERBUFFER,depth);
                else throw new Error('Missing shared opaque depth');
                if(gl.checkFramebufferStatus(gl.DRAW_FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw new Error('Counter target incomplete');
                const clipped=gl.isEnabled(gl.SCISSOR_TEST);gl.disable(gl.SCISSOR_TEST);gl.clearBufferfv(gl.COLOR,0,new Float32Array(4));if(clipped)gl.enable(gl.SCISSOR_TEST);
                gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,savedFbo);Object.assign(cap,{framebuffer,color,width,height,draws:0});
            }
            const saved={fbo:gl.getParameter(gl.DRAW_FRAMEBUFFER_BINDING),blend:gl.isEnabled(gl.BLEND),src:gl.getParameter(gl.BLEND_SRC_RGB),dst:gl.getParameter(gl.BLEND_DST_RGB),srcA:gl.getParameter(gl.BLEND_SRC_ALPHA),dstA:gl.getParameter(gl.BLEND_DST_ALPHA),eq:gl.getParameter(gl.BLEND_EQUATION_RGB),eqA:gl.getParameter(gl.BLEND_EQUATION_ALPHA)};
            gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,cap.framebuffer);gl.enable(gl.BLEND);gl.blendEquation(gl.FUNC_ADD);gl.blendFunc(gl.ONE,gl.ONE);gl.uniform1i(f.counter,1);
            drawElements.apply(this,arguments);cap.draws++;
            gl.uniform1i(f.counter,0);gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,saved.fbo);gl.blendEquationSeparate(saved.eq,saved.eqA);gl.blendFuncSeparate(saved.src,saved.dst,saved.srcA,saved.dstA);if(!saved.blend)gl.disable(gl.BLEND);
            return;
        }
        return drawElements.apply(this,arguments);
    };
    state.finishLayers=()=>{
        const gl=state.gl,cap=state.counterCapture;state.counterCapture=null;if(!cap?.framebuffer)throw new Error('No overlap frame');
        const read=gl.getParameter(gl.READ_FRAMEBUFFER_BINDING);gl.bindFramebuffer(gl.READ_FRAMEBUFFER,cap.framebuffer);gl.readBuffer(gl.COLOR_ATTACHMENT0);const pixels=new Float32Array(cap.width*cap.height*4);gl.readPixels(0,0,cap.width,cap.height,gl.RGBA,gl.FLOAT,pixels);const error=gl.getError();gl.bindFramebuffer(gl.READ_FRAMEBUFFER,read);gl.deleteFramebuffer(cap.framebuffer);gl.deleteTexture(cap.color);if(error!==gl.NO_ERROR)throw new Error('Overlap GL error '+error);
        const sums=[0,0,0,0];for(let i=0;i<pixels.length;i++)sums[i%4]+=pixels[i];return {draws:cap.draws,bounds:state.bounds,visibleLayers:sums[0],outsideLayers:sums[1],totalLayers:sums[2],visibilityMismatches:sums[3]};
    };
    state.inspectEnvelope=()=>{
        const gl=state.gl;if(!gl || !state.bounds)throw new Error('Missing spatial draw state');
        const rect=[...state.bounds.rect];
        if(!gl.getExtension('EXT_color_buffer_float'))throw new Error('Float color target unavailable');
        const saved={program:gl.getParameter(gl.CURRENT_PROGRAM),vao:gl.getParameter(gl.VERTEX_ARRAY_BINDING),draw:gl.getParameter(gl.DRAW_FRAMEBUFFER_BINDING),read:gl.getParameter(gl.READ_FRAMEBUFFER_BINDING),viewport:Array.from(gl.getParameter(gl.VIEWPORT)),texture:gl.getParameter(gl.TEXTURE_BINDING_2D)};
        const capabilities=[gl.BLEND,gl.DEPTH_TEST,gl.SCISSOR_TEST,gl.CULL_FACE,gl.STENCIL_TEST].map(cap=>[cap,gl.isEnabled(cap)]);
        const compile=(kind,source)=>{const shader=gl.createShader(kind);shaderSource.call(gl,shader,source);gl.compileShader(shader);if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(shader));return shader;};
        const vs=compile(gl.VERTEX_SHADER,'#version 300 es\nvoid main(){vec2 p=gl_VertexID==0?vec2(-1.,-1.):gl_VertexID==1?vec2(3.,-1.):vec2(-1.,3.);gl_Position=vec4(p,0.,1.);}');
        const fs=compile(gl.FRAGMENT_SHADER,'#version 300 es\nprecision highp float;uniform sampler2D envelope;out vec4 color;void main(){float d=texelFetch(envelope,ivec2(gl_FragCoord.xy),0).r;color=vec4(d,d,d,1.);}');
        const program=gl.createProgram();attachShader.call(gl,program,vs);attachShader.call(gl,program,fs);gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(program));
        const width=gl.drawingBufferWidth,height=gl.drawingBufferHeight;
        const color=gl.createTexture(),framebuffer=gl.createFramebuffer();gl.bindTexture(gl.TEXTURE_2D,color);gl.texStorage2D(gl.TEXTURE_2D,1,gl.RGBA32F,width,height);gl.bindTexture(gl.TEXTURE_2D,saved.texture);
        gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,framebuffer);gl.framebufferTexture2D(gl.DRAW_FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,color,0);if(gl.checkFramebufferStatus(gl.DRAW_FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw new Error('Envelope proof framebuffer incomplete');
        for(const [cap] of capabilities)gl.disable(cap);
        gl.viewport(0,0,width,height);useProgram.call(gl,program);gl.uniform1i(gl.getUniformLocation(program,'envelope'),5);gl.bindVertexArray(null);drawArrays.call(gl,gl.TRIANGLES,0,3);
        gl.bindFramebuffer(gl.READ_FRAMEBUFFER,framebuffer);gl.readBuffer(gl.COLOR_ATTACHMENT0);const pixels=new Float32Array(width*height*4);gl.readPixels(0,0,width,height,gl.RGBA,gl.FLOAT,pixels);const error=gl.getError();
        useProgram.call(gl,saved.program);gl.bindVertexArray(saved.vao);gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,saved.draw);gl.bindFramebuffer(gl.READ_FRAMEBUFFER,saved.read);gl.viewport(...saved.viewport);
        for(const [cap,on] of capabilities)(on?gl.enable:gl.disable).call(gl,cap);
        gl.deleteFramebuffer(framebuffer);gl.deleteTexture(color);gl.deleteProgram(program);gl.deleteShader(vs);gl.deleteShader(fs);
        if(error!==gl.NO_ERROR)throw new Error('Envelope proof GL error '+error);
        let skippedPixels=0,unsafePixels=0,unbounded=0,finite=0,uncovered=0;
        for(let y=0;y<height;y++)for(let x=0;x<width;x++){
            const d=pixels[(y*width+x)*4],outside=x+0.5<rect[0]||y+0.5<rect[1]||x+0.5>=rect[2]||y+0.5>=rect[3];
            if(d===1)unbounded++;else if(d===0)uncovered++;else finite++;
            if(outside){skippedPixels++;if(d!==1)unsafePixels++;}
        }
        const result={bounds:state.bounds,skippedPixels,unsafePixels,unbounded,finite,uncovered};state.proofs.push(result);return result;
    };
    // Clone the particle fragment program without the portal predicate. Replay each logical
    // dominant draw into disjoint scissor rectangles, preserving order within every pixel.
    const normalLink=p.linkProgram, normalGetLocation=p.getUniformLocation;
    const spatialUse=p.useProgram, spatialDraw=p.drawElementsInstanced;
    const nativeScissor=p.scissor, nativeEnable=p.enable, nativeDisable=p.disable;
    const pairs=new WeakMap(), locationInfo=new WeakMap();
    const uniformNames=['uniform1f','uniform1i','uniform1ui','uniform2f','uniform2i','uniform2ui','uniform3f','uniform3i','uniform3ui','uniform4f','uniform4i','uniform4ui','uniform1fv','uniform2fv','uniform3fv','uniform4fv','uniform1iv','uniform2iv','uniform3iv','uniform4iv','uniform1uiv','uniform2uiv','uniform3uiv','uniform4uiv','uniformMatrix2fv','uniformMatrix3fv','uniformMatrix4fv','uniformMatrix2x3fv','uniformMatrix2x4fv','uniformMatrix3x2fv','uniformMatrix3x4fv','uniformMatrix4x2fv','uniformMatrix4x3fv'];
    const nativeUniform=Object.fromEntries(uniformNames.map(n=>[n,p[n]]));
    state.splitPrograms=[];state.physicalDraws=0;
    p.linkProgram=function(program){
        normalLink.call(this,program);
        const shaders=attached.get(program)||[],fs=shaders.find(s=>(shaderTexts.get(s)||'').includes('uniform int uDiagnosticSpatialMode;'));
        if(!fs)return;
        const text=shaderTexts.get(fs),alternative=text.replace('if (!portalDiagnosticFragmentVisible()) discard;','').replace(/if\(uDiagnosticLayerCounter==1\)\{[\s\S]*?return;\s*\}/,'');
        if(alternative===text)throw new Error('Portal predicate removal failed');
        const shader=this.createShader(this.FRAGMENT_SHADER);shaderSource.call(this,shader,alternative);this.compileShader(shader);if(!this.getShaderParameter(shader,this.COMPILE_STATUS))throw new Error(this.getShaderInfoLog(shader));
        const alt=this.createProgram(),vertex=shaders.find(s=>this.getShaderParameter(s,this.SHADER_TYPE)===this.VERTEX_SHADER);
        attachShader.call(this,alt,vertex);attachShader.call(this,alt,shader);normalLink.call(this,alt);this.deleteShader(shader);
        if(!this.getProgramParameter(alt,this.LINK_STATUS))throw new Error(this.getProgramInfoLog(alt));
        const block=this.getUniformBlockIndex(alt,'PortalScopeAtlasMetadata');if(block!==this.INVALID_INDEX)this.uniformBlockBinding(alt,block,0);
        const pair={alt,values:new Map(),locations:new Map()};pairs.set(program,pair);
        state.splitPrograms.push({originalBytes:text.length,alternateBytes:alternative.length,portalBlockRetained:block!==this.INVALID_INDEX});
    };
    p.getUniformLocation=function(program,name){const location=normalGetLocation.call(this,program,name),pair=pairs.get(program);if(location&&pair)locationInfo.set(location,{pair,name});return location;};
    for(const method of uniformNames)p[method]=function(location,...args){
        const info=location&&locationInfo.get(location);if(info)info.pair.values.set(info.name,{method,args:args.map(v=>ArrayBuffer.isView(v)?Array.from(v):v)});
        return nativeUniform[method].call(this,location,...args);
    };
    let clipEnabled=false,clipBox=null;
    p.scissor=function(x,y,width,height){clipBox=[x,y,width,height];return nativeScissor.apply(this,arguments);};
    p.enable=function(cap){if(cap===this.SCISSOR_TEST)clipEnabled=true;return nativeEnable.call(this,cap);};
    p.disable=function(cap){if(cap===this.SCISSOR_TEST)clipEnabled=false;return nativeDisable.call(this,cap);};
    p.drawElementsInstanced=function(mode,count,type,offset,instances){
        const program=programs.get(this),pair=pairs.get(program);
        if(!pair||count!==330||state.mode!=='split')return spatialDraw.apply(this,arguments);
        if(!state.bounds)throw new Error('Missing split bounds');
        const [left,bottom,right,top]=state.bounds.rect,width=this.drawingBufferWidth,height=this.drawingBufferHeight;
        const savedEnabled=clipEnabled,savedBox=clipBox?[...clipBox]:[0,0,width,height];
        const admitted=(x,y,r,t)=>{
            if(savedEnabled){x=Math.max(x,savedBox[0]);y=Math.max(y,savedBox[1]);r=Math.min(r,savedBox[0]+savedBox[2]);t=Math.min(t,savedBox[1]+savedBox[3]);}
            if(r<=x||t<=y)return false;nativeScissor.call(this,x,y,r-x,t-y);return true;
        };
        nativeEnable.call(this,this.SCISSOR_TEST);
        // Keep original visibility and material shading in the affected rectangle.
        if(admitted(left,bottom,right,top)){spatialDraw.apply(this,arguments);state.physicalDraws++;}
        else {state.counts.draws++;state.counts.instances+=instances;}
        useProgram.call(this,pair.alt);
        for(const [name,value] of pair.values){
            if(!pair.locations.has(name))pair.locations.set(name,normalGetLocation.call(this,pair.alt,name));
            nativeUniform[value.method].call(this,pair.locations.get(name),...value.args);
        }
        for(const rect of [[0,0,width,bottom],[0,top,width,height],[0,bottom,left,top],[right,bottom,width,top]]){
            if(admitted(...rect)){drawElements.apply(this,arguments);state.physicalDraws++;}
        }
        useProgram.call(this,program);nativeScissor.call(this,...savedBox);if(!savedEnabled)nativeDisable.call(this,this.SCISSOR_TEST);
    };

}