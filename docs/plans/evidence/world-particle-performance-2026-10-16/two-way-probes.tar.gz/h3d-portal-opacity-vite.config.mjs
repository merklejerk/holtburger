import base from '/home/me/code/holtburger/apps/holtburger-3d/vite.config.ts';
export default {...base, plugins:[{name:'h3d-fixture-opacity-control',enforce:'pre',transform(code,id){
 if(!id.endsWith('/src/lib/game/renderer/webgl2-portal-scope-atlas-executor-fixture.ts'))return;
 const old='gl.uniform1f(requireWebGL2Uniform(gl, program, "uAlphaTest"), 0);';
 if(code.split(old).length!==2)throw Error('Unexpected fixture alpha setup');
 return {code:code.replace(old,old+'\n gl.uniform1f(requireWebGL2Uniform(gl, program, "uOpacityScale"), 1);'),map:null};
}},...base.plugins]};
