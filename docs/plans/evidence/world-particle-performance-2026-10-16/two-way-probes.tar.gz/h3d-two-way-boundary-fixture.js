({predicate,radius}) => {
 const width=96,height=80;
 const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;
 const gl=canvas.getContext('webgl2',{antialias:false,alpha:false});if(!gl)throw Error('WebGL2 unavailable');
 const debug=gl.getExtension('WEBGL_debug_renderer_info');
 const renderer=debug?gl.getParameter(debug.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER);
 const compile=(type,source)=>{const s=gl.createShader(type);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s;};
 const program=(vertex,fragment)=>{const p=gl.createProgram(),v=compile(gl.VERTEX_SHADER,vertex),f=compile(gl.FRAGMENT_SHADER,fragment);gl.attachShader(p,v);gl.attachShader(p,f);gl.linkProgram(p);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(p));gl.deleteShader(v);gl.deleteShader(f);return p;};
 const vertex=`#version 300 es
 precision highp float;layout(location=0) in vec4 aClip;uniform float uOffset;
 void main(){gl_Position=aClip;gl_Position.z+=uOffset*gl_Position.w;}`;
 const fullVertex=`#version 300 es
 void main(){vec2 p=gl_VertexID==0?vec2(-1.,-1.):gl_VertexID==1?vec2(3.,-1.):vec2(-1.,3.);gl_Position=vec4(p,0.,1.);}`;
 const portal=program(vertex,'#version 300 es\nprecision highp float;void main(){}');
 const reduce=program(fullVertex,`#version 300 es
 precision highp float;uniform highp sampler2D uFrontierDepth;
 void main(){float z=texelFetch(uFrontierDepth,ivec2(gl_FragCoord.xy),0).r;if(z==1.)discard;gl_FragDepth=z*0.5;}`);
 const checkedFragment=`#version 300 es
 precision highp float;precision highp int;
 ${predicate}
 uniform vec4 uColor;out vec4 color;
 void main(){if(!portalDeferredFragmentVisible())discard;color=uColor;}`;
 const outsideFragment=`#version 300 es
 precision highp float;uniform ivec4 uRect;uniform vec4 uColor;out vec4 color;
 void main(){ivec2 p=ivec2(gl_FragCoord.xy);if(all(greaterThanEqual(p,uRect.xy))&&all(lessThan(p,uRect.zw)))discard;color=uColor;}`;
 if(outsideFragment.includes('gl_FragCoord.z'))throw Error('Outside shader reads builtin Z');
 const checked=program(vertex,checkedFragment),outside=program(vertex,outsideFragment);
 const texture=format=>{const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);gl.texStorage2D(gl.TEXTURE_2D,1,format,width,height);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);return t;};
 const target=(t,attachment)=>{const f=gl.createFramebuffer();gl.bindFramebuffer(gl.FRAMEBUFFER,f);gl.framebufferTexture2D(gl.FRAMEBUFFER,attachment,gl.TEXTURE_2D,t,0);if(attachment===gl.DEPTH_ATTACHMENT){gl.drawBuffers([gl.NONE]);gl.readBuffer(gl.NONE);}if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw Error('Incomplete target');return f;};
 const frontier=texture(gl.DEPTH_COMPONENT24),frontierTarget=target(frontier,gl.DEPTH_ATTACHMENT);
 const envelope=texture(gl.DEPTH_COMPONENT32F),envelopeTarget=target(envelope,gl.DEPTH_ATTACHMENT);
 const output=texture(gl.RGBA8),outputTarget=target(output,gl.COLOR_ATTACHMENT0),sceneDepth=texture(gl.DEPTH_COMPONENT24);
 gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.TEXTURE_2D,sceneDepth,0);if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw Error('Incomplete depth target');
 gl.depthMask(true);gl.clearDepth(1);gl.clear(gl.DEPTH_BUFFER_BIT);
 const vao=gl.createVertexArray();gl.bindVertexArray(vao);const vertices=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,vertices);gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,4,gl.FLOAT,false,0,0);
 const metadata=new Uint8Array(16384);new Uint32Array(metadata.buffer,64+255*32,8).set([0,0,0,0,width,height,0,0]);
 const ubo=gl.createBuffer();gl.bindBuffer(gl.UNIFORM_BUFFER,ubo);gl.bufferData(gl.UNIFORM_BUFFER,metadata,gl.STATIC_DRAW);gl.bindBufferBase(gl.UNIFORM_BUFFER,0,ubo);
 const block=gl.getUniformBlockIndex(checked,'PortalScopeAtlasMetadata');gl.uniformBlockBinding(checked,block,0);gl.useProgram(checked);gl.uniform1ui(gl.getUniformLocation(checked,'uPortalRenderDomain'),0);gl.uniform1i(gl.getUniformLocation(checked,'uPortalEnvelopeDepth'),1);
 gl.viewport(0,0,width,height);gl.disable(gl.CULL_FACE);gl.disable(gl.BLEND);gl.disable(gl.DITHER);gl.disable(gl.SCISSOR_TEST);
 function draw(p,offset,color=[1,1,1,1]){gl.useProgram(p);gl.uniform1f(gl.getUniformLocation(p,'uOffset'),offset);gl.uniform4fv(gl.getUniformLocation(p,'uColor'),color);gl.bindVertexArray(vao);gl.drawArrays(gl.TRIANGLES,0,3);}
 function setEnvelope(mode){
  gl.disable(gl.BLEND);gl.disable(gl.SCISSOR_TEST);gl.bindFramebuffer(gl.FRAMEBUFFER,envelopeTarget);gl.depthMask(true);gl.clearDepth(mode==='uncovered'?0:1);gl.clear(gl.DEPTH_BUFFER_BIT);
  if(mode!=='finite'&&mode!=='window')return;
  gl.bindFramebuffer(gl.FRAMEBUFFER,frontierTarget);gl.clearDepth(1);gl.clear(gl.DEPTH_BUFFER_BIT);gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.ALWAYS);
  if(mode==='window'){gl.enable(gl.SCISSOR_TEST);gl.scissor(22,17,45,42);}
  draw(portal,0);gl.disable(gl.SCISSOR_TEST);
  gl.bindFramebuffer(gl.FRAMEBUFFER,envelopeTarget);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,frontier);gl.useProgram(reduce);gl.uniform1i(gl.getUniformLocation(reduce,'uFrontierDepth'),0);gl.drawArrays(gl.TRIANGLES,0,3);gl.disable(gl.DEPTH_TEST);
 }
 function read(split,rect,offset,depthTest,blend=false){
  gl.bindFramebuffer(gl.FRAMEBUFFER,outputTarget);gl.depthMask(false);gl.depthFunc(gl.LEQUAL);(depthTest?gl.enable:gl.disable).call(gl,gl.DEPTH_TEST);(blend?gl.enable:gl.disable).call(gl,gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);gl.disable(gl.SCISSOR_TEST);gl.clearBufferfv(gl.COLOR,0,new Float32Array([.1,.2,.3,1]));gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,envelope);
  const draws=blend?[[offset,[1,0,0,.25]],[offset-2**-20,[0,1,0,.5]],[offset+2**-20,[0,0,1,.75]]]:[[offset,[1,1,1,1]]];
  if(split){gl.useProgram(outside);gl.uniform4iv(gl.getUniformLocation(outside,'uRect'),rect);for(const [z,c]of draws)draw(outside,z,c);gl.enable(gl.SCISSOR_TEST);gl.scissor(rect[0],rect[1],rect[2]-rect[0],rect[3]-rect[1]);}
  for(const [z,c]of draws)draw(checked,z,c);gl.disable(gl.SCISSOR_TEST);
  const pixels=new Uint8Array(width*height*4);gl.readPixels(0,0,width,height,gl.RGBA,gl.UNSIGNED_BYTE,pixels);return pixels;
 }
 function triangle(ndc,ws,zs){return new Float32Array(ndc.flatMap(([x,y],i)=>[x*ws[i],y*ws[i],zs[i]*ws[i],ws[i]]));}
 function bounds(positions){let l=width,b=height,r=0,t=0;for(let i=0;i<12;i+=4){const w=positions[i+3];if(w<=.00001)return[0,0,width,height];const x=(positions[i]/w+1)*width/2,y=(positions[i+1]/w+1)*height/2;l=Math.min(l,x);b=Math.min(b,y);r=Math.max(r,x);t=Math.max(t,y);}return[Math.max(0,Math.min(width,Math.floor(l)-3)),Math.max(0,Math.min(height,Math.floor(b)-3)),Math.max(0,Math.min(width,Math.ceil(r)+3)),Math.max(0,Math.min(height,Math.ceil(t)+3))];}
 const shape=[[-.95,-.9],[.94,-.84],[-.65,.93]];
 const cases=[{name:'constant-mid',ws:[1,1,1],zs:[.25,.25,.25]},{name:'constant-far',ws:[1,1,1],zs:[.9999,.9999,.9999]},{name:'sloping',ws:[1,1,1],zs:[-.7,.85,.1]},{name:'perspective',ws:[.25,20,1000],zs:[-.9,.95,.3]},{name:'wide-w-range',ws:[.001,1,100000],zs:[-.999,.9999,.1]},{name:'near-clipped',ws:[.2,10,30],zs:[-1.5,.8,.1]},{name:'far-clipped',ws:[1,10,500],zs:[.4,1.3,.9]},{name:'eye-crossing',ws:[-.3,2,20],zs:[0,.8,-.6]},{name:'steep-narrow',ws:[.1,100,2],zs:[-.95,.999,.5],shape:[[-.04,-.98],[.035,-.95],[.012,.98]]}];
 const offsets=[-(2**-16),-(2**-20),-(2**-22),-(2**-24),-(2**-26),0,2**-26,2**-24,2**-22,2**-20,2**-16];
 const records=[];let negativeControlDifferentBytes=0;
 for(const c of cases)for(const shift of[0,.0078125,-.01953125]){
  const positions=triangle((c.shape||shape).map(([x,y])=>[x+shift,y-shift]),c.ws,c.zs);gl.bindBuffer(gl.ARRAY_BUFFER,vertices);gl.bufferData(gl.ARRAY_BUFFER,positions,gl.STREAM_DRAW);
  for(const depthTest of[true,false])for(const mode of['finite','window','unbounded','uncovered']){
   setEnvelope(mode);const rect=mode==='finite'?bounds(positions):mode==='uncovered'?[0,0,width,height]:[20,15,69,61];
   for(const offset of mode==='finite'||mode==='window'?offsets:[0])for(const blend of[false,true]){
    const a=read(false,rect,offset,depthTest,blend),b=read(true,rect,offset,depthTest,blend);let differentBytes=0,maxByteDifference=0;for(let i=0;i<a.length;i++){if(a[i]!==b[i])differentBytes++;maxByteDifference=Math.max(maxByteDifference,Math.abs(a[i]-b[i]));}
    records.push({name:c.name,shift,depthTest,mode,rect,offset,blend,differentBytes,maxByteDifference});
    if(mode==='window'&&offset===0&&!blend){const bad=read(true,[0,0,0,0],offset,depthTest);for(let i=0;i<a.length;i++)if(a[i]!==bad[i])negativeControlDifferentBytes++;}
   }
  }
 }
 const error=gl.getError();if(error)throw Error('WebGL error '+error);
 const summary={comparisons:records.length,failures:records.filter(r=>r.differentBytes>0).length,differentBytes:records.reduce((n,r)=>n+r.differentBytes,0),maxByteDifference:Math.max(...records.map(r=>r.maxByteDifference)),negativeControlDifferentBytes};
 if(summary.failures||negativeControlDifferentBytes===0)throw Error('Partition validation failed '+JSON.stringify(summary));
 return {renderer,width,height,gutterRadius:radius,summary,records,shaders:{vertex,checkedFragment,outsideFragment},limitations:['Synthetic partition test uses unrestricted envelope clear outside finite geometry; it does not reproduce full traversal.','CPU bounding rectangle is a diagnostic with a three-pixel guard, not a general raster error proof.','Original shader and builtin fragment depth are retained in the checked rectangle.','Opaque test attachment is clear depth one; enabled and disabled tests cover depth-state routing, not an occluder distribution.','No timings or visual acceptance checks.']};
}
