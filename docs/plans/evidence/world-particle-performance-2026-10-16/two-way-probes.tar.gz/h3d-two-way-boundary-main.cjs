const { app, BrowserWindow } = require('electron');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = '/home/me/code/holtburger/apps/holtburger-3d/src/lib/game/renderer';
const sources = {};
function source(name) { const s = fs.readFileSync(path.join(root, name), 'utf8'); sources[name] = crypto.createHash('sha256').update(s).digest('hex'); return s; }
function template(name, symbol) {
  const s = source(name); const marker = `export const ${symbol} = \``;
  const start = s.indexOf(marker); if(start < 0) throw Error(`Missing template ${symbol}`);
  return s.slice(start + marker.length, s.indexOf('`;', start + marker.length));
}
const countSource = source('portal-arrival-metadata.ts');
if(!countSource.includes('PORTAL_ARRIVAL_STATE_MAXIMUM_COUNT = 0xff')) throw Error('Arrival capacity changed');
const metadataSource = source('portal-scope-atlas-metadata-glsl.ts');
const name = metadataSource.match(/const PORTAL_SCOPE_ATLAS_METADATA_BLOCK_NAME = "([^"]+)";/)[1];
const metadata = template('portal-scope-atlas-metadata-glsl.ts', 'PORTAL_SCOPE_ATLAS_METADATA_GLSL')
 .replaceAll('${PORTAL_SCOPE_ATLAS_METADATA_BLOCK_NAME}',name).replaceAll('${PORTAL_ARRIVAL_STATE_MAXIMUM_COUNT}','255');
const samplingSource = source('portal-envelope-sampling-glsl.ts');
const radius = Number(samplingSource.match(/PORTAL_ENVELOPE_GUTTER_RADIUS_TEXELS: number = (\d+)/)[1]);
const gutter = samplingSource.slice(samplingSource.indexOf(': `')+3, samplingSource.indexOf('`;')).replaceAll('${PORTAL_ENVELOPE_GUTTER_RADIUS_TEXELS}',String(radius));
const sampling = template('portal-envelope-sampling-glsl.ts','PORTAL_ENVELOPE_SAMPLING_GLSL').replace('${gutterSampling}', radius===0?'':gutter);
const predicate = template('portal-deferred-visibility-glsl.ts','PORTAL_DEFERRED_VISIBILITY_GLSL')
 .replace('${PORTAL_SCOPE_ATLAS_METADATA_GLSL}',metadata).replace('${PORTAL_ENVELOPE_SAMPLING_GLSL}',sampling);
if(predicate.includes('${')) throw Error('Unresolved GLSL template');
const productionReduction = source('webgl2-portal-scope-atlas-programs.ts');
if(!productionReduction.includes('texelFetch(uFrontierDepth, screenPixel, 0).r * 0.5')) throw Error('Envelope encoding changed');
const fixture = fs.readFileSync('/tmp/h3d-two-way-boundary-fixture.js','utf8');
app.whenReady().then(async()=>{
 const win = new BrowserWindow({width:800,height:600,show:true,webPreferences:{contextIsolation:true,sandbox:true,nodeIntegration:false}});
 try {
  await win.loadURL('data:text/html,<html><body>Depth precision diagnostic</body></html>');
  const result = await win.webContents.executeJavaScript(`(${fixture})(${JSON.stringify({predicate,radius})})`,true);
  result.sourceHashes=sources;
  const gpu=await app.getGPUInfo('complete');
  result.gpu={devices:gpu.gpuDevice,auxAttributes:gpu.auxAttributes};
  fs.writeFileSync('/tmp/h3d-two-way-boundary-result.json',JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify({stage:'complete',summary:result.summary,renderer:result.renderer}));
 } catch(e) {console.error(e.stack);process.exitCode=1;}
 finally {win.destroy();app.quit();}
});
