"""Read-only validation of retained spatial-partition investigation evidence."""
from pathlib import Path
import gzip,hashlib,json,statistics,tarfile
root=Path.cwd();base=root/'docs/plans/evidence/world-particle-performance-2026-10-16';m=json.loads((base/'manifest.json').read_text())
for f in m['files']:
 data=(base/f['path']).read_bytes();assert len(data)==f['bytes']and hashlib.sha256(data).hexdigest()==f['sha256'],f['path']
def read(name):return json.loads(gzip.decompress((base/('two-way-'+name+'.json.gz')).read_bytes()))
s=json.loads((base/'two-way-summary.json').read_text());f=read('frozen');l=read('live');a=read('boundary-first');b=read('boundary-repeat');p=read('opacity-control')
assert len(f['trials'])==15 and len(l['trials'])==10 and len(l['proofs'])==10 and l['cleanup']=={'restored':True}
assert f['setup']['draws']==206 and f['validation']=={'differentPixels':0,'affectedPixels':48374,'externalDraws':0,'error':0}
assert all(c['differentPixels']==0 for c in f['setup']['comparisons'])
assert f['envelope']['unsafePixels']==0 and f['envelope']['finite']==f['envelope']['uncovered']==0
for label in ['normal','two-way','no-portal']:
 ts=[t for t in f['trials']if t['label']==label];assert sorted(t['round']for t in ts)==list(range(5))
 assert all(len(t['values'])==40 and t['depth']and t['externalDraws']==0 and t['physicalDraws']==(412 if label=='two-way'else 206)for t in ts)
 assert statistics.median([statistics.mean(t['values'])for t in ts])==s['frozen']['gpuMs'][label]['median']
for mode in ['normal','split']:
 ts=[t for t in l['trials']if t['mode']==mode];assert sorted(t['round']for t in ts)==list(range(5))
 for t in ts:
  frames=t['snapshot']['sampledFrameCount'];assert t['windowMs']>=4000 and frames>0
  assert t['counts']['draws']==t['counts']['instances']==frames*206
  assert t['physicalDraws']==frames*(412 if mode=='split'else 206)
  assert all(not p['portalBlockRetained']for p in t['splitPrograms'])
for proof in l['proofs']:assert proof['unsafePixels']==proof['finite']==proof['uncovered']==0
assert a['records']==b['records']and a['summary']==b['summary']
assert len(a['records'])==2592 and a['summary']['differentBytes']==a['summary']['failures']==0 and a['summary']['negativeControlDifferentBytes']>0
assert any(r['mode']=='window'and r['blend']for r in a['records'])
assert 'gl_FragCoord.z'not in a['shaders']['outsideFragment']and 'gl_FragCoord.z'in a['shaders']['checkedFragment']
assert p['ready']and p['error']is None and p['executor']['particleMatchesEquivalentTransparency']
for path,digest in s['productionSourceHashes'].items():assert hashlib.sha256((root/path).read_bytes()).hexdigest()==digest,path
for path,digest in s['servedProductionAssets'].items():assert hashlib.sha256((root/path).read_bytes()).hexdigest()==digest,path
removed=set(m['sanitization']['removedKeys'])
def sanitized(v):
 if isinstance(v,list):
  for x in v:sanitized(x)
 if isinstance(v,dict):
  assert not removed.intersection(v)
  if 'consoleMessages'in v:assert all(set(row)<={'level','count'}for row in v['consoleMessages'])
  for x in v.values():sanitized(x)
for v in [s,f,l,a,b,p]:sanitized(v)
with tarfile.open(base/'two-way-probes.tar.gz')as archive:
 for member in archive.getmembers():assert member.isfile()and member.name==Path(member.name).name
print(json.dumps({'ok':True,'artifacts':len(m['files']),'frozenWindows':15,'liveWindows':10,'boundaryRuns':2,'boundaryComparisonsPerRun':2592,'portalOpacityControlPassed':True,'productionSourceUnchanged':True}))
